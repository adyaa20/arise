"""
cogs/help.py — Advanced Help Cog
==================================
• Replaces the default discord.py help command entirely
• Category select dropdown — auto-populates from all loaded cogs
• Detailed command listing with usage, aliases, and description
• No pagination buttons needed — each category fits one embed
• Fully dynamic: adding a new cog file instantly appears here
"""

import logging
from typing import Optional

import discord
from discord.ext import commands

log = logging.getLogger("help")

# ── Embed colour per cog category (fallback = blurple) ────────────────────────
CATEGORY_COLORS: dict[str, int] = {
    "Player":        0x7B2FBE,
    "Gate":          0xCC1133,
    "Exam":          0xCC6600,
    "Quests":        0x1A8C4E,
    "Train":         0x1E5FBE,
    "Emoji Manager": 0xF1C40F,
    "DB Status":     0xE74C3C,
    "Backup":        0x2ECC71,
    "Help":          0x3498DB,
}

CATEGORY_ICONS: dict[str, str] = {
    "Player":        "👤",
    "Gate":          "🌀",
    "Exam":          "📜",
    "Quests":        "📋",
    "Train":         "🏋️",
    "Emoji Manager": "🎭",
    "DB Status":     "🗄️",
    "Backup":        "💾",
    "Help":          "📖",
}

# ── Cogs that should NOT appear in help (internal / hidden) ───────────────────
HIDDEN_COGS = {"Help"}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _usage_string(cmd: commands.Command) -> str:
    """Build  slname <required> [optional]  from the command signature."""
    return f"`sl{cmd.qualified_name} {cmd.signature}`".strip()


def _build_cog_embed(cog: commands.Cog, bot: commands.Bot) -> discord.Embed:
    """Create a detailed embed for a single cog/category."""
    icon  = CATEGORY_ICONS.get(cog.qualified_name, "📂")
    color = CATEGORY_COLORS.get(cog.qualified_name, discord.Color.blurple().value)

    embed = discord.Embed(
        title=f"{icon}  {cog.qualified_name}",
        description=cog.description or "*No description provided.*",
        color=color,
    )

    cmds = [c for c in cog.get_commands() if not c.hidden]
    if not cmds:
        embed.add_field(name="Commands", value="*No visible commands.*", inline=False)
        return embed

    for cmd in sorted(cmds, key=lambda c: c.name):
        aliases = f"  *(aliases: {', '.join(f'`sl{a}`' for a in cmd.aliases)})*" if cmd.aliases else ""
        value   = (
            f"{cmd.help or '*No description.*'}\n"
            f"**Usage:** {_usage_string(cmd)}"
            f"{aliases}"
        )
        embed.add_field(name=f"`sl{cmd.name}`", value=value, inline=False)

    embed.set_footer(text=f"sl = prefix  |  <required>  [optional]")
    return embed


def _build_overview_embed(bot: commands.Bot) -> discord.Embed:
    """Landing/overview embed shown before a category is selected."""
    embed = discord.Embed(
        title="🗡️  Solo Leveling Bot — Help",
        description=(
            "Use the **dropdown below** to browse command categories.\n\n"
            "**Prefix:** `sl`  *(case-insensitive: sl / Sl / SL / sL)*\n"
            f"**Categories:** {len([c for n, c in bot.cogs.items() if n not in HIDDEN_COGS])}\n"
            f"**Total commands:** {len([c for c in bot.commands if not c.hidden])}"
        ),
        color=0x5865F2,
    )
    for cog_name, cog in sorted(bot.cogs.items()):
        if cog_name in HIDDEN_COGS:
            continue
        icon  = CATEGORY_ICONS.get(cog_name, "📂")
        cmds  = [c for c in cog.get_commands() if not c.hidden]
        names = "  ".join(f"`sl{c.name}`" for c in sorted(cmds, key=lambda x: x.name))
        embed.add_field(
            name=f"{icon}  {cog_name}",
            value=names or "*(no visible commands)*",
            inline=False,
        )
    embed.set_footer(text="Select a category below for detailed info.")
    return embed


# ─────────────────────────────────────────────────────────────────────────────
# Select menu
# ─────────────────────────────────────────────────────────────────────────────

class CategorySelect(discord.ui.Select):
    def __init__(self, bot: commands.Bot, invoker_id: int):
        self.bot        = bot
        self.invoker_id = invoker_id

        options = []
        for cog_name, cog in sorted(bot.cogs.items()):
            if cog_name in HIDDEN_COGS:
                continue
            icon = CATEGORY_ICONS.get(cog_name, "📂")
            options.append(
                discord.SelectOption(
                    label=cog_name,
                    description=(cog.description or "")[:100],
                    emoji=icon,
                    value=cog_name,
                )
            )

        if not options:
            options.append(discord.SelectOption(label="No categories", value="__none__"))

        super().__init__(
            placeholder="📂  Choose a category…",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.invoker_id:
            return await interaction.response.send_message(
                "❌ This menu isn't yours.", ephemeral=True
            )

        selected = self.values[0]
        if selected == "__none__":
            return await interaction.response.defer()

        cog = self.bot.get_cog(selected)
        if not cog:
            return await interaction.response.send_message(
                "❌ Category not found (it may have been reloaded).", ephemeral=True
            )

        embed = _build_cog_embed(cog, self.bot)
        await interaction.response.edit_message(embed=embed)


class HelpView(discord.ui.View):
    def __init__(self, bot: commands.Bot, invoker_id: int):
        super().__init__(timeout=180)
        self.add_item(CategorySelect(bot, invoker_id))

    async def on_timeout(self):
        # Disable the select on timeout
        for child in self.children:
            child.disabled = True
        # We don't have a direct message ref here; bot.py handles cleanup if needed


# ─────────────────────────────────────────────────────────────────────────────
# Cog
# ─────────────────────────────────────────────────────────────────────────────

class HelpCog(commands.Cog, name="Help"):
    """Bot help and information commands."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="help", aliases=["h", "commands", "cmds"], help="Show the help menu.")
    async def help_cmd(self, ctx: commands.Context, *, category: Optional[str] = None):
        """
        Usage: slhelp [category]

        Without arguments: shows the overview with a category dropdown.
        With a category name: jumps straight to that category's embed.
        """
        if category:
            # Try exact match first, then case-insensitive
            cog = self.bot.get_cog(category) or next(
                (c for n, c in self.bot.cogs.items() if n.lower() == category.lower()),
                None,
            )
            if cog and cog.qualified_name not in HIDDEN_COGS:
                return await ctx.send(embed=_build_cog_embed(cog, self.bot))
            await ctx.send(f"❌ Category `{category}` not found. Use `slhelp` to see all categories.")
            return

        view = HelpView(self.bot, ctx.author.id)
        msg  = await ctx.send(embed=_build_overview_embed(self.bot), view=view)

        # Store message ref so we can disable select on timeout
        async def on_timeout_patch():
            for child in view.children:
                child.disabled = True
            try:
                await msg.edit(view=view)
            except Exception:
                pass

        view.on_timeout = on_timeout_patch  # type: ignore[method-assign]


async def setup(bot: commands.Bot):
    await bot.add_cog(HelpCog(bot))
