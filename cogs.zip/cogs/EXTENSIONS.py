"""
All extension paths for bot.load_extension().
Import this in your main.py:

    from cogs.EXTENSIONS import ALL_EXTENSIONS
    for ext in ALL_EXTENSIONS:
        await bot.load_extension(ext)
"""

ALL_EXTENSIONS = [
    # ── Core player system ──
    "cogs.player.player_cog",

    # ── Main commands ──
    "cogs.main_cmds.gate_cog",
    "cogs.main_cmds.exam_cog",
    "cogs.main_cmds.quests",
    "cogs.main_cmds.skills_cog",
    # ── Basic commands ──
    "cogs.basic.daily_cog",
    "cogs.basic.train",
    "cogs.basic.trivia",

    # ── Admin ──
    "cogs.admin.admin",
    "cogs.admin.backup_cog",
    "cogs.admin.db_status",
    "cogs.admin.ban_system",
    # ── Emojis ──
    "cogs.admin.emoji_manager",

    # ── Help ──
    "cogs.help",
]
