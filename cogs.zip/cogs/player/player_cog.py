"""
cogs/player_cog.py — Player System
=====================================
Architecture:
  • MongoDB → players collection (all player data)

Rank + Level System:
  • E Rank : Level 1–25   (stats grow per level, gate cleared = XP)
  • D Rank : Level 26–50  (locked until Hunter Exam after lv 25)
  • C Rank : Level 51–80
  • B Rank : Level 81–120
  • A Rank : Level 121–180
  • S Rank : Level 181+

Gate Access:
  • E  → E rank gates only
  • D  → E, D
  • C  → E, D, C
  • B  → E, D, C, B
  • A  → E, D, C, B, A
  • S  → E, D, C, B, A  (NOT S — needs National Level status)
  • National Level → all gates including S

Skills (unlocked every 5 levels, usable in gate combat):
  • Level  5 → Shadow Strike  (Power: 40, Mana Cost: 100)
  • Level 10 → Multi Strike   (Power: 50, Mana Cost: 120)
  • Level 15 → Arc Slash      (Power: 70, Mana Cost: 150)
  • Level 20 → Shadow Burst   (Power: 100, Mana Cost: 200)

Commands:
  sl start          — register
  sl profile        — full profile
  sl stats          — quick stat view
  sl su <stat> <n>  — invest skill points
  sl exam           — take hunter rank exam (once eligible)
  sl cd             — cooldowns
  sl skills         — skill unlock status (handled in skills_cog.py)

Moved to daily_cog.py:
  sl daily          — claim daily reward
  sl balance        — wallet

Moved to exam_cog.py:
  sl exam           — take hunter rank exam
"""

import discord
from discord.ext import commands
import datetime
import random
import math

from database import MongoDB
from cogs.admin.emoji_manager import get_emoji_json as _get_emoji_json

# ─────────────────────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────────────────────

RANK_ORDER = ["E", "D", "C", "B", "A", "S"]

# Level at which exam becomes available per rank
EXAM_LEVEL_REQ = {
    "E": 25,   # E → D exam unlocks at lv 25
    "D": 50,
    "C": 80,
    "B": 120,
    "A": 180,
    # S → National Level is manual (admin grants)
}

# Levels where stats STOP growing (player needs exam to continue)
RANK_LEVEL_CAP = {
    "E": 25,
    "D": 50,
    "C": 80,
    "B": 120,
    "A": 180,
    "S": 999,
}

# Colors per rank — dark purple theme
RANK_COLORS = {
    "E": 0x555577,
    "D": 0x1E5FBE,
    "C": 0x1A8C4E,
    "B": 0x7B2FBE,
    "A": 0xCC6600,
    "S": 0xCC1133,
}

# Fallback rank emojis (used if DB emoji not found)
RANK_EMOJI_FB = {
    "E": "<:e_rank:1487523864861737191>",
    "D": "<:d_rank:1487523295728500898>",
    "C": "<:c_rank:1487523294243721378>",
    "B": "🟪",
    "A": "<:a_rank:1487523290191757322>",
    "S": "🟥",
}

# Stat gain per level (passive — no class)
STAT_PER_LEVEL = {
    "hp":   20,
    "mp":   8,     # Increased from 5 → skills are mana-hungry
    "atk":  3,
    "def":  2,
    "prec": 1,
    "spd":  1,
}

# Stat boost per skill point invested
STAT_BOOST = {
    "atk":  10,
    "def":  10,
    "hp":   50,
    "mp":   10,
    "prec": 5,
    "spd":  5,
}

# Rank-up stat bonuses (granted when rank advances via exam)
RANK_UP_BONUS = {
    "D": {"hp": 200,  "mp": 80,  "atk": 50,  "def": 30,  "prec": 10, "spd": 10},
    "C": {"hp": 400,  "mp": 160, "atk": 100, "def": 60,  "prec": 20, "spd": 20},
    "B": {"hp": 800,  "mp": 320, "atk": 200, "def": 120, "prec": 40, "spd": 40},
    "A": {"hp": 1500, "mp": 600, "atk": 400, "def": 250, "prec": 80, "spd": 80},
    "S": {"hp": 3000, "mp": 1200,"atk": 800, "def": 500, "prec": 150,"spd": 150},
}

# Base stats at registration (E rank, level 1)
BASE_STATS = {
    "hp": 800, "mp": 200,
    "atk": 130, "def": 50,
    "prec": 15, "spd": 15,
}

# Skill points awarded per level
SP_PER_LEVEL = 3

# Startup rewards
START_COINS     = 50_000
START_DIAMONDS  = 25
START_TICKETS   = 20

# Daily reward
DAILY_GOLD    = 500
DAILY_ESSENCE = 10
DAILY_COOLDOWN_HRS = 20

# Exam pass chance (random roll — can be tuned)
EXAM_BASE_PASS = 0.80   # 80% pass rate — feels earned not guaranteed

# ─────────────────────────────────────────────────────────────
#  SKILLS SYSTEM
# ─────────────────────────────────────────────────────────────

# All 4 skills — unlock at levels 5, 10, 15, 20
SKILLS = [
    {
        "id":          "shadow_strike",
        "name":        "Shadow Strike",
        "emoji":       "🌑",
        "power":       40,       # damage multiplier applied in gate_cog calc_damage
        "mana_cost":   100,
        "unlock_level": 5,
        "desc":        "A swift shadow-infused slash that deals moderate damage.",
    },
    {
        "id":          "multi_strike",
        "name":        "Multi Strike",
        "emoji":       "⚡",
        "power":       50,
        "mana_cost":   120,
        "unlock_level": 10,
        "desc":        "Rapid consecutive strikes that overwhelm defences.",
    },
    {
        "id":          "arc_slash",
        "name":        "Arc Slash",
        "emoji":       "🌀",
        "power":       70,
        "mana_cost":   150,
        "unlock_level": 15,
        "desc":        "A wide arcing blade wave that carves through armour.",
    },
    {
        "id":          "shadow_burst",
        "name":        "Shadow Burst",
        "emoji":       "💥",
        "power":       100,
        "mana_cost":   200,
        "unlock_level": 20,
        "desc":        "An explosive eruption of shadow energy — your ultimate.",
    },
]

# Quick lookup by id
SKILL_BY_ID = {s["id"]: s for s in SKILLS}


def get_unlocked_skills(level: int) -> list[dict]:
    """Return list of skills unlocked at this level."""
    return [s for s in SKILLS if level >= s["unlock_level"]]


def get_skill_by_id(skill_id: str) -> dict | None:
    return SKILL_BY_ID.get(skill_id)


# ─────────────────────────────────────────────────────────────
#  MONGO HELPERS
# ─────────────────────────────────────────────────────────────

def _col():
    return MongoDB.col("players")


def get_player(discord_id: int) -> dict | None:
    return _col().find_one({"discord_id": discord_id})


def save_player(discord_id: int, data: dict) -> None:
    _col().update_one(
        {"discord_id": discord_id},
        {"$set": data},
        upsert=True,
    )


def player_exists(discord_id: int) -> bool:
    return _col().count_documents({"discord_id": discord_id}) > 0


# ─────────────────────────────────────────────────────────────
#  LEVEL / XP / RANK SYSTEM
# ─────────────────────────────────────────────────────────────

def xp_to_next(level: int) -> int:
    """XP needed to go from `level` to `level+1`."""
    return int(100 * (level ** 1.5))


def get_rank_from_level(level: int) -> str:
    """Return the rank bracket for a given level (ignores exam — just bracket)."""
    if level <= 25:  return "E"
    if level <= 50:  return "D"
    if level <= 80:  return "C"
    if level <= 120: return "B"
    if level <= 180: return "A"
    return "S"


def apply_level_up(player: dict) -> int:
    """
    Process XP → level ups. Stops at rank level cap if exam not passed.
    Returns number of levels gained.
    """
    gained = 0
    rank   = player.get("rank", "E")
    cap    = RANK_LEVEL_CAP.get(rank, 999)

    while (player["xp"] >= xp_to_next(player["level"])
           and player["level"] < cap):
        player["xp"]    -= xp_to_next(player["level"])
        player["level"] += 1
        player["skill_points"] = player.get("skill_points", 0) + SP_PER_LEVEL
        # Passive stat growth per level
        for stat, gain in STAT_PER_LEVEL.items():
            player[stat] = player.get(stat, BASE_STATS.get(stat, 0)) + gain
        player["max_hp"] = player["hp"]
        player["max_mp"] = player["mp"]
        gained += 1

    return gained


def can_take_exam(player: dict) -> tuple[bool, str]:
    """Returns (eligible, reason_if_not)."""
    rank  = player.get("rank", "E")
    level = player.get("level", 1)
    if rank == "S":
        return False, "You are already S Rank. Only the System can grant National Level status."
    req = EXAM_LEVEL_REQ.get(rank, 999)
    if level < req:
        return False, f"You need **Level {req}** to take the exam. Currently: **{level}**."
    if player.get("exam_taken_today"):
        return False, "You have already attempted the exam today. Come back tomorrow."
    return True, ""


def rank_up(player: dict) -> str:
    """Advance player rank. Returns new rank."""
    old_idx = RANK_ORDER.index(player.get("rank", "E"))
    new_rank = RANK_ORDER[min(old_idx + 1, len(RANK_ORDER) - 1)]
    player["rank"] = new_rank
    # Apply rank-up bonus stats
    bonus = RANK_UP_BONUS.get(new_rank, {})
    for stat, val in bonus.items():
        player[stat] = player.get(stat, 0) + val
    player["max_hp"] = player["hp"]
    player["max_mp"] = player["mp"]
    return new_rank


# ─────────────────────────────────────────────────────────────
#  EMOJI HELPERS
# ─────────────────────────────────────────────────────────────

def _resolve_db_emoji(raw: str, name: str = "") -> str:
    """
    emoji_manager stores custom emojis as just the ID (e.g. '1487523864861737191').
    Reconstruct the full <:name:id> string so Discord renders it.
    If it's already a full emoji string or unicode, return as-is.
    """
    if not raw:
        return ""
    if raw.startswith("<") or not raw.isdigit():
        return raw   # already formatted or unicode
    # It's a raw ID — reconstruct using the lookup name as the emoji name
    emoji_name = name or "emoji"
    return f"<:{emoji_name}:{raw}>"


def _rank_emoji(rank: str) -> str:
    key   = f"{rank.lower()}_rank"
    entry = _get_emoji_json(key)
    if entry:
        return _resolve_db_emoji(entry["emoji_str"], key)
    return RANK_EMOJI_FB.get(rank, "⬜")


def _stat_emoji(name: str) -> str:
    _FALLBACK = {
        "hp":       "❤️",
        "mp":       "💙",
        "atk":      "⚔️",
        "def":      "🛡️",
        "prec":     "🎯",
        "spd":      "👟",
        "gold":     "<:gold:1488226454595436725>",
        "essence":  "<:diamonds:1488226480767897781>",
        "gate_key": "<:gacha_ticke:1488241475954409552>",
        "xp":       "<:exp:1500854097170141276>",
    }
    entry = _get_emoji_json(name)
    if entry:
        return _resolve_db_emoji(entry["emoji_str"], name)
    return _FALLBACK.get(name, "▸")


# ─────────────────────────────────────────────────────────────
#  UI BUILDERS
# ─────────────────────────────────────────────────────────────

def _xp_bar(xp: int, xp_max: int, length: int = 14) -> str:
    pct    = min(xp / max(xp_max, 1), 1.0)
    filled = int(pct * length)
    return "█" * filled + "░" * (length - filled)


def _hp_bar(current: int, maximum: int, length: int = 10) -> str:
    pct    = min(current / max(maximum, 1), 1.0)
    filled = int(pct * length)
    return "█" * filled + "░" * (length - filled)


def _gate_access_str(player: dict) -> str:
    rank     = player.get("rank", "E")
    national = player.get("national_level", False)
    idx      = RANK_ORDER.index(rank)
    allowed  = RANK_ORDER[:idx + 1]   # E up to current rank
    lines    = []
    for r in RANK_ORDER:
        if national or r in allowed:
            lines.append(f"✅ **{r} Rank Gates**")
        elif rank == "S" and r == "S":
            lines.append(f"🔒 **S Rank Gates** *(National Level required)*")
        else:
            lines.append(f"🔒 **{r} Rank Gates**")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────
#  REGISTRATION IMAGES
# ─────────────────────────────────────────────────────────────

_REGISTER_IMG = (
    "https://cdn.discordapp.com/attachments/1482309921235144748"
    "/1506909540753342605/register.png"
    "?ex=6a1a865f&is=6a1934df"
    "&hm=cc50582a585a0013e25d0a80e57ae40a9693e097ab7a2834483a3cc67c06ccd7&"
)
_JINWOO_IMG = (
    "https://cdn.discordapp.com/attachments/1482309921235144748"
    "/1506909660043673642/jinwoo.png"
    "?ex=6a1a867b&is=6a1934fb"
    "&hm=b73736a30007f8be6b402d0c3ad23a0a1bdd8ff12c5db761f5e41a460a6c6933&"
)

# Startup rewards shown in confirm embed
GOLD_EMOJI    = "<:gold:1488226454595436725>"
DIAMOND_EMOJI = "<:diamonds:1488226480767897781>"
TICKET_EMOJI  = "<:gacha_ticke:1488241475954409552>"



# ─────────────────────────────────────────────────────────────
#  REGISTER VIEW
# ─────────────────────────────────────────────────────────────

class RegisterView(discord.ui.View):
    def __init__(self, user: discord.Member, player_data: dict):
        super().__init__(timeout=60)
        self.user        = user
        self.player_data = player_data
        self.responded   = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user.id:
            await interaction.response.send_message(
                "❌ This is not your system window.", ephemeral=True
            )
            return False
        return True

    @discord.ui.button(label="CONFIRM", style=discord.ButtonStyle.primary)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.responded:
            return
        self.responded = True
        self.stop()

        if player_exists(self.user.id):
            await interaction.response.edit_message(
                content=None,
                embed=discord.Embed(
                    description="⚠️ You are already registered in the System, Hunter.",
                    color=0x3D0070,
                ),
                view=None,
            )
            return

        try:
            save_player(self.user.id, self.player_data)
        except Exception as exc:
            import logging
            logging.getLogger("player_cog").exception(
                "Registration failed for %s", self.user.id, exc_info=exc
            )
            await interaction.response.edit_message(
                content="❌ Registration failed. Please try again.",
                embed=None,
                view=None,
            )
            return

        embed = discord.Embed(title="SYSTEM NOTIFICATION", color=0x6600CC)
        embed.set_image(url=_JINWOO_IMG)
        embed.add_field(
            name="__SECRET QUEST INITIATED__",
            value=(
                "Congratulations! You have been chosen to undertake a "
                "**classified mission** as a **Hunter**."
            ),
            inline=False,
        )
        embed.add_field(
            name="__Startup Rewards__",
            value=(
                f"▶ Obtained **{START_COINS:,}** {GOLD_EMOJI}\n"
                f"▶ Obtained **{START_DIAMONDS}** {DIAMOND_EMOJI}\n"
                f"▶ Obtained **{START_TICKETS}** {TICKET_EMOJI} Gate Keys"
            ),
            inline=False,
        )
        embed.add_field(
            name="〔 HUNTER STATUS 〕",
            value="**Rank :** E-Class\n**Level :** 01",
            inline=False,
        )
        embed.add_field(
            name="\u200b",
            value=(
                "__**Your data has been recorded in the System.**__\n"
                "__**Begin your hunt.**__"
            ),
            inline=False,
        )
        embed.set_footer(text="System Notice • Survival is not guaranteed")
        await interaction.response.edit_message(embed=embed, view=None)

    @discord.ui.button(label="CANCEL", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.responded:
            return
        self.responded = True
        self.stop()

        embed = discord.Embed(
            description=(
                "**[ SYSTEM MESSAGE ]**\n\n"
                "Registration cancelled.\n\n"
                "The System does not forget those who hesitate.\n"
                "Return when you are ready, Hunter."
            ),
            color=0x3D0070,
        )
        await interaction.response.edit_message(embed=embed, view=None)

    async def on_timeout(self):
        if self.responded:
            return
        for child in self.children:
            child.disabled = True
        self.stop()

# ─────────────────────────────────────────────────────────────
#  COG
# ─────────────────────────────────────────────────────────────

class PlayerCog(commands.Cog, name="Player"):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def cog_load(self):
        _col().create_index("discord_id", unique=True)
        print("[PlayerCog] ✅ Ready.")

    # ── sl start ──────────────────────────────────────────────
    @commands.command(name="start", aliases=["register", "reg"])
    async def start(self, ctx: commands.Context):
        """Register as a Hunter."""
        if player_exists(ctx.author.id):
            p     = get_player(ctx.author.id)
            rank  = p.get("rank", "E")
            level = p.get("level", 1)
            re    = _rank_emoji(rank)
            embed = discord.Embed(
                description=(
                    f"⚠️ **{ctx.author.display_name}**, you're already a registered Hunter.\n"
                    f"{re} Rank **{rank}** · Level **{level}**\n\n"
                    f"Use `sl profile` to view your full stats."
                ),
                color=RANK_COLORS.get(rank, 0x7B2FBE),
            )
            return await ctx.send(embed=embed)

        # Build player data upfront — passed into the view so confirm can save it
        player_data = {
            "discord_id":      ctx.author.id,
            "username":        ctx.author.display_name,
            "rank":            "E",
            "level":           1,
            "xp":              0,
            "skill_points":    0,
            **BASE_STATS,
            "max_hp":          BASE_STATS["hp"],
            "max_mp":          BASE_STATS["mp"],
            "gold":            START_COINS,
            "mana_crystals":   START_DIAMONDS,
            "gate_keys":       START_TICKETS,
            "national_level":  False,
            "exam_taken_today": False,
            "exam_date":       None,
            "monsters_killed": 0,
            "gates_cleared":   0,
            "daily_streak":    0,
            "last_daily":      None,
            "awakened_at":     datetime.datetime.utcnow().strftime("%Y-%m-%d"),
        }

        embed = discord.Embed(color=0x6600CC)
        embed.set_image(url=_REGISTER_IMG)
        embed.description = (
            "The System has recognised a new candidate.\n\n"
            "You stand at the threshold of awakening — "
            "a path walked by few and survived by fewer.\n\n"
            "Strength will be tested. Limits will be broken.\n"
            "By confirming, you accept the System's judgment\n"
            "and take your first step as a **Hunter**."
        )
        embed.set_footer(text="This window will expire in 60 seconds.")

        await ctx.send(embed=embed, view=RegisterView(ctx.author, player_data))

    # ── sl profile ────────────────────────────────────────────
    @commands.command(name="profile", aliases=["pf", "p"])
    async def profile(self, ctx: commands.Context, member: discord.Member = None):
        target   = member or ctx.author
        p        = get_player(target.id)
        if not p:
            return await ctx.send(
                f"❌ **{target.display_name}** is not registered. Use `sl start`."
            )

        rank     = p.get("rank", "e")
        level    = p.get("level", 1)
        xp       = p.get("xp", 0)
        xp_next  = xp_to_next(level)
        gold     = p.get("gold", 0)
        crystals = p.get("mana_crystals", 0)
        keys     = p.get("gate_keys", 0)
        cap      = RANK_LEVEL_CAP.get(rank, 999)
        re       = _rank_emoji(rank)
        national = p.get("national_level", False)
        xp_bar   = _xp_bar(xp, xp_next)
        pct      = int(xp / xp_next * 100) if xp_next else 100
        cap_line = f"\n> ⚠️ *Level cap reached — use `sl exam` to advance*" if level >= cap else ""

        kills    = p.get("monsters_killed", 0)
        gates    = p.get("gates_cleared", 0)
        streak   = p.get("daily_streak", 0)
        awakened = p.get("awakened_at", "Unknown")

        title_tag = "  ✦ **National Level Hunter**" if national else ""

        # Skills summary line
        unlocked_skills = get_unlocked_skills(level)
        skill_line = (
            f"✦ **{len(unlocked_skills)}/4** skills unlocked"
            if unlocked_skills
            else "✦ Reach **Level 5** to unlock first skill"
        )

        embed = discord.Embed(color=RANK_COLORS.get(rank, 0x7B2FBE))
        embed.set_author(
            name=f"{target.display_name}  —  {re} {rank}-Rank Hunter{title_tag}",
            icon_url=target.display_avatar.url,
        )
        embed.set_thumbnail(url=target.display_avatar.url)

        # ── Identity ──
        embed.add_field(
            name="〔 Identity 〕",
            value=(
                f"**Level** `{level}`　**Rank** {re} `{rank}`\n"
                f"{_stat_emoji('xp')} `{xp:,} / {xp_next:,}` XP　`{pct}%`\n"
                f"`{xp_bar}`{cap_line}\n"
                f"-# {skill_line} — `sl skills`"
            ),
            inline=False,
        )

        # ── Combat Stats ──
        embed.add_field(
            name="〔 Combat Stats 〕",
            value=(
                f"{_stat_emoji('hp')} HP\n"
                f"{_stat_emoji('mp')} MP\n"
                f"{_stat_emoji('atk')} ATK\n"
                f"{_stat_emoji('def')} DEF"
            ),
            inline=True,
        )
        embed.add_field(
            name="‎",
            value=(
                f"```py\n"
                f"{p.get('hp', 0):,}\n"
                f"{p.get('mp', 0):,}\n"
                f"{p.get('atk', 0):,}\n"
                f"{p.get('def', 0):,}\n"
                f"```"
            ),
            inline=True,
        )

        # ── Secondary Stats ──
        embed.add_field(
            name="〔 Attributes 〕",
            value=(
                f"{_stat_emoji('prec')} PREC\n"
                f"{_stat_emoji('spd')} SPD\n"
                f"🏹 Kills\n"
                f"🌀 Gates"
            ),
            inline=True,
        )
        embed.add_field(
            name="‎",
            value=(
                f"```py\n"
                f"{p.get('prec', 0):,}\n"
                f"{p.get('spd', 0):,}\n"
                f"{kills:,}\n"
                f"{gates:,}\n"
                f"```"
            ),
            inline=True,
        )

        # ── Wallet ──
        embed.add_field(
            name="〔 Wallet 〕",
            value=(
                f"{_stat_emoji('gold')} **Gold**　`{gold:,}`\n"
                f"{_stat_emoji('essence')} **Essence**　`{crystals:,}`\n"
                f"{_stat_emoji('gate_key')} **Gate Keys**　`{keys}`"
            ),
            inline=False,
        )

        # ── Gate Access ──
        embed.add_field(
            name="〔 Gate Access 〕",
            value=_gate_access_str(p),
            inline=False,
        )

        exam_eligible, _ = can_take_exam(p)
        footer_parts = [f"Streak 🔥 {streak}d", f"Awakened {awakened}", "sl stats · sl exam · sl bal · sl skills"]
        if exam_eligible:
            footer_parts.insert(0, "⚡ Exam available!")
        embed.set_footer(text="  ·  ".join(footer_parts))
        await ctx.send(embed=embed)

    # ── sl stats ──────────────────────────────────────────────
    @commands.command(name="stats", aliases=["st"])
    async def stats(self, ctx: commands.Context, member: discord.Member = None):
        target = member or ctx.author
        p      = get_player(target.id)
        if not p:
            return await ctx.send("❌ Not registered. Use `sl start` to begin.")

        rank  = p.get("rank", "E")
        level = p.get("level", 1)
        re    = _rank_emoji(rank)
        kills = p.get("monsters_killed", 0)
        gates = p.get("gates_cleared", 0)
        xp    = p.get("xp", 0)
        xp_next = xp_to_next(level)
        pct   = int(xp / xp_next * 100) if xp_next else 100

        embed = discord.Embed(
            description=(
                f"**{target.display_name}**\n"
                f"{re} {rank}-Rank　·　Level `{level}`　·　{_stat_emoji('xp')} `{xp:,}/{xp_next:,}` `{pct}%`"
            ),
            color=RANK_COLORS.get(rank, 0x7B2FBE),
        )
        embed.set_author(name="〔 Hunter Status 〕", icon_url=target.display_avatar.url)
        embed.set_thumbnail(url=target.display_avatar.url)

        embed.add_field(
            name="〔 Combat 〕",
            value=(
                f"{_stat_emoji('hp')} HP\n"
                f"{_stat_emoji('mp')} MP\n"
                f"{_stat_emoji('atk')} ATK\n"
                f"{_stat_emoji('def')} DEF"
            ),
            inline=True,
        )
        embed.add_field(
            name="‎",
            value=(
                f"```py\n"
                f"{p.get('hp', 0):,}\n"
                f"{p.get('mp', 0):,}\n"
                f"{p.get('atk', 0):,}\n"
                f"{p.get('def', 0):,}\n"
                f"```"
            ),
            inline=True,
        )
        embed.add_field(
            name="〔 Agility 〕",
            value=(
                f"{_stat_emoji('prec')} PREC\n"
                f"{_stat_emoji('spd')} SPD\n"
                f"🏹 Kills\n"
                f"🌀 Gates"
            ),
            inline=True,
        )
        embed.add_field(
            name="‎",
            value=(
                f"```py\n"
                f"{p.get('prec', 0):,}\n"
                f"{p.get('spd', 0):,}\n"
                f"{kills:,}\n"
                f"{gates:,}\n"
                f"```"
            ),
            inline=True,
        )
        embed.set_footer(text="sl su <stat> <amount>  ·  e.g. sl su atk 5  ·  sl skills")
        await ctx.send(embed=embed)

    # ── sl su <stat> <n> ──────────────────────────────────────
    _STAT_ALIASES = {
        "attack": "atk", "str": "atk", "strength": "atk",
        "defense": "def", "defence": "def", "armor": "def",
        "health": "hp",
        "mana": "mp", "magic": "mp",
        "precision": "prec", "accuracy": "prec", "crit": "prec",
        "speed": "spd", "agility": "spd", "agi": "spd",
    }

    @commands.command(name="su", aliases=["statup", "invest"])
    async def stat_up(self, ctx: commands.Context, stat: str = None, amount: str = None):
        p = get_player(ctx.author.id)
        if not p:
            return await ctx.send("❌ Not registered. Use `sl start` first.")

        if not stat or not amount:
            sp = p.get("skill_points", 0)
            embed = discord.Embed(
                title="〔 Stat Allocation 〕",
                description=(
                    f"**Usage:** `sl su <stat> <amount>`\n"
                    f"**Points Available:** `{sp}`\n\n"
                    + "\n".join(
                        f"{_stat_emoji(s)} **{s.upper()}** — `+{v}` per point"
                        for s, v in STAT_BOOST.items()
                    )
                ),
                color=RANK_COLORS.get(p.get("rank","E"), 0x7B2FBE),
            )
            embed.set_footer(text="e.g.  sl su atk 10")
            return await ctx.send(embed=embed)

        stat = self._STAT_ALIASES.get(stat.lower(), stat.lower())
        if stat not in STAT_BOOST:
            return await ctx.send(
                f"❌ Invalid stat. Choose: {', '.join(f'`{s}`' for s in STAT_BOOST)}"
            )
        try:
            amount = int(amount)
            if amount <= 0:
                raise ValueError
        except ValueError:
            return await ctx.send("❌ Amount must be a positive number.")

        sp = p.get("skill_points", 0)
        if amount > sp:
            return await ctx.send(f"❌ Only **{sp} skill points** available.")

        boost = STAT_BOOST[stat] * amount
        p["skill_points"] = sp - amount
        p[stat] = p.get(stat, BASE_STATS.get(stat, 0)) + boost
        if stat == "hp":
            p["max_hp"] = p["hp"]
        if stat == "mp":
            p["max_mp"] = p["mp"]
        save_player(ctx.author.id, p)

        embed = discord.Embed(
            description=(
                f"```ansi\n\u001b[1;32m▓▓▓▓▓▓▓▓  STAT UPGRADED  ▓▓▓▓▓▓▓▓\u001b[0m\n```\n"
                f"{_stat_emoji(stat)} **{stat.upper()}** upgraded by `+{boost:,}`\n"
                f"New value: **`{p[stat]:,}`**\n\n"
                f"Points remaining: **`{p['skill_points']}`**"
            ),
            color=0x57F287,
        )
        embed.set_author(name="〔 System — Allocation Complete 〕")
        await ctx.send(embed=embed)


    # ── sl cd ─────────────────────────────────────────────────
    @commands.command(name="cd", aliases=["cooldowns", "cooldown"])
    async def cooldowns(self, ctx: commands.Context):
        import time
        p = get_player(ctx.author.id)
        if not p:
            return await ctx.send("❌ Not registered. Use `sl start` first.")

        now_dt = datetime.datetime.utcnow()
        now_ts = time.time()
        lines  = []

        # Daily
        last_daily = p.get("last_daily")
        if last_daily:
            last_dt  = datetime.datetime.fromisoformat(last_daily)
            hrs_gone = (now_dt - last_dt).total_seconds() / 3600
            rem      = max(0, DAILY_COOLDOWN_HRS - hrs_gone)
            if rem > 0:
                h, m = int(rem), int((rem % 1) * 60)
                lines.append(f"📅 **Daily Reward** — ⏳ `{h}h {m}m` remaining")
            else:
                lines.append("📅 **Daily Reward** — ✅ Ready!")
        else:
            lines.append("📅 **Daily Reward** — ✅ Ready!")

        # Exam
        eligible, reason = can_take_exam(p)
        if eligible:
            lines.append("📜 **Hunter Exam** — ✅ Ready! Use `sl exam`")
        else:
            lines.append(f"📜 **Hunter Exam** — ❌ {reason}")

        # Gate
        try:
            from cogs.main_cmds.gate_cog import gate_summon_cd, GATE_SUMMON_CD_S
            last_gate = gate_summon_cd.get(ctx.author.id, 0)
            rem = max(0, GATE_SUMMON_CD_S - (now_ts - last_gate))
            lines.append(
                f"🌀 **Gate Summon** — {'⏳ `' + str(int(rem)) + 's` remaining' if rem > 0 else '✅ Ready!'}"
            )
        except Exception:
            lines.append("🌀 **Gate Summon** — ✅ Ready!")

        streak = p.get("daily_streak", 0)
        embed  = discord.Embed(
            title=f"⏱️ {ctx.author.display_name}'s Cooldowns",
            description="\n".join(lines),
            color=0x7B2FBE,
        )
        embed.set_footer(text=f"sl daily  ·  sl exam  ·  sl profile  ·  Streak 🔥 {streak}d")
        await ctx.send(embed=embed)

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.BadArgument):
            await ctx.send(f"❌ Invalid argument: {error}", delete_after=8)
        elif isinstance(error, commands.CommandInvokeError):
            print(f"[PlayerCog] ❌ {ctx.command}: {error.original}")
            await ctx.send("⚠️ Something went wrong. Try again.", delete_after=8)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(PlayerCog(bot))
