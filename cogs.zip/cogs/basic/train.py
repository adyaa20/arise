"""
cogs/train.py — Solo Leveling Train Command
=============================================
• sl train / sl t
• 5 attempts per day, resets at midnight
• Each button maps to a training task tracked in MongoDB
• Progress shows in sl quests / sl daily
"""

import random
import logging
import time
from datetime import date

import discord
from discord.ext import commands

from database import get_player, update_player

log = logging.getLogger("train")

SL_PURPLE           = 0x7B2FBE
DAILY_ATTEMPTS      = 3          # max attempts per cooldown window
TRAIN_COOLDOWN_SECS = 300         # 5 minutes between train sessions

TRAIN_ACTIONS = [
    {"name": "Run",      "emoji": "🏃",  "stat": "spd",  "task_key": "running",  "progress": (1, 2)},
    {"name": "Pushups",  "emoji": "💪",  "stat": "atk",  "task_key": "pushups",  "progress": (3, 5)},
    {"name": "Situps",   "emoji": "🧘",  "stat": "prec", "task_key": "situps",   "progress": (3, 5)},
    {"name": "Squats",   "emoji": "🦵",  "stat": "def",  "task_key": "squats",   "progress": (3, 5)},
]

MOTIVATIONAL_QUOTES = [
    '"Keep going, Monarch!"',
    '"The weak don\'t get to choose."',
    '"Rise. There is no rest for Hunters."',
    '"Every step forward is a shadow conquered."',
    '"Pain is just the System testing your limits."',
]


class TrainView(discord.ui.View):
    def __init__(self, player: dict, invoker_id: int):
        super().__init__(timeout=60)
        self.player     = player
        self.invoker_id = invoker_id
        self.attempts   = player.get("train_attempts_today", DAILY_ATTEMPTS)
        self.message: discord.Message | None = None

        for action in TRAIN_ACTIONS:
            btn          = discord.ui.Button(
                label=action["emoji"],
                style=discord.ButtonStyle.secondary,
                custom_id=action["name"],
            )
            btn.callback = self._make_callback(action)
            self.add_item(btn)

        self._sync_buttons()

    def _sync_buttons(self):
        disabled = self.attempts <= 0
        for child in self.children:
            child.disabled = disabled

    def _make_callback(self, action: dict):
        async def callback(interaction: discord.Interaction):
            if interaction.user.id != self.invoker_id:
                return await interaction.response.send_message("❌ Not your session.", ephemeral=True)
            if self.attempts <= 0:
                return await interaction.response.send_message("❌ No attempts left today.", ephemeral=True)

            gained      = random.randint(*action["progress"])
            self.attempts -= 1
            task_key    = f"train_{action['task_key']}_today"
            current_val = self.player.get(task_key, 0) + gained
            self.player[task_key] = current_val

            # Increment stat by 1
            stat_key = action["stat"]
            new_stat = self.player.get(stat_key, 10) + 1
            self.player[stat_key] = new_stat

            update_player(self.invoker_id, {
                "train_attempts_today": self.attempts,
                "train_last_ts":        self.player.get("train_last_ts", time.time()),
                task_key:               current_val,
                stat_key:               new_stat,
            })

            self._sync_buttons()

            quote  = random.choice(MOTIVATIONAL_QUOTES)
            embed  = discord.Embed(title="Training in Progress...", color=SL_PURPLE)
            embed.description = f"🖤 *{quote}*"
            embed.add_field(
                name="\u200b",
                value=f"You performed **{action['name']}** and gained **+{gained}** progress.",
                inline=False,
            )
            embed.add_field(name="Attempts Remaining", value=str(self.attempts), inline=True)
            embed.set_footer(text="Check sl daily to see your quest progress")

            await interaction.response.edit_message(embed=embed, view=self)

        return callback

    async def on_timeout(self):
        for child in self.children:
            child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except Exception:
                pass


class TrainCog(commands.Cog, name="Train"):
    """Daily training system."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="train", aliases=["t"], help="Daily training session.")
    async def train(self, ctx: commands.Context):
        """sl train — 3 attempts per cooldown window (5 min CD). Progress tracked in sl daily."""
        player = get_player(ctx.author.id)
        if not player:
            return await ctx.send("❌ You are not registered. Use `sl start` to begin.")

        now = time.time()

        # 5-minute cooldown check
        last_train = player.get("train_last_ts", 0)
        remaining  = TRAIN_COOLDOWN_SECS - (now - last_train)
        if remaining > 0:
            mins = int(remaining // 60)
            secs = int(remaining % 60)
            cd_str = f"{mins}m {secs}s" if mins else f"{secs}s"
            embed = discord.Embed(
                title="[ SYSTEM — TRAINING COOLDOWN ]",
                description=(
                    f"⏳ You must rest before training again.\n\n"
                    f"**Cooldown:** `{cd_str}` remaining."
                ),
                color=SL_PURPLE,
            )
            return await ctx.send(embed=embed)

        # Reset attempts if cooldown has expired (new window)
        if now - last_train >= TRAIN_COOLDOWN_SECS:
            reset_fields = {
                "train_attempts_today": DAILY_ATTEMPTS,
                "train_pushups_today":  0,
                "train_squats_today":   0,
                "train_situps_today":   0,
                "train_running_today":  0,
                "train_last_ts":        now,
            }
            update_player(ctx.author.id, reset_fields)
            player.update(reset_fields)

        attempts = player.get("train_attempts_today", DAILY_ATTEMPTS)

        if attempts <= 0:
            embed = discord.Embed(
                title="[ SYSTEM — TRAINING LIMIT REACHED ]",
                description=(
                    f"You have used all **{DAILY_ATTEMPTS} training attempts** this session.\n\n"
                    "Wait for the cooldown to reset, Hunter."
                ),
                color=SL_PURPLE,
            )
            return await ctx.send(embed=embed)

        embed = discord.Embed(
            title="Training in Progress...",
            description=f"🖤 *{random.choice(MOTIVATIONAL_QUOTES)}*",
            color=SL_PURPLE,
        )
        embed.add_field(name="Attempts Remaining", value=str(attempts), inline=True)
        embed.set_footer(text="Choose a training action below  •  5 min cooldown between sessions")

        view = TrainView(player, ctx.author.id)
        view.message = await ctx.send(embed=embed, view=view)


async def setup(bot: commands.Bot):
    await bot.add_cog(TrainCog(bot))
