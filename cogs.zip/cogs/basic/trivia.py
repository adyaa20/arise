"""
cogs/trivia.py — Solo Leveling Trivia
=======================================
• sl trivia / sl tr  — random questions from ALL categories, no category shown
• Questions pulled from SQLite trivia_questions table
• Rewards: coins + exp added to MongoDB player doc
"""

import asyncio
import random
import logging

import discord
from discord.ext import commands

from database import get_random_trivia, get_trivia_count, get_player, add_exp, add_coins

log = logging.getLogger("trivia")

# ── Reward tables ────────────────────────────────────────────
GOLD_REWARDS = [200, 300, 400, 500, 600, 800, 1000]
EXP_REWARDS  = [50,  70,  100, 120, 150, 200, 250]

# ── Score flavour text ───────────────────────────────────────
SCORE_FLAVORS = {
    0: "Did you guess randomly? Because it shows...",
    1: "A shaky start. Train harder, Hunter.",
    2: "You know a little. But the shadows demand more.",
    3: "Solid performance. You know your way around the shadows.",
    4: "Impressive! The System acknowledges your knowledge.",
    5: "Perfect score! You are worthy of the Shadow Monarch's throne.",
}

OPT_EMOJIS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣"]

SL_PURPLE = 0x6600CC


def _build_question_embed(q: dict, index: int, opts: list) -> discord.Embed:
    options_text = "\n".join(f"{OPT_EMOJIS[i]}  {opts[i][1]}" for i in range(4))
    embed = discord.Embed(
        title=f"[ QUESTION {index + 1}/5 ]",
        description=f"**{q['question']}**\n\n{options_text}",
        color=SL_PURPLE,
    )
    embed.set_footer(text="React to answer • 30s remaining")
    return embed


class TriviaCog(commands.Cog, name="Trivia"):
    """Solo Leveling trivia — test your knowledge, earn rewards."""

    def __init__(self, bot: commands.Bot):
        self.bot    = bot
        self.active = {}   # discord_id → True, prevents double sessions

    @commands.command(name="trivia", aliases=["tr"], help="Start a Solo Leveling trivia session.")
    async def trivia(self, ctx: commands.Context):
        """
        sl trivia
        5 random questions from the question bank. No category shown.
        Rewards: Gold 🪙 + EXP 💠 based on score.
        """
        # ── Guard: must be registered ──────────────────
        player = get_player(ctx.author.id)
        if not player:
            return await ctx.send("❌ You are not registered. Use `sl start` to begin.")

        # ── Guard: no double session ───────────────────
        if ctx.author.id in self.active:
            return await ctx.send("❌ You already have an active trivia session!")

        # ── Guard: need at least 5 questions ──────────
        if get_trivia_count() < 5:
            return await ctx.send(
                "❌ Not enough trivia questions in the database yet. "
                "Ask an admin to add some!"
            )

        self.active[ctx.author.id] = True

        questions = get_random_trivia(5)

        # ── Intro embed ────────────────────────────────
        intro = discord.Embed(
            title="[ SYSTEM — TRIVIA INITIATED ]",
            description=(
                "**5 questions** await you, Hunter.\n\n"
                "React with 1️⃣ 2️⃣ 3️⃣ 4️⃣ to answer each question.\n"
                "You have **30 seconds** per question."
            ),
            color=SL_PURPLE,
        )
        intro.set_footer(text="Good luck, Hunter.")
        msg = await ctx.send(embed=intro)
        await asyncio.sleep(2)

        score   = 0
        answers = []

        # ── Question loop ──────────────────────────────
        for i, q in enumerate(questions):
            opts = [
                ("A", q["option_a"]),
                ("B", q["option_b"]),
                ("C", q["option_c"]),
                ("D", q["option_d"]),
            ]
            random.shuffle(opts)
            correct_index = next(idx for idx, (letter, _) in enumerate(opts) if letter == q["answer"])

            await msg.edit(embed=_build_question_embed(q, i, opts))

            try:
                await msg.clear_reactions()
            except Exception:
                pass

            for emoji in OPT_EMOJIS:
                await msg.add_reaction(emoji)

            def check(reaction, user):
                return (
                    user.id == ctx.author.id
                    and reaction.message.id == msg.id
                    and str(reaction.emoji) in OPT_EMOJIS
                )

            try:
                reaction, _ = await self.bot.wait_for("reaction_add", timeout=30.0, check=check)
                chosen_index = OPT_EMOJIS.index(str(reaction.emoji))
                is_correct   = chosen_index == correct_index
            except asyncio.TimeoutError:
                is_correct = False

            if is_correct:
                score += 1
                answers.append("C")
            else:
                answers.append("X")

            await asyncio.sleep(0.8)

        # ── Clear reactions ────────────────────────────
        try:
            await msg.clear_reactions()
        except Exception:
            pass

        # ── Rewards ────────────────────────────────────
        gold = random.choice(GOLD_REWARDS) * (score + 1)
        exp  = random.choice(EXP_REWARDS)  * (score + 1)

        add_coins(ctx.author.id, gold)
        add_exp(ctx.author.id, exp)

        # ── Result embed ───────────────────────────────
        result_icons = " | ".join("☑️" if a == "C" else "❌" for a in answers)
        flavor       = SCORE_FLAVORS.get(score, "")

        final = discord.Embed(
            title="[ TRIVIA COMPLETE ]",
            description=flavor,
            color=SL_PURPLE,
        )
        final.add_field(
            name="\u200b",
            value=f"You got **{score}/5** correct!\nResults: {result_icons}",
            inline=False,
        )
        final.add_field(
            name="Rewards",
            value=f"🪙 **+{gold}** Gold\n💠 **+{exp}** Experience",
            inline=False,
        )
        await msg.edit(embed=final)
        self.active.pop(ctx.author.id, None)

    @trivia.error
    async def trivia_error(self, ctx, error):
        log.exception("Trivia error:", exc_info=error)
        await ctx.send("❌ Something went wrong with trivia. Try again.")
        self.active.pop(ctx.author.id, None)


async def setup(bot: commands.Bot):
    await bot.add_cog(TriviaCog(bot))
