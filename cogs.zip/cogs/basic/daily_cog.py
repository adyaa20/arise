"""
cogs/daily_cog.py — Daily Rewards & Balance
=============================================
Commands:
  sl daily    — claim daily reward (streak bonuses)
  sl balance  — wallet (gold, essence, gate keys)
"""

import discord
from discord.ext import commands
import datetime

from cogs.player.player_cog import (
    get_player, save_player,
    RANK_COLORS, DAILY_GOLD, DAILY_ESSENCE, DAILY_COOLDOWN_HRS,
    _stat_emoji,
)


class DailyCog(commands.Cog, name="Daily"):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ── sl daily ──────────────────────────────────────────────
    @commands.command(name="daily", aliases=["d"])
    async def daily(self, ctx: commands.Context):
        """Claim your daily reward. Streak bonuses apply."""
        p = get_player(ctx.author.id)
        if not p:
            return await ctx.send("❌ Not registered. Use `sl start` first.")

        now      = datetime.datetime.utcnow()
        last_str = p.get("last_daily")
        streak   = p.get("daily_streak", 0)

        if last_str:
            last_dt = datetime.datetime.fromisoformat(last_str)
            hrs_ago = (now - last_dt).total_seconds() / 3600
            if hrs_ago < DAILY_COOLDOWN_HRS:
                rem  = DAILY_COOLDOWN_HRS - hrs_ago
                h, m = int(rem), int((rem % 1) * 60)
                return await ctx.send(embed=discord.Embed(
                    description=f"⏳ Daily already claimed!\nNext reward in **{h}h {m}m**.",
                    color=0xFF4444,
                ))
            streak = 0 if hrs_ago > 48 else streak + 1
        else:
            streak = 1

        mult      = 1 + min(streak - 1, 6) * 0.15
        gold      = int(DAILY_GOLD * mult)
        essence   = int(DAILY_ESSENCE * mult)
        key_bonus = (streak % 7 == 0)

        p["gold"]          = p.get("gold", 0) + gold
        p["mana_crystals"] = p.get("mana_crystals", 0) + essence
        p["daily_streak"]  = streak
        p["last_daily"]    = now.isoformat()
        if key_bonus:
            p["gate_keys"] = p.get("gate_keys", 0) + 1
        save_player(ctx.author.id, p)

        fire     = "🔥" * min(streak, 7)
        key_line = f"\n{_stat_emoji('gate_key')} **+1 Gate Key**" if key_bonus else ""
        next_str = f"Day **{min(streak+1,7)}**" if streak < 7 else "Day **7** *(max)*"

        embed = discord.Embed(
            description=(
                f"```ansi\n\u001b[1;33m▓▓▓▓▓  DAILY REWARD  ▓▓▓▓▓\u001b[0m\n```"
            ),
            color=0xF1A800,
        )
        embed.set_author(
            name=f"{ctx.author.display_name}  —  Daily Claimed",
            icon_url=ctx.author.display_avatar.url,
        )
        embed.add_field(
            name=f"〔 Streak {fire} 〕",
            value=f"Day **{streak}**　·　`×{mult:.2f}` bonus\nNext: {next_str}",
            inline=False,
        )
        embed.add_field(
            name="〔 Rewards 〕",
            value=(
                f"{_stat_emoji('gold')} **+{gold:,}** Gold\n"
                f"{_stat_emoji('essence')} **+{essence}** Essence"
                f"{key_line}"
            ),
            inline=False,
        )
        embed.set_footer(text="Come back tomorrow to keep your streak!")
        await ctx.send(embed=embed)

    # ── sl balance ────────────────────────────────────────────
    @commands.command(name="balance", aliases=["bal", "wallet"])
    async def balance(self, ctx: commands.Context, member: discord.Member = None):
        target = member or ctx.author
        p      = get_player(target.id)
        if not p:
            return await ctx.send(f"❌ **{target.display_name}** is not registered.")

        rank = p.get("rank", "E")
        embed = discord.Embed(color=RANK_COLORS.get(rank, 0x7B2FBE))
        embed.set_author(
            name=f"{target.display_name}  —  Wallet",
            icon_url=target.display_avatar.url,
        )
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(
            name="〔 Currency 〕",
            value=(
                f"{_stat_emoji('gold')} **Gold**\n"
                f"╰ `{p.get('gold', 0):,}`\n\n"
                f"{_stat_emoji('essence')} **Essence**\n"
                f"╰ `{p.get('mana_crystals', 0):,}`"
            ),
            inline=True,
        )
        embed.add_field(
            name="〔 Items 〕",
            value=(
                f"{_stat_emoji('gate_key')} **Gate Keys**\n"
                f"╰ `{p.get('gate_keys', 0)}`"
            ),
            inline=True,
        )
        embed.set_footer(text="sl profile  ·  sl daily  ·  sl cd")
        await ctx.send(embed=embed)

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CommandInvokeError):
            print(f"[DailyCog] ❌ {ctx.command}: {error.original}")
            await ctx.send("⚠️ Something went wrong. Try again.", delete_after=8)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(DailyCog(bot))
