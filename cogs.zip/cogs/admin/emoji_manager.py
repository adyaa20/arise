"""
cogs/admin/emoji_manager.py — Emoji Manager Cog
=================================================
Commands (all admin-only):
  sl ea <name> <emoji/link>  — Add emoji  (saves to DB + emojis.json)
  sl er <name>               — Remove emoji (removes from DB + emojis.json)
  sl ep <name>               — Preview emoji
  sl el                      — List all emojis (paginated, purple embed)

emojis.json is auto-created / auto-synced next to this bot.
All cog files load emojis from emojis.json via load_emoji_json() / get_emoji_json().
"""

import json
import logging
from pathlib import Path

import discord
from discord.ext import commands

from database import sqlite_conn
from cogs.admin.admin import is_bot_admin

log = logging.getLogger("emoji_manager")

# ─────────────────────────────────────────────────────────────
# emojis.json path  (same directory as bot.py / project root)
# ─────────────────────────────────────────────────────────────
EMOJI_JSON_PATH = Path(__file__).resolve().parent.parent.parent / "emojis.json"


# ─────────────────────────────────────────────────────────────
# JSON helpers  (used by this file AND importable by all cogs)
# ─────────────────────────────────────────────────────────────

def load_emoji_json() -> dict:
    """Load the full emojis.json dict. Returns {} if file missing."""
    if EMOJI_JSON_PATH.exists():
        try:
            with EMOJI_JSON_PATH.open("r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:
            log.warning("Failed to read emojis.json: %s", exc)
    return {}


def save_emoji_json(data: dict) -> None:
    """Overwrite emojis.json with the given dict (sorted keys)."""
    try:
        EMOJI_JSON_PATH.parent.mkdir(parents=True, exist_ok=True)
        with EMOJI_JSON_PATH.open("w", encoding="utf-8") as f:
            json.dump(dict(sorted(data.items())), f, indent=2, ensure_ascii=False)
    except Exception as exc:
        log.error("Failed to write emojis.json: %s", exc)


def get_emoji_json(name: str) -> dict | None:
    """
    Convenience helper for cogs.
    Returns the emoji entry dict  {emoji_str, is_custom, is_link}  or None.
    """
    return load_emoji_json().get(name.lower())


def get_emoji(name: str) -> str | None:
    """
    Convenience helper — returns the raw emoji_str string from emojis.json,
    or None if not found.  Use this wherever you only need the stored value
    (e.g. image URLs, unicode emoji, raw custom-emoji IDs).
    """
    entry = load_emoji_json().get(name.lower())
    return entry["emoji_str"] if entry else None


def _sync_json_from_db() -> None:
    """
    Full sync: pull every row from the SQLite emojis table and write
    them all to emojis.json.  Called on cog load AND after every
    add/remove so the JSON is always perfectly in sync with the DB.
    """
    try:
        rows = _db_all()
        data = {
            row["name"]: {
                "emoji_str": row["emoji_str"],
                "is_custom": bool(row["is_custom"]),
                "is_link":   bool(row["is_link"]),
            }
            for row in rows
        }
        save_emoji_json(data)
        log.info("emojis.json synced from DB — %d entries.", len(data))
    except Exception as exc:
        log.error("_sync_json_from_db failed: %s", exc)


# Solo Leveling purple palette
SL_PURPLE       = 0x7B2FBE
SL_PURPLE_DARK  = 0x4B0082
SL_PURPLE_LIGHT = 0x9B59B6


# ─────────────────────────────────────────────────────────────
# Auth helpers
# ─────────────────────────────────────────────────────────────
def admin_check():
    async def predicate(ctx: commands.Context):
        if not is_bot_admin(ctx.author.id):
            raise commands.CheckFailure()
        return True
    return commands.check(predicate)


# ─────────────────────────────────────────────────────────────
# DB helpers
# ─────────────────────────────────────────────────────────────
def _db_add(name: str, emoji_str: str, is_custom: int, is_link: int) -> None:
    with sqlite_conn() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO emojis (name, emoji_str, is_custom, is_link) VALUES (?, ?, ?, ?)",
            (name.lower(), emoji_str, is_custom, is_link),
        )


def _db_remove(name: str) -> bool:
    with sqlite_conn() as conn:
        cur = conn.execute("DELETE FROM emojis WHERE name = ?", (name.lower(),))
    return cur.rowcount > 0


def _db_get(name: str):
    with sqlite_conn() as conn:
        return conn.execute(
            "SELECT name, emoji_str, is_custom, is_link FROM emojis WHERE name = ?",
            (name.lower(),),
        ).fetchone()


def _db_all():
    with sqlite_conn() as conn:
        return conn.execute(
            "SELECT name, emoji_str, is_custom, is_link FROM emojis ORDER BY name"
        ).fetchall()


def _db_exists(name: str) -> bool:
    with sqlite_conn() as conn:
        return conn.execute(
            "SELECT 1 FROM emojis WHERE name = ?", (name.lower(),)
        ).fetchone() is not None


def _ensure_schema():
    """Add is_link / is_custom columns if missing (migration safety)."""
    try:
        with sqlite_conn() as conn:
            cols = [r[1] for r in conn.execute("PRAGMA table_info(emojis)").fetchall()]
            if "is_custom" not in cols:
                conn.execute("ALTER TABLE emojis ADD COLUMN is_custom INTEGER DEFAULT 0")
            if "is_link" not in cols:
                conn.execute("ALTER TABLE emojis ADD COLUMN is_link INTEGER DEFAULT 0")
    except Exception as exc:
        log.warning("Schema migration failed: %s", exc)


# ─────────────────────────────────────────────────────────────
# Display helper — resolves any stored value → display string
# ─────────────────────────────────────────────────────────────
def _resolve_display(bot: commands.Bot, emoji_str: str, is_custom: int, is_link: int) -> str:
    """Return the best display string for an emoji row."""
    if is_link:
        return emoji_str          # raw URL — used in embed image/thumbnail

    if is_custom:
        # New format: already stored as <:name:id> or <a:name:id> — render directly
        if emoji_str.startswith("<") and emoji_str.endswith(">"):
            return emoji_str
        # Legacy fallback: bare numeric ID stored by old code
        try:
            eid = int(emoji_str)
            e = discord.utils.get(bot.emojis, id=eid)
            return str(e) if e else f"`{emoji_str}`"
        except Exception:
            return f"`{emoji_str}`"

    return emoji_str              # unicode


# ─────────────────────────────────────────────────────────────
# Pagination view  (sl el)
# ─────────────────────────────────────────────────────────────
class EmojiListView(discord.ui.View):
    PER_PAGE = 20

    def __init__(self, rows: list, bot: commands.Bot, user_id: int):
        super().__init__(timeout=120)
        self.rows        = rows
        self.bot         = bot
        self.user_id     = user_id
        self.page        = 0
        self.total_pages = max(1, (len(rows) + self.PER_PAGE - 1) // self.PER_PAGE)
        self.message: discord.Message | None = None
        self._sync_buttons()

    def _sync_buttons(self):
        self.btn_prev.disabled = self.page == 0
        self.btn_next.disabled = self.page >= self.total_pages - 1

    def _build_embed(self) -> discord.Embed:
        embed = discord.Embed(
            title="<:_:0> ✦  Emoji Vault  ✦",
            description=f"*All stored bot emojis — Page {self.page + 1} of {self.total_pages}*",
            color=SL_PURPLE,
        )
        embed.set_author(name="Solo Leveling Bot  •  Emoji Manager")

        start = self.page * self.PER_PAGE
        slice_ = self.rows[start : start + self.PER_PAGE]

        for row in slice_:
            name, emoji_str, is_custom, is_link = (
                row["name"], row["emoji_str"], row["is_custom"], row["is_link"]
            )
            if is_link:
                value = "🔗 `[image link]`"
            else:
                value = _resolve_display(self.bot, emoji_str, is_custom, is_link)

            embed.add_field(
                name=f"`{name}` • `{emoji_str}`",
                value=value,
                inline=True,
            )

        embed.set_footer(
            text=f"Total emojis: {len(self.rows)}  •  Use 'sl ep <name>' to preview"
        )
        return embed

    async def send(self, ctx: commands.Context):
        self.message = await ctx.send(embed=self._build_embed(), view=self)

    @discord.ui.button(label="◀ Prev", style=discord.ButtonStyle.secondary)
    async def btn_prev(self, interaction: discord.Interaction, _btn):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("❌ Not your menu.", ephemeral=True)
        self.page -= 1
        self._sync_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="Next ▶", style=discord.ButtonStyle.secondary)
    async def btn_next(self, interaction: discord.Interaction, _btn):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("❌ Not your menu.", ephemeral=True)
        self.page += 1
        self._sync_buttons()
        await interaction.response.edit_message(embed=self._build_embed(), view=self)

    async def on_timeout(self):
        for child in self.children:
            child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────
# Cog
# ─────────────────────────────────────────────────────────────
class EmojiManager(commands.Cog, name="Emoji Manager"):
    """Manage emojis stored in the bot database (admin only)."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        _ensure_schema()
        # Sync DB → emojis.json on every startup so the file is always fresh
        _sync_json_from_db()

    # ── sl emigrate  ──────────────────────────────────────
    @commands.command(name="emigrate", help="Migrate legacy bare emoji IDs to <:name:id> format.")
    @admin_check()
    async def emoji_migrate(self, ctx: commands.Context):
        """
        sl emigrate — One-time fix for emojis stored as bare IDs (old format).
        Converts them to <:name:id> so they render everywhere.
        """
        rows = _db_all()
        fixed = 0
        skipped = 0
        failed = []

        # Build a flat lookup of all emojis the bot can see across all guilds
        all_bot_emojis = {e.id: e for e in self.bot.emojis}

        for row in rows:
            name, emoji_str, is_custom, is_link = (
                row["name"], row["emoji_str"], row["is_custom"], row["is_link"]
            )
            # Only process custom emojis stored as bare numeric IDs
            if not is_custom or is_link:
                skipped += 1
                continue
            if emoji_str.startswith("<") and emoji_str.endswith(">"):
                skipped += 1
                continue  # already in correct format
            if not emoji_str.isdigit():
                skipped += 1
                continue

            # Look up in cache first, then try fetching from each guild
            eid = int(emoji_str)
            e = all_bot_emojis.get(eid)

            if e is None:
                # Cache miss — try fetching from each guild the bot is in
                for guild in self.bot.guilds:
                    try:
                        e = await guild.fetch_emoji(eid)
                        if e:
                            break
                    except Exception:
                        continue

            if e:
                prefix = "<a" if e.animated else "<"
                new_str = f"{prefix}:{e.name}:{e.id}>"
                _db_add(name, new_str, 1, 0)
                fixed += 1
            else:
                failed.append(f"{name} (ID: {emoji_str})")

        _sync_json_from_db()

        embed = discord.Embed(title="🔧  Emoji Migration Complete", color=SL_PURPLE)
        embed.add_field(name="✅ Fixed", value=str(fixed), inline=True)
        embed.add_field(name="⏭️ Skipped", value=str(skipped), inline=True)
        embed.add_field(name="❌ Failed", value=str(len(failed)) if failed else "None", inline=True)
        if failed:
            embed.add_field(
                name="⚠️ Could Not Resolve",
                value="\n".join(f"`{n}`" for n in failed) or "—",
                inline=False,
            )
        embed.set_footer(text="emojis.json re-synced after migration")
        await ctx.send(embed=embed)

    # ── sl esync  ─────────────────────────────────────────
    @commands.command(name="esync", help="Force sync DB → emojis.json (admin only).")
    @admin_check()
    async def emoji_sync(self, ctx: commands.Context):
        """sl esync  — manually rebuild emojis.json from the database."""
        _sync_json_from_db()
        data = load_emoji_json()
        embed = discord.Embed(
            description=f"✅ Synced! `emojis.json` me ab **{len(data)}** emojis hain.",
            color=SL_PURPLE,
        )
        embed.set_footer(text="DB → emojis.json full sync complete")
        await ctx.send(embed=embed)

    # ── sl ea  ────────────────────────────────────────────
    @commands.command(name="ea", help="Add an emoji or image link to the database.")
    @admin_check()
    async def emoji_add(self, ctx: commands.Context, name: str, value: str):
        """
        sl ea <name> <emoji | custom_emoji | image_url>

        Examples:
          sl ea sword ⚔️
          sl ea mana <:mana:1234567890>
          sl ea banner https://i.imgur.com/abc.png
        """
        if _db_exists(name):
            return await ctx.send(
                f"❌ `{name}` already exists. Use `sl er {name}` to remove it first."
            )

        is_custom = 0
        is_link   = 0
        store     = value   # what gets saved

        # ── Detect type ──────────────────────────────────
        if value.startswith("http://") or value.startswith("https://"):
            is_link = 1

        elif value.isdigit():
            # Raw emoji ID — fetch to get the name, then store as <:name:id>
            try:
                e = await self.bot.fetch_emoji(int(value))
                prefix = "<a" if e.animated else "<"
                store     = f"{prefix}:{e.name}:{e.id}>"
                is_custom = 1
            except Exception:
                return await ctx.send("❌ Emoji ID not found or bot can't access it.")

        elif value.startswith("<") and value.endswith(">"):
            # <:name:id> or <a:name:id>
            parts = value.split(":")
            if len(parts) < 3:
                return await ctx.send("❌ Invalid custom emoji format. Expected `<:name:id>`.")
            store     = value   # store the full <:name:id> string — Discord renders it directly
            is_custom = 1

        # else: unicode emoji — store as-is

        try:
            _db_add(name, store, is_custom, is_link)
        except Exception as exc:
            return await ctx.send(f"❌ DB error: {exc}")

        # ── Sync entire DB → emojis.json (guarantees nothing is missed) ──
        _sync_json_from_db()
        total_count = len(load_emoji_json())

        # ── Build confirmation embed ─────────────────────
        emoji_type = "🖼️ Link" if is_link else ("⚙️ Custom" if is_custom else "🔤 Unicode")

        embed = discord.Embed(
            title="✅  Emoji Added Successfully",
            color=SL_PURPLE,
        )
        embed.set_author(name="Solo Leveling Bot  •  Emoji Manager")

        embed.add_field(name="📛  Name",  value=f"`{name.lower()}`", inline=True)
        embed.add_field(name="🏷️  Type",  value=emoji_type,          inline=True)
        embed.add_field(name="💾  Stored Value", value=f"`{store}`", inline=True)

        if is_link:
            embed.add_field(name="🔗  URL", value=value, inline=False)
            embed.set_thumbnail(url=value)
        else:
            display = _resolve_display(self.bot, store, is_custom, is_link)
            embed.add_field(name="👁️  Preview", value=display, inline=True)

        embed.add_field(
            name="📂  emojis.json",
            value=f"✅ Updated in real-time — **{total_count}** emojis total",
            inline=False,
        )

        embed.set_footer(text="✨ Added to DB  •  emojis.json synced  •  Ready to use")
        await ctx.send(embed=embed)

    # ── sl er  ────────────────────────────────────────────
    @commands.command(name="er", help="Remove an emoji from the database.")
    @admin_check()
    async def emoji_remove(self, ctx: commands.Context, name: str):
        """sl er <name>"""
        if _db_remove(name):
            # ── Sync entire DB → emojis.json ────────────
            _sync_json_from_db()
            total_count = len(load_emoji_json())

            embed = discord.Embed(
                title="🗑️  Emoji Removed",
                color=SL_PURPLE_DARK,
            )
            embed.set_author(name="Solo Leveling Bot  •  Emoji Manager")
            embed.add_field(name="📛  Name", value=f"`{name.lower()}`", inline=True)
            embed.add_field(
                name="📂  emojis.json",
                value=f"✅ Updated in real-time — **{total_count}** emojis remaining",
                inline=False,
            )
            embed.set_footer(text="✨ Removed from DB  •  emojis.json synced")
            await ctx.send(embed=embed)
        else:
            await ctx.send(f"❌ No emoji named `{name}` found.")

    # ── sl ep  ────────────────────────────────────────────
    @commands.command(name="ep", help="Preview a stored emoji.")
    @admin_check()
    async def emoji_preview(self, ctx: commands.Context, name: str):
        """sl ep <name>"""
        row = _db_get(name)
        if not row:
            return await ctx.send(f"❌ Emoji `{name}` not found. Use `sl el` to see all.")

        r_name, emoji_str, is_custom, is_link = (
            row["name"], row["emoji_str"], row["is_custom"], row["is_link"]
        )

        embed = discord.Embed(
            title=f"🔍  Preview  —  `{r_name}`",
            color=SL_PURPLE_LIGHT,
        )

        if is_link:
            embed.description = f"🖼️ **Image Link**\n{emoji_str}"
            embed.set_image(url=emoji_str)
            embed.add_field(name="Type", value="Link / Image URL", inline=True)
        else:
            display = _resolve_display(self.bot, emoji_str, is_custom, is_link)
            embed.description = f"## {display}"
            embed.add_field(name="Stored Value", value=f"`{emoji_str}`", inline=True)
            embed.add_field(name="Type", value="⚙️ Custom" if is_custom else "🔤 Unicode", inline=True)

        embed.set_footer(text=f"sl er {r_name}  to remove  •  sl el  to list all")
        await ctx.send(embed=embed)

    # ── sl el  ────────────────────────────────────────────
    @commands.command(name="el", help="List all stored emojis.")
    @admin_check()
    async def emoji_list(self, ctx: commands.Context):
        """sl el"""
        rows = _db_all()
        if not rows:
            embed = discord.Embed(
                description="📭  No emojis stored yet. Use `sl ea` to add one.",
                color=SL_PURPLE,
            )
            return await ctx.send(embed=embed)

        view = EmojiListView(rows, self.bot, ctx.author.id)
        await view.send(ctx)


async def setup(bot: commands.Bot):
    await bot.add_cog(EmojiManager(bot))
