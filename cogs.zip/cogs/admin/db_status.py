"""
cogs/admin/db_status.py — Database Status Cog
===============================================
Admin-only command to ping both SQLite and MongoDB Atlas.
Reports connection status, latency, and basic collection counts.
"""

import time
import logging
import discord
from discord.ext import commands

from database import MongoDB, sqlite_conn, SQLITE_PATH
from cogs.admin.admin import is_bot_admin

log = logging.getLogger("db_status")



class DBStatus(commands.Cog, name="DB Status"):
    """Database health and diagnostic tools."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="dbstatus", aliases=["dbping", "dbcheck"], help="Check database connection status.")
    async def db_status(self, ctx: commands.Context):
        """
        Pings both SQLite and MongoDB Atlas.
        Admin only.
        Usage: sldbstatus
        """
        if not is_bot_admin(ctx.author.id):
            return await ctx.send("🚫 Admins only.")

        embed = discord.Embed(
            title="🗄️  Database Status",
            color=0x7B2FBE,
        )

        # ── SQLite ping ──────────────────────────────────────
        sqlite_status = "❓ Unknown"
        sqlite_detail = ""
        try:
            t0 = time.perf_counter()
            with sqlite_conn() as conn:
                tables = conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
                row_counts = {}
                for (tname,) in tables:
                    cnt = conn.execute(f"SELECT COUNT(*) FROM [{tname}]").fetchone()[0]
                    row_counts[tname] = cnt
            sqlite_latency = (time.perf_counter() - t0) * 1000
            sqlite_status  = "✅ Online"
            table_lines    = "\n".join(f"  `{t}` — {c} rows" for t, c in row_counts.items())
            sqlite_detail  = f"**File:** `{SQLITE_PATH}`\n**Latency:** `{sqlite_latency:.2f}ms`\n**Tables:**\n{table_lines or '  *(none)*'}"
        except Exception as exc:
            sqlite_status = "❌ Error"
            sqlite_detail = f"```{exc}```"

        embed.add_field(
            name=f"SQLite  {sqlite_status}",
            value=sqlite_detail or "*(no detail)*",
            inline=False,
        )

        # ── MongoDB ping ─────────────────────────────────────
        mongo_status = "❓ Unknown"
        mongo_detail = ""
        try:
            t0 = time.perf_counter()
            MongoDB.connect()
            MongoDB._client.admin.command("ping")
            mongo_latency = (time.perf_counter() - t0) * 1000

            db    = MongoDB._client[MongoDB._client.list_database_names()[0]]
            db    = MongoDB._client["sample_mflix"]
            colls = db.list_collection_names()
            clines = [f"  `{c}` — {db[c].estimated_document_count()} docs" for c in sorted(colls)]

            mongo_status = "✅ Online"
            mongo_detail = (
                f"**DB:** `{db.name}`\n"
                f"**Latency:** `{mongo_latency:.2f}ms`\n"
                f"**Collections:**\n"
                + ("\n".join(clines) if clines else "  *(empty)*")
            )
        except Exception as exc:
            mongo_status = "❌ Error"
            mongo_detail = f"```{exc}```"

        embed.add_field(
            name=f"MongoDB Atlas  {mongo_status}",
            value=mongo_detail or "*(no detail)*",
            inline=False,
        )

        embed.set_footer(text=f"Requested by {ctx.author.display_name}")
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(DBStatus(bot))
