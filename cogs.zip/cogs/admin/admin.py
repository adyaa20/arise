import discord
from discord.ext import commands
import os
import json
import aiohttp

from database import get_player, update_player, delete_player, MongoDB

BALANCE_ITEMS = {"gold", "mana_crystals", "gate_keys"}
CRATE_ITEMS   = {"weapon_crate"}
CUBE_ITEMS    = {"water_cube", "fire_cube", "dark_cube", "light_cube", "wind_cube"}
GEAR_ITEMS    = {"enchant_gear_1", "enchant_gear_2", "enchant_gear_3"}
ALL_ITEMS     = BALANCE_ITEMS | CUBE_ITEMS | GEAR_ITEMS | CRATE_ITEMS

IMG_DIR           = os.path.join(os.path.dirname(__file__), "..", "assets")
REGISTER_IMG_PATH = os.path.join(IMG_DIR, "register.png")
JINWOO_IMG_PATH   = os.path.join(IMG_DIR, "jinwoo.png")
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "config.json")

# ── Admin ID helpers ──────────────────────────────────────────────────────────

OWNER_IDS: set[int] = {942301877784150056}


def _load_admin_ids() -> set[int]:
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r") as f:
            data = json.load(f)
        return set(data.get("admin_ids", []))
    return set()


def _save_admin_ids(ids: set[int]):
    # Read existing config first so we don't wipe other keys
    data = {}
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r") as f:
            data = json.load(f)
    data["admin_ids"] = list(ids)
    os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
    with open(CONFIG_PATH, "w") as f:
        json.dump(data, f, indent=2)


# ADMIN_IDS is the live mutable set — all mutations go here
ADMIN_IDS: set[int] = _load_admin_ids() | OWNER_IDS


def _refresh_admin_ids() -> None:
    """Reload admin IDs from disk and merge into the live set.
    Call this on bot startup to ensure saved IDs from config.json are loaded."""
    ADMIN_IDS.clear()
    ADMIN_IDS.update(_load_admin_ids() | OWNER_IDS)


def _is_admin(user: discord.Member) -> bool:
    """Return True if user is in the live ADMIN_IDS set."""
    return user.id in ADMIN_IDS


def is_bot_admin(user_id: int) -> bool:
    """Public helper — always reads from the live ADMIN_IDS set.
    Import this in other cogs instead of duplicating admin logic."""
    return user_id in ADMIN_IDS


async def save_attachment(attachment: discord.Attachment, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    async with aiohttp.ClientSession() as session:
        async with session.get(attachment.url) as resp:
            if resp.status == 200:
                with open(path, "wb") as f:
                    f.write(await resp.read())


# ── Cog ───────────────────────────────────────────────────────────────────────

class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_check(self, ctx: commands.Context) -> bool:
        if is_bot_admin(ctx.author.id):
            return True
        await ctx.send("❌ You don't have permission to use admin commands.")
        return False

    # ── Group ─────────────────────────────────────────────────────────────────

    @commands.group(name="admin", invoke_without_command=True)
    async def admin(self, ctx: commands.Context):
        """Admin commands."""
        await ctx.send_help(ctx.command)

    # ── Admin management ──────────────────────────────────────────────────────

    @admin.command(name="add")
    async def admin_add(self, ctx: commands.Context, member: discord.Member):
        """Add a user as bot admin. Usage: sl admin add @user  OR  sl aa @user"""
        if ctx.author.id not in OWNER_IDS:
            await ctx.send("❌ Only the bot owner can add new admins.")
            return

        if member.id in ADMIN_IDS:
            await ctx.send(f"⚠️ {member.mention} is already an admin.")
            return

        ADMIN_IDS.add(member.id)
        _save_admin_ids(ADMIN_IDS - OWNER_IDS)

        embed = discord.Embed(
            title="[ SYSTEM — ADMIN GRANTED ]",
            description=f"✅ {member.mention} (`{member.name}`) has been added as a bot admin.",
            color=0x6600CC,
        )
        await ctx.send(embed=embed)

    @commands.command(name="aa")
    async def shortcut_admin_add(self, ctx: commands.Context, member: discord.Member):
        """Shortcut: add a user as bot admin. Usage: sl aa @user"""
        if not is_bot_admin(ctx.author.id):
            return await ctx.send("❌ You don't have permission to use admin commands.")
        await ctx.invoke(self.admin_add, member=member)

    @admin.command(name="remove")
    async def admin_remove(self, ctx: commands.Context, member: discord.Member):
        """Remove a user's bot admin status. Usage: sl admin remove @user"""
        if ctx.author.id not in OWNER_IDS:
            await ctx.send("❌ Only the bot owner can remove admins.")
            return

        if member.id in OWNER_IDS:
            await ctx.send("❌ Cannot remove the bot owner from admins.")
            return

        if member.id not in ADMIN_IDS:
            await ctx.send(f"⚠️ {member.mention} is not a bot admin.")
            return

        ADMIN_IDS.discard(member.id)
        _save_admin_ids(ADMIN_IDS - OWNER_IDS)

        embed = discord.Embed(
            title="[ SYSTEM — ADMIN REMOVED ]",
            description=f"✅ {member.mention} (`{member.name}`) has been removed from bot admins.",
            color=0x6600CC,
        )
        await ctx.send(embed=embed)

    @admin.command(name="list")
    async def admin_list(self, ctx: commands.Context):
        """List all bot admins. Usage: sl admin list  OR  sl al"""
        lines = []
        for uid in ADMIN_IDS:
            member = ctx.guild.get_member(uid)
            tag = f"• **{member.name}** (`{uid}`)" if member else f"• *Unknown* (`{uid}`)"
            if uid in OWNER_IDS:
                tag += " 👑"
            lines.append(tag)

        embed = discord.Embed(
            title="[ SYSTEM — BOT ADMIN LIST ]",
            description="\n".join(lines) if lines else "No admins configured.",
            color=0x6600CC,
        )
        embed.set_footer(text=f"{len(ADMIN_IDS)} admin(s) • Does not include Discord server administrators")
        await ctx.send(embed=embed)

    @commands.command(name="al")
    async def shortcut_admin_list(self, ctx: commands.Context):
        """Shortcut: list all bot admins. Usage: sl al"""
        if not is_bot_admin(ctx.author.id):
            return await ctx.send("❌ You don't have permission to use admin commands.")
        await ctx.invoke(self.admin_list)

    # ── Image uploads ─────────────────────────────────────────────────────────

    @admin.command(name="registration")
    async def set_registration(self, ctx: commands.Context):
        """Set the registration popup image. Attach image to this command."""
        if not ctx.message.attachments:
            return await ctx.send("❌ Please attach an image.")

        att = ctx.message.attachments[0]
        if not att.content_type or not att.content_type.startswith("image"):
            return await ctx.send("❌ Attachment must be an image.")

        msg = await ctx.send("⏳ Saving registration image...")
        await save_attachment(att, REGISTER_IMG_PATH)

        embed = discord.Embed(
            title="[ SYSTEM — IMAGE UPDATED ]",
            description="✅ Registration image saved!\nUse `sl admin restart` to apply.",
            color=0x6600CC,
        )
        embed.set_image(url="attachment://register.png")
        await msg.edit(content=None, embed=embed)
        await ctx.send("Preview:", file=discord.File(REGISTER_IMG_PATH, filename="register.png"))

    @admin.command(name="jinwoo")
    async def set_jinwoo(self, ctx: commands.Context):
        """Set the Jin-woo image. Attach image to this command."""
        if not ctx.message.attachments:
            return await ctx.send("❌ Please attach an image.")

        att = ctx.message.attachments[0]
        if not att.content_type or not att.content_type.startswith("image"):
            return await ctx.send("❌ Attachment must be an image.")

        msg = await ctx.send("⏳ Saving Jin-woo image...")
        await save_attachment(att, JINWOO_IMG_PATH)

        embed = discord.Embed(
            title="[ SYSTEM — IMAGE UPDATED ]",
            description="✅ Jin-woo image saved!\nUse `sl admin restart` to apply.",
            color=0x6600CC,
        )
        await msg.edit(content=None, embed=embed)
        await ctx.send("Preview:", file=discord.File(JINWOO_IMG_PATH, filename="jinwoo.png"))

    # ── Restart ───────────────────────────────────────────────────────────────

    @admin.command(name="restart")
    async def restart(self, ctx: commands.Context):
        """Reload all cogs."""
        embed = discord.Embed(title="[ SYSTEM — RESTARTING ]", description="⏳ Reloading all cogs...", color=0x3D0070)
        msg = await ctx.send(embed=embed)

        failed, success = [], []
        for ext in list(self.bot.extensions.keys()):
            try:
                await self.bot.reload_extension(ext)
                success.append(ext.split(".")[-1])
            except Exception as e:
                failed.append(f"{ext.split('.')[-1]}: {e}")

        lines = "\n".join(f"✅ {s}" for s in success)
        if failed:
            lines += "\n" + "\n".join(f"❌ {f}" for f in failed)

        embed = discord.Embed(
            title="[ SYSTEM — RESTART COMPLETE ]",
            description=f"{lines}\n\n**All cogs reloaded.**",
            color=0x6600CC,
        )
        await msg.edit(embed=embed)

    # ── Give / Take / Cleardb ─────────────────────────────────────────────────

    @admin.command(name="give")
    async def give(self, ctx: commands.Context, member: discord.Member, item: str, amount: int):
        """Give items to a player. Usage: sl admin give @user gold 1000"""
        item = item.lower()
        if item not in ALL_ITEMS:
            return await ctx.send(f"❌ Invalid item. Valid: `{'`, `'.join(sorted(ALL_ITEMS))}`")
        if amount <= 0:
            return await ctx.send("❌ Amount must be positive.")

        player = get_player(member.id)
        if not player:
            return await ctx.send(f"❌ {member.mention} is not registered.")

        await self._modify(member.id, item, amount)
        embed = discord.Embed(
            title="[ SYSTEM — ADMIN GIVE ]",
            description=f"✅ Gave **{amount:,}x {item.replace('_', ' ').title()}** to {member.mention}",
            color=0x6600CC,
        )
        await ctx.send(embed=embed)

    @admin.command(name="take")
    async def take(self, ctx: commands.Context, member: discord.Member, item: str, amount: int):
        """Take items from a player. Usage: sl admin take @user gold 1000"""
        item = item.lower()
        if item not in ALL_ITEMS:
            return await ctx.send(f"❌ Invalid item. Valid: `{'`, `'.join(sorted(ALL_ITEMS))}`")
        if amount <= 0:
            return await ctx.send("❌ Amount must be positive.")

        player = get_player(member.id)
        if not player:
            return await ctx.send(f"❌ {member.mention} is not registered.")

        await self._modify(member.id, item, -amount)
        embed = discord.Embed(
            title="[ SYSTEM — ADMIN TAKE ]",
            description=f"✅ Took **{amount:,}x {item.replace('_', ' ').title()}** from {member.mention}",
            color=0x6600CC,
        )
        await ctx.send(embed=embed)

    @admin.command(name="cdb")
    async def cdb(self, ctx: commands.Context, member: discord.Member):
        """Wipe ALL MongoDB data for a player. Usage: sl cdb @user"""
        deleted = delete_player(member.id)
        if not deleted:
            return await ctx.send(f"❌ {member.mention} has no data to wipe.")

        embed = discord.Embed(
            title="[ SYSTEM — PLAYER WIPED ]",
            description=f"⚠️ All data for {member.mention} has been permanently deleted.",
            color=0x6600CC,
        )
        await ctx.send(embed=embed)

    @admin.command(name="setlevel", aliases=["sl", "lvl"])
    async def set_level(self, ctx: commands.Context, member: discord.Member, level: int):
        """Force-set a player's level. Usage: sl admin setlevel @user 30"""
        from cogs.player.player_cog import (
            RANK_LEVEL_CAP, RANK_ORDER, STAT_PER_LEVEL, SP_PER_LEVEL,
            xp_to_next, get_player, save_player, BASE_STATS,
        )

        if level < 1:
            return await ctx.send("❌ Level must be at least 1.")
        if level > 999:
            return await ctx.send("❌ Level cap is 999.")

        player = get_player(member.id)
        if not player:
            return await ctx.send(f"❌ {member.mention} is not registered.")

        old_level = player.get("level", 1)
        diff      = level - old_level

        if diff == 0:
            return await ctx.send(f"ℹ️ {member.mention} is already level **{level}**.")

        # Recalculate stats from base if going down, or add levels if going up
        if level == 1:
            # Reset to base
            for stat, base in BASE_STATS.items():
                player[stat] = base
            player["max_hp"] = BASE_STATS["hp"]
            player["max_mp"] = BASE_STATS["mp"]
            player["skill_points"] = 0
            player["xp"] = 0
        else:
            for stat, gain in STAT_PER_LEVEL.items():
                player[stat] = player.get(stat, BASE_STATS.get(stat, 0)) + (gain * diff)
            player["max_hp"] = player["hp"]
            player["max_mp"] = player["mp"]
            player["skill_points"] = max(0, player.get("skill_points", 0) + (SP_PER_LEVEL * diff))
            player["xp"] = 0  # reset xp to 0 at the new level

        player["level"] = level
        save_player(member.id, player)

        direction = "⬆️" if diff > 0 else "⬇️"
        embed = discord.Embed(
            title="〔 System — Level Override 〕",
            description=(
                f"{direction} {member.mention}\n\n"
                f"**Level** `{old_level}` → `{level}`  *({diff:+d})*\n"
                f"Stats adjusted · XP reset to `0`"
            ),
            color=0x6600CC,
        )
        embed.set_footer(text=f"Set by {ctx.author.display_name}")
        await ctx.send(embed=embed)

    @admin.command(name="setrank", aliases=["rank"])
    async def set_rank(self, ctx: commands.Context, member: discord.Member, rank: str):
        """Force-set a player's rank. Usage: sl admin setrank @user S"""
        from cogs.player.player_cog import RANK_ORDER, RANK_UP_BONUS, get_player, save_player

        rank = rank.upper()
        if rank not in RANK_ORDER:
            return await ctx.send(f"❌ Invalid rank. Valid: {', '.join(f'`{r}`' for r in RANK_ORDER)}")

        player = get_player(member.id)
        if not player:
            return await ctx.send(f"❌ {member.mention} is not registered.")

        old_rank = player.get("rank", "E")
        player["rank"] = rank
        player["exam_taken_today"] = False
        save_player(member.id, player)

        embed = discord.Embed(
            title="〔 System — Rank Override 〕",
            description=(
                f"🎖️ {member.mention}\n\n"
                f"**Rank** `{old_rank}` → `{rank}`"
            ),
            color=0x6600CC,
        )
        embed.set_footer(text=f"Set by {ctx.author.display_name}")
        await ctx.send(embed=embed)


    @admin.command(name="fs", aliases=["forcestart", "force"])
    async def gate_force_start(self, ctx: commands.Context):
        """Force-start the joining phase of a gate in this channel. Usage: sl admin fs"""
        from cogs.main_cmds.gate_cog import active_gates, _start_gate

        session = active_gates.get(ctx.channel.id)
        if not session:
            return await ctx.send("❌ No active gate in this channel.")
        if session.phase != "joining":
            return await ctx.send("❌ Gate is already past the joining phase.")
        if not session.hunters:
            return await ctx.send("❌ No hunters have joined yet — at least 1 needed.")

        await ctx.message.delete()
        await _start_gate(session, ctx.channel.id, self.bot)

    @admin.command(name="exam")
    async def admin_exam(self, ctx: commands.Context, member: discord.Member = None):
        """Test the exam system for yourself or another player. No eligibility check, no cooldown.
        Usage: sl admin exam  OR  sl admin exam @user"""
        from cogs.main_cmds.exam_cog import build_shadow, exam_damage, ExamBattleView, _ExamStartView, BATTLE_TIMEOUT
        from cogs.player.player_cog import (
            get_player, save_player, rank_up,
            RANK_COLORS, RANK_ORDER, RANK_UP_BONUS,
            _rank_emoji, _stat_emoji,
        )

        target = member or ctx.author
        p = get_player(target.id)
        if not p:
            return await ctx.send(f"❌ {target.mention} is not registered.")

        rank = p.get("rank", "E")
        if rank == "S":
            return await ctx.send("❌ Already S Rank — no exam to test.")

        next_rank = RANK_ORDER[RANK_ORDER.index(rank) + 1]
        re_cur    = _rank_emoji(rank)
        re_next   = _rank_emoji(next_rank)
        shadow    = build_shadow(p, rank)
        re_shadow = "👁️" if shadow["is_igris"] else "🌑"

        igris_extra = (
            "\n\n⚠️ **Special Rule:** Igris activates **Phase 2** below 35% HP.\n"
            "*+25% ATK, increased aggression.*"
        ) if shadow["is_igris"] else ""

        confirm_embed = discord.Embed(
            title="[ SYSTEM ] — Hunter Rank Examination",
            description=(
                f"**{target.display_name}**, the System has selected your trial.\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"**Your Rank:** {re_cur} **{rank}** → {re_next} **{next_rank}**\n"
                f"**Your Level:** {p.get('level', 1)}\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"{re_shadow} **Shadow Opponent:** {shadow['name']}\n"
                f"❤️ HP: `{shadow['max_hp']:,}` · "
                f"⚔️ ATK: `{shadow['atk']:,}` · "
                f"🛡️ DEF: `{shadow['def']:,}`\n"
                f"⚡ Enters **Rage Mode** below 40% HP (+15% DMG, +10% Crit)"
                f"{igris_extra}\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"**If you win:** Rank advances + stat bonuses.\n"
                f"**If you lose:** No cooldown — admin test.\n\n"
                f"*The battle will take place in this channel.*\n\n"
                f"🛠️ *[ADMIN TEST — no eligibility check, no cooldown]*"
            ),
            color=RANK_COLORS.get(rank, 0x7B2FBE),
        )

        view = _ExamStartView(target)
        pub_msg = await ctx.send(embed=confirm_embed, view=view)
        await view.wait()

        if not view.confirmed:
            return await pub_msg.edit(
                embed=discord.Embed(
                    title="[ SYSTEM ] — Exam Withdrawn",
                    description="*Withdrawn from the examination.*",
                    color=0x555577,
                ),
                view=None,
            )

        await pub_msg.edit(
            embed=discord.Embed(
                description=(
                    f"⚡ **{target.display_name}**, your shadow trial begins now!\n"
                    f"Fight **{shadow['name']}** here in the channel."
                ),
                color=0x7B2FBE,
            ),
            view=None,
        )

        player_first = p.get("spd", 15) >= shadow["spd"]
        order_line   = "⚡ You attack first!" if player_first else "⚡ The shadow strikes first!"

        intro_embed = discord.Embed(
            title=f"[ SHADOW TRIAL ] — {shadow['name']}",
            description=(
                f"```\n■ SHADOW TRIAL INITIATED\n```\n"
                f"The shadow materialises before you.\n"
                f"**{shadow['name']}** stands in your way.\n\n"
                f"{order_line}\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"**Your HP:** `{p['hp']:,}`\n"
                f"**Shadow HP:** `{shadow['max_hp']:,}`\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"**Actions:**\n"
                f"⚔️ **Attack** — Strike the shadow\n"
                f"🛡️ **Defend** — Halve incoming damage this turn\n"
                f"💧 **Rest** — Recover 5% HP (shadow still attacks)\n"
            ),
            color=RANK_COLORS.get(rank, 0x7B2FBE),
        )

        exam_cog = ctx.bot.get_cog("Exam")
        battle_view = ExamBattleView(exam_cog, p, shadow, ctx.channel)

        if not player_first:
            dmg, is_crit, dodged = exam_damage(shadow, p)
            if not dodged:
                battle_view.p_hp = max(0, battle_view.p_hp - dmg)
                tag = " ⚡ CRIT!" if is_crit else ""
                battle_view._add_log(f"👁️ {shadow['name']} struck first — **{dmg:,}** dmg{tag}")
            else:
                battle_view._add_log(f"💨 You dodged the opening strike!")

        channel_msg = await ctx.channel.send(embed=intro_embed, view=battle_view)
        battle_view.msg = channel_msg
        await battle_view.wait()

        p_fresh = get_player(target.id)
        if battle_view.result == "win":
            new_rank = rank_up(p_fresh)
            save_player(target.id, p_fresh)
            re_new = _rank_emoji(new_rank)
            await ctx.send(embed=discord.Embed(
                title="[ SYSTEM ] — Rank Advancement",
                description=(
                    f"🎉 **{target.display_name}** defeated **{shadow['name']}**!\n\n"
                    f"{re_cur} **{rank}** → {re_new} **{new_rank}**\n\n"
                    f"*The System acknowledges your strength.*"
                ),
                color=RANK_COLORS.get(new_rank, 0x7B2FBE),
            ))
        else:
            await ctx.send(embed=discord.Embed(
                title="[ SYSTEM ] — Trial Failed",
                description=(
                    f"**{target.display_name}** was defeated by **{shadow['name']}**.\n"
                    f"Rank remains {re_cur} **{rank}**. *(Admin test — no cooldown applied)*"
                ),
                color=0xFF4444,
            ))

    # ── Internal ──────────────────────────────────────────────────────────────

    async def _modify(self, discord_id: int, item: str, delta: int):
        if item in BALANCE_ITEMS:
            MongoDB.col("players").update_one(
                {"discord_id": discord_id},
                {"$inc": {item: delta}},
            )
        elif item in CUBE_ITEMS:
            await self.bot.db.modify_cubes(discord_id, **{item: delta})
        elif item in GEAR_ITEMS:
            await self.bot.db.modify_gear(discord_id, **{item: delta})
        elif item in CRATE_ITEMS:
            await self.bot.db.modify_weapon_crates(discord_id, delta)

    # ── Error handler ─────────────────────────────────────────────────────────

    @admin.error
    async def admin_error(self, ctx: commands.Context, error):
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"❌ Missing argument: `{error.param.name}`")
        elif isinstance(error, commands.MemberNotFound):
            await ctx.send("❌ Member not found.")
        elif isinstance(error, commands.BadArgument):
            await ctx.send("❌ Invalid argument. Check usage.")


async def setup(bot):
    await bot.add_cog(AdminCog(bot))
