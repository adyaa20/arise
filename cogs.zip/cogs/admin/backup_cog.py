"""
cogs/backup_cog.py — Auto Backup System
=========================================
Every 5 minutes:
  • Dumps SQLite tables → sql_backup.txt
  • Dumps MongoDB collections → mongo_backup.txt
  • Uploads both to the backup channel with cool embeds
"""

import discord
from discord.ext import commands, tasks
import asyncio
import sqlite3
import json
import os
from datetime import datetime, timezone
from io import BytesIO, StringIO

from database import sqlite_conn, MongoDB, SQLITE_PATH
from cogs.admin.admin import is_bot_admin

# ── Config ────────────────────────────────────────────────────
BACKUP_CHANNEL_ID = 1509664756762673233
INTERVAL_MINUTES  = 5

# Solo Leveling palette
SL_PURPLE      = 0x7B2FBE
SL_DARK        = 0x1a0033
SL_GREEN       = 0x00ff88
SL_RED         = 0xff3366
SL_GOLD        = 0xffd700

LOADING_FRAMES = ["⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷"]

# SQLite tables to back up
SQLITE_TABLES = [
    "master_characters",
    "emojis",
    "rank_images",
    "item_templates",
    "skill_templates",
    "dungeon_templates",
    "quest_templates",
    "bot_config",
]

# MongoDB collections to back up
MONGO_COLLECTIONS = [
    "players",
    "player_characters",
    "guilds",
    "dungeons",
    "quests",
    "trades",
]


# ─────────────────────────────────────────────────────────────
#  DUMP HELPERS
# ─────────────────────────────────────────────────────────────

def _dump_sqlite() -> tuple[str, dict[str, int]]:
    """Returns (text_content, {table: row_count})"""
    lines = []
    counts = {}
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    lines.append("╔══════════════════════════════════════════════════╗")
    lines.append("║         SOLO LEVELING BOT — SQLite Backup        ║")
    lines.append(f"║  Generated : {now}  ║")
    lines.append("╚══════════════════════════════════════════════════╝")
    lines.append("")

    try:
        with sqlite_conn() as conn:
            for table in SQLITE_TABLES:
                # Check table exists
                exists = conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)
                ).fetchone()

                lines.append(f"▓▓ TABLE: {table.upper()} {'▓' * max(1, 40 - len(table))}")

                if not exists:
                    lines.append("  ⚠  Table does not exist yet.")
                    lines.append("")
                    counts[table] = 0
                    continue

                rows = conn.execute(f"SELECT * FROM {table}").fetchall()
                counts[table] = len(rows)

                if not rows:
                    lines.append("  — none / no data yet —")
                    lines.append("")
                    continue

                # Column headers
                cols = [desc[0] for desc in conn.execute(f"SELECT * FROM {table} LIMIT 0").description]
                lines.append("  " + " | ".join(f"{c:<20}" for c in cols))
                lines.append("  " + "-" * (23 * len(cols)))

                for row in rows:
                    lines.append("  " + " | ".join(f"{str(v):<20}" for v in row))

                lines.append(f"  [{len(rows)} row(s)]")
                lines.append("")

    except Exception as e:
        lines.append(f"\n❌ SQLite dump error: {e}")

    lines.append("══════════════════════════════════════════════════")
    lines.append("END OF SQLITE BACKUP")
    return "\n".join(lines), counts


def _serialize(obj):
    """JSON serializer for MongoDB objects."""
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    return str(obj)


def _dump_mongo() -> tuple[str, dict[str, int]]:
    """Returns (text_content, {collection: doc_count})"""
    lines = []
    counts = {}
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    lines.append("╔══════════════════════════════════════════════════╗")
    lines.append("║        SOLO LEVELING BOT — MongoDB Backup        ║")
    lines.append(f"║  Generated : {now}  ║")
    lines.append("╚══════════════════════════════════════════════════╝")
    lines.append("")

    try:
        for col_name in MONGO_COLLECTIONS:
            lines.append(f"▓▓ COLLECTION: {col_name.upper()} {'▓' * max(1, 36 - len(col_name))}")
            try:
                docs = list(MongoDB.col(col_name).find({}))
                counts[col_name] = len(docs)

                if not docs:
                    lines.append("  — none / no data yet —")
                    lines.append("")
                    continue

                for i, doc in enumerate(docs, 1):
                    doc.pop("_id", None)   # remove ObjectId for clean output
                    lines.append(f"  [{i}] " + json.dumps(doc, default=_serialize, ensure_ascii=False, indent=4)
                                 .replace("\n", "\n       "))
                    lines.append("")

                lines.append(f"  [{len(docs)} document(s)]")
                lines.append("")

            except Exception as col_err:
                lines.append(f"  ❌ Error reading collection: {col_err}")
                lines.append("")
                counts[col_name] = -1

    except Exception as e:
        lines.append(f"\n❌ MongoDB dump error: {e}")

    lines.append("══════════════════════════════════════════════════")
    lines.append("END OF MONGODB BACKUP")
    return "\n".join(lines), counts


# ─────────────────────────────────────────────────────────────
#  EMBED BUILDERS
# ─────────────────────────────────────────────────────────────

def _loading_embed(label: str, frame_idx: int = 0) -> discord.Embed:
    frame = LOADING_FRAMES[frame_idx % len(LOADING_FRAMES)]
    bars  = "█" * 8 + "░" * 2
    embed = discord.Embed(
        title=f"{frame}  SYSTEM BACKUP INITIALIZING...",
        description=(
            f"```\n"
            f"[{bars}] 80%\n"
            f"► {label}\n"
            f"```"
        ),
        color=SL_PURPLE,
    )
    embed.set_footer(text="Solo Leveling Bot • Backup System")
    return embed


def _success_embed(
    sql_counts: dict[str, int],
    mongo_counts: dict[str, int],
    timestamp: datetime,
    backup_num: int,
) -> discord.Embed:

    # SQL summary
    sql_lines = []
    for t, c in sql_counts.items():
        icon = "✅" if c > 0 else "⬜"
        sql_lines.append(f"{icon} `{t}` — **{c}** row(s)")

    # Mongo summary
    mongo_lines = []
    for col, c in mongo_counts.items():
        if c == -1:
            icon, label = "❌", "error"
        elif c == 0:
            icon, label = "⬜", "none / no data yet"
        else:
            icon, label = "✅", f"**{c}** doc(s)"
        mongo_lines.append(f"{icon} `{col}` — {label}")

    total_sql   = sum(v for v in sql_counts.values() if v > 0)
    total_mongo = sum(v for v in mongo_counts.values() if v > 0)

    embed = discord.Embed(
        title="🗡️  [ SYSTEM ] — BACKUP COMPLETE",
        color=SL_GREEN,
        timestamp=timestamp,
    )
    embed.set_author(name=f"Solo Leveling Bot • Backup #{backup_num:04d}")
    embed.description = (
        "```ansi\n"
        "\u001b[1;32m▓▓▓▓▓▓▓▓▓▓ 100% COMPLETE ▓▓▓▓▓▓▓▓▓▓\u001b[0m\n"
        "```"
    )
    embed.add_field(
        name="📦  SQLite — Bot Data",
        value="\n".join(sql_lines) or "No tables found.",
        inline=True,
    )
    embed.add_field(
        name="🌐  MongoDB — Player Data",
        value="\n".join(mongo_lines) or "No collections found.",
        inline=True,
    )
    embed.add_field(
        name="📊  Summary",
        value=(
            f"```\n"
            f"SQL Rows    : {total_sql}\n"
            f"Mongo Docs  : {total_mongo}\n"
            f"Interval    : Every {INTERVAL_MINUTES} min\n"
            f"```"
        ),
        inline=False,
    )
    embed.set_footer(text=f"Next backup in {INTERVAL_MINUTES} minutes • bot_data.db + MongoDB Atlas")
    return embed


def _error_embed(error: str, timestamp: datetime) -> discord.Embed:
    embed = discord.Embed(
        title="❌  [ SYSTEM ] — BACKUP FAILED",
        description=f"```\n{error}\n```",
        color=SL_RED,
        timestamp=timestamp,
    )
    embed.set_footer(text="Solo Leveling Bot • Backup System")
    return embed


# ─────────────────────────────────────────────────────────────
#  COG
# ─────────────────────────────────────────────────────────────

class BackupCog(commands.Cog, name="Backup"):
    def __init__(self, bot: commands.Bot):
        self.bot        = bot
        self.backup_num = 0
        self._channel: discord.TextChannel | None = None

    async def cog_load(self):
        self.backup_loop.start()
        print("[Backup] ✅ Backup loop started.")

    async def cog_unload(self):
        self.backup_loop.cancel()

    async def _get_channel(self) -> discord.TextChannel | None:
        if self._channel is None:
            self._channel = self.bot.get_channel(BACKUP_CHANNEL_ID)
        return self._channel

    # ── Core backup routine ───────────────────────────────────
    async def _run_backup(self, manual: bool = False) -> None:
        channel = await self._get_channel()
        if channel is None:
            print(f"[Backup] ❌ Channel {BACKUP_CHANNEL_ID} not found.")
            return

        self.backup_num += 1
        now = datetime.now(timezone.utc)

        # ── Loading message ──────────────────────────────────
        status_msg = await channel.send(embed=_loading_embed("Reading SQLite...", 0))

        # Animate a couple frames
        for i, label in enumerate([
            "Reading SQLite...",
            "Dumping master_characters...",
            "Connecting to MongoDB...",
            "Serializing documents...",
            "Writing files...",
        ], 1):
            await asyncio.sleep(0.6)
            try:
                await status_msg.edit(embed=_loading_embed(label, i))
            except Exception:
                pass

        # ── Actual dump (run in thread so it doesn't block) ──
        try:
            sql_text, sql_counts = await asyncio.get_event_loop().run_in_executor(
                None, _dump_sqlite
            )
            mongo_text, mongo_counts = await asyncio.get_event_loop().run_in_executor(
                None, _dump_mongo
            )
        except Exception as e:
            await status_msg.edit(embed=_error_embed(str(e), now))
            return

        # ── Build file objects ───────────────────────────────
        ts_str    = now.strftime("%Y%m%d_%H%M%S")
        sql_file  = discord.File(
            fp=BytesIO(sql_text.encode("utf-8")),
            filename=f"sql_backup_{ts_str}.txt",
        )
        mongo_file = discord.File(
            fp=BytesIO(mongo_text.encode("utf-8")),
            filename=f"mongo_backup_{ts_str}.txt",
        )

        # ── Edit loading → success embed + upload files ──────
        success = _success_embed(sql_counts, mongo_counts, now, self.backup_num)
        prefix  = "🔧 **[MANUAL BACKUP]**\n" if manual else ""

        await status_msg.edit(
            content=prefix or None,
            embed=success,
        )
        await channel.send(
            content="📁 **Backup Files:**",
            files=[sql_file, mongo_file],
        )

    # ── Scheduled task ────────────────────────────────────────
    @tasks.loop(minutes=INTERVAL_MINUTES)
    async def backup_loop(self):
        try:
            await self._run_backup()
        except Exception as e:
            print(f"[Backup] ❌ Loop error: {e}")

    @backup_loop.before_loop
    async def before_backup(self):
        await self.bot.wait_until_ready()
        # Small delay on first start so bot is fully settled
        await asyncio.sleep(10)

    # ── Manual trigger command ─────────────────────────────────
    @commands.command(name="backup", aliases=["bk"])
    async def manual_backup(self, ctx: commands.Context):
        """Manually trigger a backup. Admin only."""
        if not is_bot_admin(ctx.author.id):
            return await ctx.send("❌ Admins only.")
        await ctx.message.add_reaction("⏳")
        await self._run_backup(manual=True)
        await ctx.message.add_reaction("✅")
        try:
            await ctx.message.remove_reaction("⏳", ctx.me)
        except Exception:
            pass


async def setup(bot: commands.Bot):
    await bot.add_cog(BackupCog(bot))
