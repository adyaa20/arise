import discord
from discord.ext import commands
from discord import app_commands
import asyncio

# { owner_id: { "guild_id": int, "decisions": { user_id: "keep"|"ban" } } }
sessions = {}


# ─── Server Selection View ────────────────────────────────────────────────────

class ServerSelectView(discord.ui.View):
    def __init__(self, guilds: list[discord.Guild], invoker_id: int):
        super().__init__(timeout=120)
        self.invoker_id = invoker_id

        for guild in guilds[:25]:  # max 25 buttons
            btn = discord.ui.Button(
                label=guild.name[:80],
                custom_id=f"server_{guild.id}",
                style=discord.ButtonStyle.primary
            )
            btn.callback = self.make_callback(guild)
            self.add_item(btn)

    def make_callback(self, guild: discord.Guild):
        async def callback(interaction: discord.Interaction):
            if interaction.user.id != self.invoker_id:
                await interaction.response.send_message("This isn't your session.", ephemeral=True)
                return

            # Disable all buttons
            for item in self.children:
                item.disabled = True
            await interaction.response.edit_message(
                content=f"✅ Selected **{guild.name}**. Fetching members...",
                view=self
            )

            # Init session
            sessions[self.invoker_id] = {
                "guild_id": guild.id,
                "decisions": {}
            }

            # Fetch fresh member list
            try:
                await guild.chunk()
            except Exception:
                pass

            members = [m for m in guild.members if not m.bot and m.id != self.invoker_id]

            if not members:
                await interaction.followup.send("No members found in that server.")
                return

            failed = 0
            for i, member in enumerate(members, 1):
                embed = _member_embed(member, i, len(members))
                view = BanView(invoker_id=self.invoker_id, target_user_id=member.id)

                try:
                    await interaction.user.send(embed=embed, view=view)
                    await asyncio.sleep(0.4)
                except discord.Forbidden:
                    failed += 1

            summary = discord.Embed(
                title="📋 All Members Sent",
                description=(
                    f"**{len(members) - failed}** member cards sent.\n"
                    + (f"⚠️ {failed} failed to send.\n" if failed else "")
                    + "\nMark each member, then use `/execute` here in DM."
                ),
                color=discord.Color.gold()
            )
            await interaction.user.send(embed=summary)

        return callback


# ─── Member Card View ─────────────────────────────────────────────────────────

class BanView(discord.ui.View):
    def __init__(self, invoker_id: int, target_user_id: int):
        super().__init__(timeout=None)
        self.invoker_id = invoker_id
        self.target_user_id = target_user_id

        self.keep_btn = discord.ui.Button(
            label="✅ Keep",
            style=discord.ButtonStyle.success,
            custom_id=f"keep_{invoker_id}_{target_user_id}"
        )
        self.ban_btn = discord.ui.Button(
            label="🔨 Ban",
            style=discord.ButtonStyle.danger,
            custom_id=f"ban_{invoker_id}_{target_user_id}"
        )

        self.keep_btn.callback = self.keep_callback
        self.ban_btn.callback = self.ban_callback

        self.add_item(self.keep_btn)
        self.add_item(self.ban_btn)

    async def keep_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.invoker_id:
            return
        _set_decision(self.invoker_id, self.target_user_id, "keep")
        await _update_card(interaction, "keep")

    async def ban_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.invoker_id:
            return
        _set_decision(self.invoker_id, self.target_user_id, "ban")
        await _update_card(interaction, "ban")


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _member_embed(member: discord.Member, index: int, total: int) -> discord.Embed:
    embed = discord.Embed(
        title=f"Member {index}/{total} — {member.display_name}",
        color=discord.Color.blurple()
    )
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="Username", value=str(member), inline=True)
    embed.add_field(name="ID", value=str(member.id), inline=True)
    embed.add_field(
        name="Joined Server",
        value=f"<t:{int(member.joined_at.timestamp())}:R>" if member.joined_at else "Unknown",
        inline=True
    )
    embed.add_field(
        name="Account Created",
        value=f"<t:{int(member.created_at.timestamp())}:R>",
        inline=True
    )
    top_role = member.top_role.name if member.top_role.name != "@everyone" else "None"
    embed.add_field(name="Top Role", value=top_role, inline=True)
    embed.set_footer(text="⏳ No decision yet")
    return embed


def _set_decision(invoker_id: int, user_id: int, decision: str):
    if invoker_id in sessions:
        sessions[invoker_id]["decisions"][user_id] = decision


async def _update_card(interaction: discord.Interaction, decision: str):
    embed = interaction.message.embeds[0]
    if decision == "keep":
        embed.color = discord.Color.green()
        embed.set_footer(text="Decision: ✅ Keep")
    else:
        embed.color = discord.Color.red()
        embed.set_footer(text="Decision: 🔨 Ban")

    view = discord.ui.View()  # empty disabled view
    btn = discord.ui.Button(
        label="✅ Keep" if decision == "keep" else "🔨 Ban",
        style=discord.ButtonStyle.success if decision == "keep" else discord.ButtonStyle.danger,
        disabled=True
    )
    view.add_item(btn)
    await interaction.response.edit_message(embed=embed, view=view)


# ─── Cog ─────────────────────────────────────────────────────────────────────

class BanSystem(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="scan", description="DM only: Pick a server and review its members.")
    async def scan(self, interaction: discord.Interaction):
        # Must be used in DMs
        if interaction.guild is not None:
            await interaction.response.send_message(
                "⚠️ Use this command in my **DMs**, not in a server.", ephemeral=True
            )
            return

        # Only bot owner or admins — adjust check as needed
        guilds = self.bot.guilds

        if not guilds:
            await interaction.response.send_message("I'm not in any servers.")
            return

        embed = discord.Embed(
            title="🌐 Select a Server",
            description="Pick which server you want to review members of.",
            color=discord.Color.blurple()
        )
        for g in guilds[:25]:
            embed.add_field(name=g.name, value=f"{g.member_count} members", inline=True)

        view = ServerSelectView(guilds=guilds, invoker_id=interaction.user.id)
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="execute", description="DM only: Bans all members you marked 🔨.")
    async def execute(self, interaction: discord.Interaction):
        if interaction.guild is not None:
            await interaction.response.send_message(
                "⚠️ Use this command in my **DMs**.", ephemeral=True
            )
            return

        session = sessions.get(interaction.user.id)
        if not session:
            await interaction.response.send_message(
                "No active session. Run `/scan` first.", ephemeral=True
            )
            return

        guild = self.bot.get_guild(session["guild_id"])
        if not guild:
            await interaction.response.send_message("Couldn't find the server. It may have been removed.")
            return

        to_ban = [uid for uid, d in session["decisions"].items() if d == "ban"]

        if not to_ban:
            await interaction.response.send_message(
                "No members marked for ban yet. Review the member cards first."
            )
            return

        await interaction.response.defer()

        banned, failed = [], []

        for user_id in to_ban:
            try:
                user = await self.bot.fetch_user(user_id)
                await guild.ban(user, reason="Administrative action.")
                banned.append(str(user))
                await asyncio.sleep(0.5)
            except Exception as e:
                failed.append(f"<@{user_id}> — {e}")

        # Clear session
        sessions.pop(interaction.user.id, None)

        result = discord.Embed(
            title=f"🔨 Bans Executed in {guild.name}",
            color=discord.Color.red()
        )
        result.add_field(
            name=f"✅ Banned ({len(banned)})",
            value="\n".join(banned) if banned else "None",
            inline=False
        )
        if failed:
            result.add_field(
                name=f"❌ Failed ({len(failed)})",
                value="\n".join(failed),
                inline=False
            )

        await interaction.followup.send(embed=result)

    @app_commands.command(name="decisions", description="DM only: Check your current pending decisions.")
    async def decisions(self, interaction: discord.Interaction):
        if interaction.guild is not None:
            await interaction.response.send_message("Use this in my DMs.", ephemeral=True)
            return

        session = sessions.get(interaction.user.id)
        if not session:
            await interaction.response.send_message("No active session. Run `/scan` first.")
            return

        guild = self.bot.get_guild(session["guild_id"])
        d = session["decisions"]

        to_ban = [uid for uid, v in d.items() if v == "ban"]
        to_keep = [uid for uid, v in d.items() if v == "keep"]

        embed = discord.Embed(
            title=f"📋 Decisions — {guild.name if guild else 'Unknown Server'}",
            color=discord.Color.orange()
        )
        embed.add_field(
            name=f"🔨 To Ban ({len(to_ban)})",
            value="\n".join(f"<@{u}>" for u in to_ban) or "None",
            inline=False
        )
        embed.add_field(name=f"✅ To Keep ({len(to_keep)})", value=str(len(to_keep)), inline=True)
        embed.set_footer(text="Run /execute to apply bans.")

        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(BanSystem(bot))
