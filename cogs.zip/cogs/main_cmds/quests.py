"""
cogs/quests.py — Solo Leveling Quest Board
===========================================
• sl quests / sl q  — show daily & weekly quests
• sl daily          — show only daily quests  
• sl weekly         — show only weekly quests
Training daily quest tracks real progress from sl train.
"""

import logging
from datetime import date

import discord
from discord.ext import commands

from database import get_quests, get_player

log = logging.getLogger("quests")

SL_PURPLE      = 0x7B2FBE
SL_PURPLE_DARK = 0x4B0082

# ── Training daily quest targets ─────────────────────────────
TRAIN_TASKS = [
    {"key": "pushups",  "label": "Push-ups", "target": 20},
    {"key": "squats",   "label": "Squats",   "target": 15},
    {"key": "situps",   "label": "Sit-ups",  "target": 20},
    {"key": "running",  "label": "Running",  "target": 10, "unit": "km"},
    {"key": "sparring", "label": "Sparring", "target": 5,  "unit": "rounds"},
]

TRAIN_REWARD_COINS = 3_000
TRAIN_REWARD_EXP   = 500

BAR_FILLED = "■"
BAR_EMPTY  = "□"
BAR_LENGTH = 10


def _progress_bar(current: int, target: int) -> str:
    filled = min(round((current / target) * BAR_LENGTH), BAR_LENGTH)
    empty  = BAR_LENGTH - filled
    bar    = f"[{BAR_FILLED * filled}{BAR_EMPTY * empty}]"
    return f"{bar}  {current}/{target}"


def _build_train_quest_field(player: dict) -> str:
    today    = str(date.today())
    is_today = player.get("train_date") == today

    lines    = []
    all_done = True
    for task in TRAIN_TASKS:
        key    = task["key"]
        target = task["target"]
        label  = task["label"]
        unit   = task.get("unit", "reps")

        current = player.get(f"train_{key}_today", 0) if is_today else 0
        if current < target:
            all_done = False

        bar = _progress_bar(current, target)
        lines.append(f"`{label:<10}` {bar}")

    reward = f"🪙 **{TRAIN_REWARD_COINS:,}** Gold  •  💠 **{TRAIN_REWARD_EXP}** EXP"
    lines.append(f"\n**Reward:** {reward}")

    if all_done:
        lines.append("✅ **COMPLETED**")

    return "\n".join(lines)


def _quest_embed(quests: list, type_: str, player: dict = None) -> discord.Embed:
    reset = "Resets every day at midnight UTC" if type_ == "daily" else "Resets every Monday at midnight UTC"

    embed = discord.Embed(
        title=f"[ SYSTEM — {'DAILY' if type_ == 'daily' else 'WEEKLY'} QUESTS ]",
        color=SL_PURPLE,
    )
    embed.set_footer(text=reset)

    if type_ == "daily":
        train_value = _build_train_quest_field(player) if player else "*(register to track progress)*"
        embed.add_field(name="🏋️  TRAINING", value=train_value, inline=False)
        embed.add_field(name="\u200b", value="\u200b", inline=False)

    if not quests:
        embed.add_field(
            name="📋 Other Quests",
            value="*The System is preparing more missions, Hunter.*",
            inline=False,
        )
    else:
        for q in quests:
            reward_text = f"🪙 **{q['reward_coins']:,}** Gold  •  💠 **{q['reward_exp']}** EXP"
            embed.add_field(
                name=f"[{q.get('rank','E')}] {q['title']}",
                value=f"{q.get('description','*No description.*')}\n**Reward:** {reward_text}",
                inline=False,
            )

    return embed


class QuestsCog(commands.Cog, name="Quests"):
    """Daily and weekly quest board."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="quests", aliases=["q", "quest"], help="Show the quest board.")
    async def quests(self, ctx: commands.Context):
        """sl quests — Shows both daily and weekly quests."""
        try:
            player = get_player(ctx.author.id)
            daily  = get_quests("daily")
            weekly = get_quests("weekly")

            embed = discord.Embed(
                title="[ SYSTEM — QUEST BOARD ]",
                description="Complete your missions and grow stronger, Hunter.",
                color=SL_PURPLE,
            )

            embed.add_field(name="🌅  DAILY QUESTS", value="\u200b", inline=False)

            train_value = _build_train_quest_field(player) if player else "*(use `sl register` to register)*"
            embed.add_field(name="🏋️  TRAINING", value=train_value, inline=False)

            for q in daily:
                reward_text = f"🪙 **{q['reward_coins']:,}** Gold  •  💠 **{q['reward_exp']}** EXP"
                embed.add_field(
                    name=f"[{q.get('rank','E')}] {q['title']}",
                    value=f"{q.get('description','*No description.*')}\n**Reward:** {reward_text}",
                    inline=False,
                )

            if not daily:
                embed.add_field(name="\u200b", value="*More daily quests coming soon...*", inline=False)

            embed.add_field(name="\u200b", value="\u200b", inline=False)

            embed.add_field(name="📅  WEEKLY QUESTS", value="\u200b", inline=False)

            for q in weekly:
                reward_text = f"🪙 **{q['reward_coins']:,}** Gold  •  💠 **{q['reward_exp']}** EXP"
                embed.add_field(
                    name=f"[{q.get('rank','E')}] {q['title']}",
                    value=f"{q.get('description','*No description.*')}\n**Reward:** {reward_text}",
                    inline=False,
                )

            if not weekly:
                embed.add_field(name="\u200b", value="*Weekly quests coming soon...*", inline=False)

            embed.set_footer(text="Daily resets midnight UTC  •  Weekly resets Monday UTC")
            await ctx.send(embed=embed)

        except Exception as e:
            log.exception("quests command failed")
            await ctx.send(f"❌ Something went wrong: `{e}`")

    @commands.command(name="questdaily", aliases=["qd"], help="Show daily quests.")
    async def questdaily(self, ctx: commands.Context):
        """sl questdaily — show daily quest board"""
        try:
            player = get_player(ctx.author.id)
            quests = get_quests("daily")
            await ctx.send(embed=_quest_embed(quests, "daily", player))
        except Exception as e:
            log.exception("daily command failed")
            await ctx.send(f"❌ Something went wrong: `{e}`")

    @commands.command(name="weekly", help="Show weekly quests.")
    async def weekly(self, ctx: commands.Context):
        """sl weekly"""
        try:
            quests = get_quests("weekly")
            await ctx.send(embed=_quest_embed(quests, "weekly"))
        except Exception as e:
            log.exception("weekly command failed")
            await ctx.send(f"❌ Something went wrong: `{e}`")


async def setup(bot: commands.Bot):
    await bot.add_cog(QuestsCog(bot))
