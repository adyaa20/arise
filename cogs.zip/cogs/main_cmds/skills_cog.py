"""
cogs/skills_cog.py — Hunter Skills System
==========================================
Architecture:
  • Reads player level from MongoDB → players collection
  • All skill definitions live in player_cog.py (SKILLS list)

Skills unlock every 5 levels up to level 20:
  • Level  5 → Shadow Strike  (Power: 40, Mana Cost: 100)
  • Level 10 → Multi Strike   (Power: 50, Mana Cost: 120)
  • Level 15 → Arc Slash      (Power: 70, Mana Cost: 150)
  • Level 20 → Shadow Burst   (Power: 100, Mana Cost: 200)

Commands:
  sl skills   — shows all 4 skills, locked/unlocked status, and XP progress
"""

import discord
from discord.ext import commands

from cogs.player.player_cog import (
    get_player,
    SKILLS,
    RANK_COLORS,
    xp_to_next,
    _rank_emoji,
)

# ─────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────

def _skill_unlock_embed(player: dict, member: discord.Member) -> discord.Embed:
    """Build the skills status embed for a player."""
    level    = player.get("level", 1)
    rank     = player.get("rank", "E")
    re       = _rank_emoji(rank)
    color    = RANK_COLORS.get(rank, 0x7B2FBE)

    lines = []
    for skill in SKILLS:
        req      = skill["unlock_level"]
        unlocked = level >= req

        if unlocked:
            status = f"✅ **UNLOCKED**"
        else:
            lvls_away = req - level
            status    = f"🔒 Unlocks at **Level {req}** *(+{lvls_away} levels)*"

        lines.append(
            f"{skill['emoji']} **{skill['name']}**　—　{status}\n"
            f"-# ┗ Power: `{skill['power']}`　Mana Cost: `{skill['mana_cost']}`　{skill['desc']}"
        )

    # Next unlock hint
    locked_skills = [s for s in SKILLS if level < s["unlock_level"]]
    if locked_skills:
        next_skill = locked_skills[0]
        lvls_needed = next_skill["unlock_level"] - level
        footer_text = (
            f"Next skill: {next_skill['name']} — reach Level {next_skill['unlock_level']} "
            f"({lvls_needed} level{'s' if lvls_needed != 1 else ''} away)"
        )
    else:
        footer_text = "All skills unlocked! Use them wisely in gate combat."

    unlocked_count = sum(1 for s in SKILLS if level >= s["unlock_level"])

    embed = discord.Embed(
        title="〔 Hunter Skill System 〕",
        description=(
            f"{re} **{rank}-Rank Hunter**　·　Level `{level}`\n"
            f"💙 Skills Unlocked: **{unlocked_count} / {len(SKILLS)}**\n\n"
            + "\n\n".join(lines)
        ),
        color=color,
    )
    embed.set_author(
        name=f"{member.display_name}'s Skills",
        icon_url=member.display_avatar.url,
    )
    embed.set_footer(text=footer_text)
    return embed


# ─────────────────────────────────────────────────────────────
#  COG
# ─────────────────────────────────────────────────────────────

class SkillsCog(commands.Cog, name="Skills"):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def cog_load(self):
        print("[SkillsCog] ✅ Ready.")

    # ── sl skills ─────────────────────────────────────────────
    @commands.command(name="skills", aliases=["sk", "skill"])
    async def skills(self, ctx: commands.Context, member: discord.Member = None):
        """View your skill unlock progress. Usage: sl skills [@member]"""
        target = member or ctx.author
        p      = get_player(target.id)

        if not p:
            name = target.display_name
            return await ctx.send(
                f"❌ **{name}** is not registered. Use `sl start` to begin."
            )

        embed = _skill_unlock_embed(p, target)
        await ctx.send(embed=embed)

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CommandInvokeError):
            print(f"[SkillsCog] ❌ {ctx.command}: {error.original}")
            await ctx.send("⚠️ Something went wrong. Try again.", delete_after=8)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(SkillsCog(bot))
