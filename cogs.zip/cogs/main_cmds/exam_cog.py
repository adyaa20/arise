"""
cogs/exam_cog.py — Hunter Rank Exam System
============================================
Flow:
  1. sl exam → eligibility check
  2. Confirm embed with shadow opponent details
  3. DM-based turn-by-turn battle (Attack / Defend / Rest)
  4. Win → rank_up() called → stats boosted
  5. Lose → try again tomorrow

Shadow scales from player stats per formula.
S Rank exam always uses Igris (with Phase 2).
"""

import discord
from discord.ext import commands
import asyncio
import random
import datetime

from database import MongoDB
from cogs.player.player_cog import (
    get_player, save_player,
    can_take_exam, rank_up,
    RANK_COLORS, RANK_ORDER, RANK_UP_BONUS,
    EXAM_LEVEL_REQ, _rank_emoji, _stat_emoji,
)

# ─────────────────────────────────────────────────────────────
#  SHADOW DATA
# ─────────────────────────────────────────────────────────────

SHADOWS = {
    "E": ["Shadow Goblin", "Dark Wolf", "Hollow Soldier", "Broken Knight",
          "Cave Stalker", "Fang Rat", "Rotcrawler", "Ash Skeleton"],
    "D": ["Iron Fang", "Shadow Assassin", "Abyss Archer", "Cursed Orc",
          "Phantom Guard", "Death Hound", "Black Spearman", "Grave Warden"],
    "C": ["Crimson Blade", "Black Fang", "Doom Shaman", "Bone Reaper",
          "Infernal Knight", "Venom Queen", "Shadow Lancer", "Nightmare Wolf"],
    "B": ["Death Howler", "Void Berserker", "Shadow Commander", "Blood Tyrant",
          "Nightmare Beast", "Abyss Predator", "Inferno Giant", "Black Priest"],
    "A": ["Eclipse Knight", "Chaos Executioner", "Abyss Monarch Guard", "Silent Reaper",
          "Hellfire Dragonkin", "Void Serpent", "Fallen Paladin", "Shadow Warlock"],
    "S": ["Igris"],  # S rank always Igris
}

SHADOW_IMAGES = {
    "E": "https://i.imgur.com/placeholder_e.png",
    "D": "https://i.imgur.com/placeholder_d.png",
    "C": "https://i.imgur.com/placeholder_c.png",
    "B": "https://i.imgur.com/placeholder_b.png",
    "A": "https://i.imgur.com/placeholder_a.png",
    "S": "https://i.imgur.com/igris.png",
}

BATTLE_TIMEOUT = 120   # seconds per turn

# ─────────────────────────────────────────────────────────────
#  SHADOW STAT BUILDER
# ─────────────────────────────────────────────────────────────

def build_shadow(player: dict, rank: str) -> dict:
    """Scale shadow stats from player stats per exam formula."""
    name = "Igris" if rank == "S" else random.choice(SHADOWS[rank])
    is_igris = (name == "Igris")

    shadow = {
        "name":    name,
        "rank":    rank,
        "hp":      int(player["hp"]   * 0.75),
        "atk":     int(player["atk"]  * 0.90),
        "def":     int(player["def"]  * 0.85),
        "spd":     int(player["spd"]  * 0.90),
        "prec":    int(player["prec"] * 0.85),
        "is_igris": is_igris,
        "phase2":  False,
        "rage":    False,
    }
    # Igris bonuses
    if is_igris:
        shadow["def"]  = int(shadow["def"]  * 1.20)
        shadow["prec"] = int(shadow["prec"] * 1.15)

    shadow["max_hp"] = shadow["hp"]
    return shadow


# ─────────────────────────────────────────────────────────────
#  BATTLE FORMULA (exam-specific)
# ─────────────────────────────────────────────────────────────

def exam_damage(attacker: dict, defender: dict) -> tuple[int, bool, bool]:
    """
    Returns (damage, is_crit, is_dodge).
    Exam formula:
      damage = ATK * (100 / (80 + DEF))
      crit   = min(8 + PREC*0.45, 45)%
      dodge  = min(SPD/(SPD+140)*100, 20)%
    """
    spd_d = defender.get("spd", 10)
    dodge_chance = min((spd_d / (spd_d + 140)) * 100, 20)
    if random.uniform(0, 100) <= dodge_chance:
        return 0, False, True   # dodged

    atk = attacker.get("atk", 50)
    def_ = defender.get("def", 20)
    raw  = atk * (100 / (80 + def_))

    prec = attacker.get("prec", 10)
    crit_chance = min(8 + prec * 0.45, 45)
    is_crit = random.uniform(0, 100) <= crit_chance
    if is_crit:
        raw *= 1.8

    dmg = max(1, int(raw))
    return dmg, is_crit, False


# ─────────────────────────────────────────────────────────────
#  EMBED BUILDERS
# ─────────────────────────────────────────────────────────────

def _hp_bar(cur: int, max_: int, length: int = 12) -> str:
    pct    = max(0, min(cur / max(max_, 1), 1.0))
    filled = int(pct * length)
    return "█" * filled + "░" * (length - filled)


def _battle_embed(
    player: dict,
    shadow: dict,
    p_cur_hp: int,
    s_cur_hp: int,
    turn: int,
    log: list[str],
    color: int = 0x7B2FBE,
    title_override: str = None,
) -> discord.Embed:
    rank  = player.get("rank", "E")
    p_max = player["hp"]
    s_max = shadow["max_hp"]
    p_bar = _hp_bar(p_cur_hp, p_max)
    s_bar = _hp_bar(s_cur_hp, s_max)

    rage_tag  = " **[RAGE]**"    if shadow.get("rage")   else ""
    phase_tag = " **[PHASE 2]**" if shadow.get("phase2") else ""

    # FIX (Bug 4): safe next-rank lookup — never index out of bounds at S rank
    if rank != "S" and RANK_ORDER.index(rank) + 1 < len(RANK_ORDER):
        next_rank_label = RANK_ORDER[RANK_ORDER.index(rank) + 1]
    else:
        next_rank_label = "S"

    embed = discord.Embed(
        title=title_override or f"[ SHADOW TRIAL ] — Turn {turn}",
        color=color,
    )
    embed.add_field(
        name=f"👤 {player.get('username', 'Hunter')}",
        value=(
            f"`[{p_bar}]`\n"
            f"❤️ **{p_cur_hp:,} / {p_max:,}**"
        ),
        inline=True,
    )
    embed.add_field(
        name=f"👁️ {shadow['name']}{rage_tag}{phase_tag}",
        value=(
            f"`[{s_bar}]`\n"
            f"❤️ **{s_cur_hp:,} / {s_max:,}**"
        ),
        inline=True,
    )
    if log:
        embed.add_field(
            name="📜 Battle Log",
            value="\n".join(f"▸ {l}" for l in log[-4:]),
            inline=False,
        )
    embed.set_footer(text=f"Shadow Trial · {rank} → {next_rank_label} Rank Exam")
    return embed


# ─────────────────────────────────────────────────────────────
#  BATTLE VIEW (DM)
# ─────────────────────────────────────────────────────────────

class ExamBattleView(discord.ui.View):
    def __init__(self, exam_cog, player: dict, shadow: dict, ctx_channel):
        super().__init__(timeout=BATTLE_TIMEOUT)
        self.exam_cog    = exam_cog
        self.player      = player
        self.shadow      = shadow
        self.ctx_channel = ctx_channel

        # Mutable HP refs
        self.p_hp = player["hp"]
        self.s_hp = shadow["max_hp"]

        self.turn       = 1
        self.defending  = False   # player chose Defend this turn
        self.log        = []
        self.done       = False
        self.result     = None    # "win" | "lose"
        self.msg        = None    # DM message to edit

    def _add_log(self, text: str):
        self.log.append(text)
        if len(self.log) > 10:
            self.log = self.log[-10:]

    async def _refresh(self, interaction: discord.Interaction = None):
        embed = _battle_embed(
            self.player, self.shadow,
            self.p_hp, self.s_hp,
            self.turn, self.log,
        )
        if self.msg:
            try:
                await self.msg.edit(embed=embed, view=self)
            except Exception:
                pass

    async def on_timeout(self):
        if not self.done:
            self.done   = True
            self.result = "lose"
            self.stop()
            try:
                await self.msg.edit(
                    embed=discord.Embed(
                        title="[ SYSTEM ] — Shadow Trial Timed Out",
                        description="You hesitated too long. The shadow trial has ended.\n\n*Try again tomorrow.*",
                        color=0xFF4444,
                    ),
                    view=None,
                )
            except Exception:
                pass

    async def _shadow_turn(self):
        """Shadow attacks after player action."""
        shadow = self.shadow
        player = self.player

        # Shadow rage mode below 40% HP
        if self.s_hp <= shadow["max_hp"] * 0.40 and not shadow["rage"]:
            shadow["rage"] = True
            self._add_log(f"💢 **{shadow['name']}** enters RAGE MODE!")

        # Igris Phase 2 below 35%
        if shadow.get("is_igris") and self.s_hp <= shadow["max_hp"] * 0.35 and not shadow.get("phase2"):
            shadow["phase2"] = True
            shadow["atk"]   = int(shadow["atk"] * 1.25)
            self._add_log("🔴 **IGRIS** activates Phase 2 — ATK surges!")

        # Rage crit bonus
        extra_prec = 10 if shadow["rage"] else 0
        s_attacker = {**shadow, "prec": shadow["prec"] + extra_prec}

        # Player def doubled if defending (they block, so shadow hits less)
        p_def_mult = 2.0 if self.defending else 1.0
        p_defender = {**player, "hp": self.p_hp, "def": int(player.get("def", 20) * p_def_mult)}

        dmg, is_crit, dodged = exam_damage(s_attacker, p_defender)

        # Rage dmg boost
        if shadow["rage"]:
            dmg = int(dmg * 1.15)

        if dodged:
            self._add_log(f"💨 You dodged **{shadow['name']}**'s attack!")
        else:
            self.p_hp = max(0, self.p_hp - dmg)
            tag = " ⚡ **CRIT!**" if is_crit else ""
            block = " 🛡️ *(blocked)*" if self.defending else ""
            self._add_log(f"👁️ {shadow['name']} dealt **{dmg:,}** damage{tag}{block}")

    # ── ATTACK ────────────────────────────────────────────────
    @discord.ui.button(label="⚔️ Attack", style=discord.ButtonStyle.danger, row=0)
    async def attack_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.player["discord_id"]:
            return await interaction.response.send_message("❌ Not your exam.", ephemeral=True)
        if self.done:
            return await interaction.response.defer()

        await interaction.response.defer()
        self.defending = False

        # Player attacks shadow
        p_attacker = {**self.player, "hp": self.p_hp}
        dmg, is_crit, dodged = exam_damage(p_attacker, self.shadow)
        if dodged:
            self._add_log(f"💨 **{self.shadow['name']}** dodged your attack!")
        else:
            self.s_hp = max(0, self.s_hp - dmg)
            tag = " ⚡ **CRIT!**" if is_crit else ""
            self._add_log(f"⚔️ You dealt **{dmg:,}** damage{tag}")

        if await self._check_end():
            return

        # Shadow turn
        await self._shadow_turn()
        self.turn += 1

        # Player 5% HP regen every 5 turns
        if self.turn % 5 == 0:
            regen = max(1, int(self.player["hp"] * 0.05))
            self.p_hp = min(self.player["hp"], self.p_hp + regen)
            self._add_log(f"💚 Recovered **{regen:,}** HP")

        if await self._check_end():
            return

        await self._refresh()

    # ── DEFEND ────────────────────────────────────────────────
    @discord.ui.button(label="🛡️ Defend", style=discord.ButtonStyle.primary, row=0)
    async def defend_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.player["discord_id"]:
            return await interaction.response.send_message("❌ Not your exam.", ephemeral=True)
        if self.done:
            return await interaction.response.defer()

        await interaction.response.defer()
        self.defending = True
        self._add_log("🛡️ You brace — incoming damage halved this turn.")

        # Shadow turn (player is defending = double DEF)
        await self._shadow_turn()
        self.defending = False
        self.turn += 1

        if await self._check_end():
            return
        await self._refresh()

    # ── REST ──────────────────────────────────────────────────
    @discord.ui.button(label="💧 Rest", style=discord.ButtonStyle.secondary, row=0)
    async def rest_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.player["discord_id"]:
            return await interaction.response.send_message("❌ Not your exam.", ephemeral=True)
        if self.done:
            return await interaction.response.defer()

        await interaction.response.defer()
        self.defending = False

        regen = max(1, int(self.player["hp"] * 0.05))
        self.p_hp = min(self.player["hp"], self.p_hp + regen)
        self._add_log(f"💧 Rested — recovered **{regen:,}** HP (shadow still attacks)")

        # Shadow attacks while you rest (no defense bonus)
        await self._shadow_turn()
        self.turn += 1

        if await self._check_end():
            return
        await self._refresh()

    # ── END CHECK ─────────────────────────────────────────────
    async def _check_end(self) -> bool:
        if self.s_hp <= 0:
            self.done   = True
            self.result = "win"
            self.stop()
            await self._show_result("win")
            return True
        if self.p_hp <= 0:
            self.done   = True
            self.result = "lose"
            self.stop()
            await self._show_result("lose")
            return True
        return False

    async def _show_result(self, result: str):
        rank      = self.player.get("rank", "E")
        next_rank = RANK_ORDER[RANK_ORDER.index(rank) + 1] if rank != "S" else "S"
        re_cur    = _rank_emoji(rank)
        re_next   = _rank_emoji(next_rank)

        if result == "win":
            embed = discord.Embed(
                title="[ SYSTEM ] — Shadow Trial Complete",
                description=(
                    f"```ansi\n"
                    f"\u001b[1;35m▓▓▓▓▓▓▓▓▓▓ VICTORY ▓▓▓▓▓▓▓▓▓▓\u001b[0m\n"
                    f"```\n"
                    f"**{self.player.get('username', 'Hunter')}** has defeated **{self.shadow['name']}**.\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"{re_cur} **{rank}** → {re_next} **{next_rank}**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"**Rank Bonuses Applied:**\n"
                    + "\n".join(
                        f"▸ {_stat_emoji(s)} **+{v}** {s.upper()}"
                        for s, v in RANK_UP_BONUS.get(next_rank, {}).items()
                    ) +
                    f"\n\n*The System acknowledges your strength.*"
                ),
                color=RANK_COLORS.get(next_rank, 0x7B2FBE),
            )
        else:
            # FIX (Bug 3): calculate actual HP lost during battle, not max HP
            hp_lost = self.player["hp"] - self.p_hp
            embed = discord.Embed(
                title="[ SYSTEM ] — Shadow Trial Failed",
                description=(
                    f"```ansi\n"
                    f"\u001b[1;31m▓▓▓▓▓▓▓▓▓▓ DEFEATED ▓▓▓▓▓▓▓▓▓▓\u001b[0m\n"
                    f"```\n"
                    f"**{self.shadow['name']}** overwhelmed you.\n\n"
                    f"Your rank remains {re_cur} **{rank}**.\n"
                    f"HP lost this battle: **{hp_lost:,}**\n"
                    f"Train harder. Return tomorrow.\n\n"
                    f"*The weak do not survive the System's trials.*"
                ),
                color=0xFF4444,
            )

        try:
            await self.msg.edit(embed=embed, view=None)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────
#  COG
# ─────────────────────────────────────────────────────────────

class ExamCog(commands.Cog, name="Exam"):

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _run_exam(self, ctx: commands.Context, p: dict, skip_checks: bool = False):
        """Shared exam logic used by both sl exam and sl admin exam."""
        rank = p.get("rank", "E")
        if rank == "S":
            return await ctx.send("❌ Already S Rank — no exam available.")

        next_rank = RANK_ORDER[RANK_ORDER.index(rank) + 1]
        re_cur    = _rank_emoji(rank)
        re_next   = _rank_emoji(next_rank)
        shadow    = build_shadow(p, rank)
        re_shadow = "👁️" if shadow["is_igris"] else "🌑"

        igris_extra = (
            "\n\n⚠️ **Special Rule:** Igris activates **Phase 2** below 35% HP.\n"
            "*+25% ATK, increased aggression.*"
        ) if shadow["is_igris"] else ""

        admin_tag = "\n\n🛠️ *[ADMIN TEST — no cooldown, no eligibility check]*" if skip_checks else ""

        confirm_embed = discord.Embed(
            title="[ SYSTEM ] — Hunter Rank Examination",
            description=(
                f"**{ctx.author.display_name}**, the System has selected your trial.\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"**Your Rank:** {re_cur} **{rank}** → {re_next} **{next_rank}**\n"
                f"**Your Level:** {p.get('level', 1)}\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"{re_shadow} **Shadow Opponent:** {shadow['name']}\n"
                f"❤️ HP: `{shadow['max_hp']:,}` · "
                f"⚔️ ATK: `{shadow['atk']:,}` · "
                f"🛡️ DEF: `{shadow['def']:,}`\n"
                f"⚡ Enters **Rage Mode** below 40% HP (+15% DMG, +10% Crit)"
                f"{igris_extra}\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"**If you win:** Rank advances + stat bonuses.\n"
                f"**If you lose:** Try again tomorrow.\n\n"
                f"*The battle will take place in this channel.*"
                f"{admin_tag}"
            ),
            color=RANK_COLORS.get(rank, 0x7B2FBE),
        )
        confirm_embed.set_footer(text="React within 60 seconds or the exam will be cancelled.")

        view = _ExamStartView(ctx.author)
        pub_msg = await ctx.send(embed=confirm_embed, view=view)
        await view.wait()

        if not view.confirmed:
            return await pub_msg.edit(
                embed=discord.Embed(
                    title="[ SYSTEM ] — Exam Withdrawn",
                    description="*You withdrew from the examination. Come back when ready.*",
                    color=0x555577,
                ),
                view=None,
            )

        await pub_msg.edit(
            embed=discord.Embed(
                description=(
                    f"⚡ **{ctx.author.display_name}**, your shadow trial begins now!\n"
                    f"Fight **{shadow['name']}** here in the channel."
                ),
                color=0x7B2FBE,
            ),
            view=None,
        )

        # Only mark cooldown for real exams
        if not skip_checks:
            p["exam_taken_today"] = True
            p["exam_date"] = datetime.datetime.utcnow().strftime("%Y-%m-%d")
            save_player(ctx.author.id, p)

        player_first = p.get("spd", 15) >= shadow["spd"]
        order_line   = "⚡ You attack first!" if player_first else "⚡ The shadow strikes first!"

        intro_embed = discord.Embed(
            title=f"[ SHADOW TRIAL ] — {shadow['name']}",
            description=(
                f"```\n■ SHADOW TRIAL INITIATED\n```\n"
                f"The shadow materialises before you.\n"
                f"**{shadow['name']}** stands in your way.\n\n"
                f"{order_line}\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"**Your HP:** `{p['hp']:,}`\n"
                f"**Shadow HP:** `{shadow['max_hp']:,}`\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"**Actions:**\n"
                f"⚔️ **Attack** — Strike the shadow\n"
                f"🛡️ **Defend** — Halve incoming damage this turn\n"
                f"💧 **Rest** — Recover 5% HP (shadow still attacks)\n"
            ),
            color=RANK_COLORS.get(rank, 0x7B2FBE),
        )

        battle_view = ExamBattleView(self, p, shadow, ctx.channel)

        if not player_first:
            dmg, is_crit, dodged = exam_damage(shadow, p)
            if not dodged:
                battle_view.p_hp = max(0, battle_view.p_hp - dmg)
                tag = " ⚡ CRIT!" if is_crit else ""
                battle_view._add_log(f"👁️ {shadow['name']} struck first — **{dmg:,}** dmg{tag}")
            else:
                battle_view._add_log(f"💨 You dodged the opening strike!")

        channel_msg = await ctx.channel.send(embed=intro_embed, view=battle_view)
        battle_view.msg = channel_msg
        await battle_view.wait()

        p_fresh = get_player(ctx.author.id)
        if battle_view.result == "win":
            new_rank = rank_up(p_fresh)
            save_player(ctx.author.id, p_fresh)
            re_new = _rank_emoji(new_rank)
            await ctx.send(embed=discord.Embed(
                title="[ SYSTEM ] — Rank Advancement",
                description=(
                    f"🎉 **{ctx.author.display_name}** has defeated **{shadow['name']}**!\n\n"
                    f"{re_cur} **{rank}** → {re_new} **{new_rank}**\n\n"
                    f"*The System acknowledges your growth.*"
                ),
                color=RANK_COLORS.get(new_rank, 0x7B2FBE),
            ))
        else:
            await ctx.send(embed=discord.Embed(
                title="[ SYSTEM ] — Trial Failed",
                description=(
                    f"**{ctx.author.display_name}** was defeated by **{shadow['name']}**.\n"
                    f"Rank remains {re_cur} **{rank}**."
                    + ("" if skip_checks else " Try again tomorrow."),
                ),
                color=0xFF4444,
            ))

    # FIX (Bugs 1 & 2): removed duplicate decorator and duplicate method definition
    # FIX (CommandRegistrationError): removed admin group — admin exam is now
    #   registered by cogs/admin/admin.py via ExamCog._admin_exam_impl()
    @commands.command(name="exam", aliases=["hunterexam", "rankup"])
    async def hunter_exam(self, ctx: commands.Context):
        """Take the Hunter Rank Exam — fight a shadow to advance your rank."""
        p = get_player(ctx.author.id)
        if not p:
            return await ctx.send("❌ Not registered. Use `sl start` first.")

        eligible, reason = can_take_exam(p)
        if not eligible:
            return await ctx.send(embed=discord.Embed(
                title="[ SYSTEM ] — Exam Unavailable",
                description=f"❌ {reason}",
                color=0xFF4444,
            ))

        await self._run_exam(ctx, p, skip_checks=False)

    async def _admin_exam_impl(self, ctx: commands.Context):
        """Called by the admin cog's 'admin exam' subcommand to avoid command name clash."""
        p = get_player(ctx.author.id)
        if not p:
            return await ctx.send("❌ Not registered. Use `sl start` first.")

        rank = p.get("rank", "E")
        if rank == "S":
            return await ctx.send("❌ Already S Rank — nothing to test.")

        await ctx.send("🛠️ **[ADMIN TEST]** — Bypassing eligibility & cooldown.", delete_after=5)
        await self._run_exam(ctx, p, skip_checks=True)

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CommandInvokeError):
            print(f"[ExamCog] ❌ {ctx.command}: {error.original}")
            await ctx.send("⚠️ Something went wrong during the exam. Try again.", delete_after=8)
        else:
            raise error


# ─────────────────────────────────────────────────────────────
#  CONFIRM VIEW
# ─────────────────────────────────────────────────────────────

class _ExamStartView(discord.ui.View):
    def __init__(self, author: discord.Member):
        super().__init__(timeout=60)
        self.author    = author
        self.confirmed = False

    @discord.ui.button(label="✅ Enter the Trial", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author.id:
            return await interaction.response.send_message("❌ Not your exam.", ephemeral=True)
        self.confirmed = True
        self.stop()
        await interaction.response.defer()

    @discord.ui.button(label="❌ Back Down", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author.id:
            return await interaction.response.send_message("❌ Not your exam.", ephemeral=True)
        self.confirmed = False
        self.stop()
        await interaction.response.defer()


async def setup(bot: commands.Bot):
    await bot.add_cog(ExamCog(bot))
