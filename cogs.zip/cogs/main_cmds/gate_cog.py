"""
cogs/gate_cog.py — Gate System
================================
Architecture:
  • MongoDB → players collection
  • SQLite  → emojis, rank_images

Gate Access Rules:
  • ALL ranks can enter ANY gate rank (team play encouraged)
  • Higher-rank gates will be harder but beatable with teammates
  • S Rank gates (for solo spawn) still rolled by player rank
  • National Level → ALL gates including S

Battle Formula (from updated_gate_battle_formula.txt):
  damage = (ATK * skill_mult) * (100 / (100 + DEF))
  crit   = min(5 + PREC*0.5, 50)%  → ×1.75
  dodge  = min(SPD/(SPD+120)*100, 25)%
  turn order by SPD
"""

import discord
from discord.ext import commands
import asyncio
import random
import time

from database import MongoDB
from cogs.admin.emoji_manager import get_emoji as db_get_emoji  # reads emojis.json (not DB directly)
from cogs.player.player_cog import (
    get_player, save_player,
    RANK_COLORS, RANK_ORDER,
    apply_level_up, xp_to_next,
    _rank_emoji, _stat_emoji,
    get_unlocked_skills, SKILLS,
)

from cogs.admin.admin import is_bot_admin as is_admin

# ─────────────────────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────────────────────

GRID_SIZE          = 9
MONSTERS_PER_GATE  = 10
JOIN_WINDOW        = 120    # seconds to join
GATE_TIMER         = 300    # seconds before gate expires
MAX_HUNTERS        = 4
MOVE_COOLDOWN      = 0.7
DM_COMBAT_TIMEOUT  = 180
GATE_SUMMON_CD_S   = 30
FORCE_START_COUNT  = 3
GUILD_BANK_CUT     = 0.20
BOSS_CAP_MULT      = 0.40
DEAD_DAMAGE_MULT   = 0.50
REVIVE_HP_PCT      = 0.40

PLAYER_CORNERS = [(0,0),(0,8),(8,0),(8,8)]
GATE_PING_ROLE = "Gate Ping"

# Gate access — ALL players can enter ANY gate rank (teammates cover higher-rank gates)
# S Rank gates still require National Level for solo spawn, but joining is open
GATE_ACCESS = {
    "E": ["E","D","C","B","A","S"],
    "D": ["E","D","C","B","A","S"],
    "C": ["E","D","C","B","A","S"],
    "B": ["E","D","C","B","A","S"],
    "A": ["E","D","C","B","A","S"],
    "S": ["E","D","C","B","A","S"],
}

RANK_META = {
    "E": {"color": 0x555577, "threat": "Low",     "rewards": "Low-Tier Loot"},
    "D": {"color": 0x1E5FBE, "threat": "Moderate","rewards": "Common Loot"},
    "C": {"color": 0x1A8C4E, "threat": "High",    "rewards": "Uncommon Loot"},
    "B": {"color": 0x7B2FBE, "threat": "Extreme", "rewards": "Rare Loot"},
    "A": {"color": 0xCC6600, "threat": "Deadly",  "rewards": "Epic Loot"},
    "S": {"color": 0xCC1133, "threat": "???",     "rewards": "Legendary Loot"},
}

# Post-gate chests
POST_GATE_CHESTS = {
    "E": {"label": "Bronze Chest",  "emoji": "📦", "gold": (500,   1_500)},
    "D": {"label": "Silver Chest",  "emoji": "🪙",  "gold": (1_500, 5_000)},
    "C": {"label": "Gold Chest",    "emoji": "🏆",  "gold": (5_000, 15_000)},
    "B": {"label": "Shadow Chest",  "emoji": "🔮",  "gold": (15_000,40_000)},
    "A": {"label": "Monarch Chest", "emoji": "👑",  "gold": (40_000,100_000)},
    "S": {"label": "Ruler's Chest", "emoji": "👁️",  "gold": (100_000,300_000)},
}

KEY_DROP_CHANCE = {
    "E": 0.10, "D": 0.15, "C": 0.20,
    "B": 0.25, "A": 0.35, "S": 0.50,
}

GOLD_PER_KILL = {
    "E": 40, "D": 100, "C": 200,
    "B": 400, "A": 800, "S": 1500,
}

# Active gate sessions {channel_id: GateSession}
active_gates: dict = {}
gate_summon_cd: dict = {}

# ─────────────────────────────────────────────────────────────
#  MONSTER TEMPLATES
# ─────────────────────────────────────────────────────────────

MONSTERS = {
    "E": [
        {"name":"Archer Goblin",    "hp":380,  "atk":38,  "def":8,  "spd":8,  "xp":50,  "gold":30,
         "emoji":"<:archer_goblin:1487523311196831764>","ability":"bypass_dodge","ability_chance":0.15,
         "ability_desc":"Focus Shot — 15% chance to bypass your dodge."},
        {"name":"Gooey Slime",      "hp":310,  "atk":32,  "def":6,  "spd":5,  "xp":45,  "gold":25,
         "emoji":"<:slime:1487523887938928691>","ability":"speed_reduce","ability_chance":0.15,
         "ability_desc":"Viscous Body — 15% chance to reduce your speed."},
        {"name":"Swordsman Goblin", "hp":460,  "atk":44,  "def":16, "spd":10, "xp":60,  "gold":35,
         "emoji":"<:swordsman_goblin:1487523894700015817>","ability":"crit_ignore_armor","ability_chance":0.10,
         "ability_desc":"Rusty Blade — 10% chance for a crit hit."},
        {"name":"Wild Wolf",        "hp":400,  "atk":48,  "def":10, "spd":12, "xp":55,  "gold":28,
         "emoji":"<:wild_wolf:1487523892489752698>","ability":"bleed","ability_chance":0.15,"ability_value":0.03,
         "ability_desc":"Deep Laceration — 15% chance to inflict Bleed (DoT)."},
        {"name":"Vampire Bat",      "hp":280,  "atk":42,  "def":4,  "spd":15, "xp":48,  "gold":22,
         "emoji":"<:vampire_bat:1487523893626535956>","ability":"evasion","ability_chance":0.13,
         "ability_desc":"Slight Evasion — 13% dodge rate."},
    ],
    "D": [
        {"name":"Feral Hobgoblin",  "hp":1540, "atk":209, "def":77, "spd":14, "xp":120, "gold":80,
         "emoji":"👹","ability":"brute_crit","ability_chance":0.20,"ability_value":0.10,
         "ability_desc":"Brute Force — 20% crit, ignores 10% armor."},
        {"name":"Red-Skin Imp",     "hp":1232, "atk":220, "def":44, "spd":18, "xp":140, "gold":90,
         "emoji":"😈","ability":"evasion","ability_chance":0.17,
         "ability_desc":"Agile Dash — 17% dodge rate."},
        {"name":"Spore Shaman",     "hp":1364, "atk":198, "def":55, "spd":11, "xp":130, "gold":85,
         "emoji":"🍄","ability":"paralyze","ability_chance":0.25,
         "ability_desc":"Numb Dust — 25% chance to paralyze (skip your next turn)."},
        {"name":"Crypt Skeleton",   "hp":1650, "atk":176, "def":132,"spd":8,  "xp":150, "gold":100,
         "emoji":"💀","ability":"bone_shield","ability_chance":0.25,
         "ability_desc":"Bone Shield — 25% chance to block physical attacks."},
        {"name":"Noxious Lizard",   "hp":1166, "atk":209, "def":33, "spd":13, "xp":125, "gold":75,
         "emoji":"🦎","ability":"poison","ability_chance":0.25,"ability_value":0.04,
         "ability_desc":"Toxic Slime — 25% chance to Poison (DoT)."},
    ],
    "C": [
        {"name":"Crimson Orc Giant","hp":1980, "atk":341, "def":99, "spd":12, "xp":200, "gold":150,
         "emoji":"👺","ability":"bloodlust","ability_chance":0.30,
         "ability_desc":"Bloodlust — 30% crit chance."},
        {"name":"Naga Warlord",     "hp":2420, "atk":308, "def":176,"spd":14, "xp":220, "gold":160,
         "emoji":"🐍","ability":"disable_skills","ability_chance":0.35,
         "ability_desc":"Paralytic Spit — 35% chance to disable skills 1 turn."},
        {"name":"Shadow Assassin",  "hp":1870, "atk":352, "def":77, "spd":22, "xp":210, "gold":155,
         "emoji":"🌑","ability":"shadow_blend","ability_chance":0.25,
         "ability_desc":"Shadow Blend — 25% chance attacks miss."},
        {"name":"Stone Golem",      "hp":2156, "atk":286, "def":132,"spd":6,  "xp":215, "gold":158,
         "emoji":"🗿","ability":"granite_skin","ability_chance":1.0,"ability_value":0.25,
         "ability_desc":"Granite Skin — reduces all incoming damage by 25%."},
        {"name":"Undead Necromancer","hp":1716,"atk":330, "def":44, "spd":10, "xp":205, "gold":145,
         "emoji":"☠️","ability":"mana_drain","ability_chance":0.30,
         "ability_desc":"Soul Burn — 30% chance to drain your MP on every hit."},
    ],
    "B": [
        {"name":"Minotaur General", "hp":2310, "atk":528, "def":143,"spd":15, "xp":300, "gold":250,
         "emoji":"🐂","ability":"pulverize","ability_chance":0.40,"ability_value":0.50,
         "ability_desc":"Pulverizing Strike — 40% crit, bypasses 50% armor."},
        {"name":"Cerelian Phantom", "hp":2420, "atk":484, "def":110,"spd":28, "xp":320, "gold":270,
         "emoji":"👻","ability":"blizzard_step","ability_chance":0.35,
         "ability_desc":"Blizzard Step — 35% dodge rate."},
        {"name":"Armored Cerberus", "hp":2970, "atk":440, "def":198,"spd":18, "xp":330, "gold":280,
         "emoji":"🐕","ability":"burn_aura","ability_chance":1.0,"ability_value":0.04,
         "ability_desc":"Heat Aura — guaranteed Burn damage every turn."},
        {"name":"Phoenix Serpent",  "hp":2530, "atk":506, "def":143,"spd":20, "xp":315, "gold":265,
         "emoji":"🔥","ability":"reflect_projectile","ability_chance":0.35,
         "ability_desc":"Wind Shield — 35% chance to reflect attacks."},
        {"name":"Hell Knight",      "hp":2640, "atk":550, "def":121,"spd":16, "xp":310, "gold":260,
         "emoji":"⚫","ability":"execution","ability_chance":0.45,
         "ability_desc":"Execution — 45% crit (×3 DMG) if your HP is below 30%."},
    ],
    "A": [
        {"name":"Demon Commander",  "hp":3300, "atk":737, "def":187,"spd":20, "xp":450, "gold":400,
         "emoji":"👿","ability":"fear_aura","ability_chance":1.0,"ability_value":0.50,
         "ability_desc":"Fear Aura — reduces your dodge chance by 50% for this fight."},
        {"name":"Void Weaver",      "hp":3960, "atk":704, "def":176,"spd":24, "xp":500, "gold":450,
         "emoji":"🌀","ability":"phase_shift","ability_chance":0.45,
         "ability_desc":"Phase Shift — 45% chance to hide (2 turns, attacks fail)."},
        {"name":"Hydra",            "hp":4400, "atk":660, "def":220,"spd":12, "xp":480, "gold":420,
         "emoji":"🐲","ability":"regen_heads","ability_chance":1.0,"ability_value":0.15,
         "ability_desc":"Regenerative Heads — heals 15% HP/turn."},
        {"name":"Soul Reaper",      "hp":3630, "atk":759, "def":198,"spd":18, "xp":460, "gold":410,
         "emoji":"💀","ability":"mana_siphon","ability_chance":0.55,
         "ability_desc":"Mana Siphon — 55% chance to heal by draining your MP."},
        {"name":"Blood Alchemist",  "hp":3410, "atk":748, "def":187,"spd":16, "xp":470, "gold":415,
         "emoji":"🩸","ability":"bleed_heal","ability_chance":0.50,"ability_value":0.05,
         "ability_desc":"Sanguine Harvest — bleed + heals 100% of bleed damage."},
    ],
    "S": [
        {"name":"Infernal Dragon",  "hp":4840, "atk":1078,"def":286,"spd":22, "xp":700, "gold":650,
         "emoji":"🔴","ability":"dragon_pressure","ability_chance":1.0,"ability_value":0.30,
         "ability_desc":"Dragon's Pressure — reduces all your stats by 30%."},
        {"name":"Void Emperor",     "hp":5500, "atk":990, "def":330,"spd":28, "xp":800, "gold":750,
         "emoji":"⚫","ability":"world_breaker","ability_chance":0.50,
         "ability_desc":"World Breaker — 50% chance to ignore all your DEF."},
        {"name":"Shadow General",   "hp":5060, "atk":1034,"def":308,"spd":30, "xp":750, "gold":700,
         "emoji":"🌑","ability":"shadow_domain","ability_chance":0.40,
         "ability_desc":"Shadow Domain — 40% miss chance on all your attacks."},
    ],
}

def _resolve_monster_emoji(monster_name: str, fallback: str) -> dict:
    """
    Returns a dict: {"emoji_str": str, "is_link": bool}
    Fuzzy match against emojis.json:
      1. Exact key:   "archer_goblin"
      2. m_ prefix:   "m_archer_goblin"
      3. Partial word match
    Falls back to {"emoji_str": fallback, "is_link": False}
    """
    try:
        from cogs.admin.emoji_manager import load_emoji_json
        data = load_emoji_json()
        slug  = monster_name.lower().replace(" ", "_").replace("-", "_")
        words = [w for w in slug.split("_") if len(w) > 2]

        def _entry(e):
            return {"emoji_str": e["emoji_str"], "is_link": bool(e.get("is_link", False))}

        if slug in data:
            return _entry(data[slug])
        if f"m_{slug}" in data:
            return _entry(data[f"m_{slug}"])
        for key, entry in data.items():
            for word in words:
                if word in key:
                    return _entry(entry)
    except Exception:
        pass
    # fallback: detect if it looks like a URL
    is_link = isinstance(fallback, str) and fallback.startswith("http")
    return {"emoji_str": fallback, "is_link": is_link}


def _inject_monster_emojis():
    """Replace hardcoded emojis in MONSTERS and BOSSES with DB/JSON values where available."""
    for rank_list in MONSTERS.values():
        for mob in rank_list:
            entry = _resolve_monster_emoji(mob["name"], mob.get("emoji", "👾"))
            mob["emoji"]    = entry["emoji_str"]
            mob["is_link"]  = entry["is_link"]
    for boss in BOSSES.values():
        entry = _resolve_monster_emoji(boss["name"], boss.get("emoji", "👾"))
        boss["emoji"]   = entry["emoji_str"]
        boss["is_link"] = entry["is_link"]


BOSSES = {
    "E": {"name":"Goblin King",    "emoji":"👺", "hp":3000,   "atk":45,   "def":20,   "spd":8,  "xp":300,  "gold":500},
    "D": {"name":"Iron Troll Lord","emoji":"🧌", "hp":7000,   "atk":130,  "def":55,   "spd":10, "xp":600,  "gold":1200},
    "C": {"name":"Chaos Chimera",  "emoji":"🐉", "hp":15000,  "atk":280,  "def":110,  "spd":13, "xp":1000, "gold":3000},
    "B": {"name":"Doom Warlord",   "emoji":"⚔️", "hp":32000,  "atk":520,  "def":200,  "spd":16, "xp":2000, "gold":7000},
    "A": {"name":"Abyss Monarch",  "emoji":"👑", "hp":70000,  "atk":900,  "def":380,  "spd":20, "xp":4000, "gold":15000},
    "S": {"name":"Shadow Dragon",  "emoji":"🔴", "hp":160000, "atk":1800, "def":650,  "spd":26, "xp":8000, "gold":40000},
}

# ─────────────────────────────────────────────────────────────
#  BATTLE FORMULA
# ─────────────────────────────────────────────────────────────

def calc_damage(attacker: dict, defender: dict, skill_mult: float = 1.0) -> tuple[int, bool, bool]:
    """
    Returns (damage, is_crit, is_dodge).
    Updated formula — supports cross-rank teams:
      dodge  = min(SPD/(SPD+120)*100, 25)%
      damage = ATK * mult * (100/(100+DEF))
      crit   = min(5 + PREC*0.5, 50)% → ×1.75
      rank_gap_floor: low-rank hunters in high-rank gates get a DMG floor
                      so they can still contribute alongside teammates
    """
    spd_d        = defender.get("spd", 10)
    dodge_chance = min((spd_d / (spd_d + 120)) * 100, 25)
    if random.uniform(0, 100) <= dodge_chance:
        return 0, False, True

    atk  = attacker.get("atk", 50)
    def_ = defender.get("def", 20)

    # Rank-gap soft boost — E rank in S gate still deals real (small) damage
    a_rank    = attacker.get("rank", "E")
    g_rank    = defender.get("gate_rank", a_rank)
    a_idx     = RANK_ORDER.index(a_rank) if a_rank in RANK_ORDER else 0
    g_idx     = RANK_ORDER.index(g_rank) if g_rank in RANK_ORDER else 0
    gap       = max(0, g_idx - a_idx)
    dmg_floor = int(def_ * 0.30 * (1 + gap * 0.10)) if gap > 0 else 0

    raw = max(dmg_floor, (atk * skill_mult) * (100 / (100 + def_)))

    prec        = attacker.get("prec", 10)
    crit_chance = min(5 + prec * 0.5, 50)
    is_crit     = random.uniform(0, 100) <= crit_chance
    if is_crit:
        raw *= 1.75

    # ±8% variance
    raw = raw * random.uniform(0.92, 1.08)
    return max(1, int(raw)), is_crit, False


def safe_boss_dmg(dmg: int, cur_hp: int, max_hp: int) -> int:
    """Boss can't one-shot a hunter above 50% HP."""
    if max_hp > 0 and cur_hp > max_hp * 0.50:
        return min(dmg, int(cur_hp * 0.60))
    return dmg


# ─────────────────────────────────────────────────────────────
#  GRID HELPERS
# ─────────────────────────────────────────────────────────────

PLAYER_EMOJIS    = ["🔵","🟡","🟠","🔴"]
DEAD_EMOJI       = "💀"

# Grid border/bg emojis — fetched from DB (same source as utils)
try:
    _BG_EMOJI            = db_get_emoji("grid_bg")            or "⬛"
    _GRID_BORDER_SIDE    = db_get_emoji("grid_border_side")   or "🔲"
    _GRID_BORDER_CORNER  = db_get_emoji("grid_border_corner") or "🔳"
    _DEFEATED_MOB_EMOJI  = db_get_emoji("defeated_mob")       or "❌"
except Exception:
    _BG_EMOJI            = "⬛"
    _GRID_BORDER_SIDE    = "🔲"
    _GRID_BORDER_CORNER  = "🔳"
    _DEFEATED_MOB_EMOJI  = "❌"


def _get_hunter_sprite(hunter: dict, index: int) -> str:
    """Return the hunter's directional sprite if available, else coloured dot."""
    try:
        from cogs.admin.emoji_manager import get_emoji as _ge
        direction = hunter.get("last_dir", "fv")
        cls       = hunter.get("class", "Assassin")
        key  = f"{cls.lower()}_{direction}"
        val  = _ge(key)
        if val:
            return val
    except Exception:
        pass
    return PLAYER_EMOJIS[index % len(PLAYER_EMOJIS)]


def _spawn_monster_positions(n: int) -> list[tuple]:
    forbidden = set(PLAYER_CORNERS)
    eligible  = [(r,c) for r in range(GRID_SIZE) for c in range(GRID_SIZE) if (r,c) not in forbidden]
    return random.sample(eligible, min(n, len(eligible)))


def build_grid(hunters: dict, monsters: list) -> str:
    """
    Render the 9×9 gate grid with a border frame (matches utils.build_grid).
    Border: corner emoji top-left + border-side emojis along top & left.
    Inner: bg emoji default.
    - Monsters: shown only when revealed/locked. Dead = defeated mob emoji.
    - Hunters: directional sprite if available, else coloured dot. Dead = 💀.
    - Treasure cells are invisible until discovered (not rendered).
    """
    grid = [[_BG_EMOJI] * GRID_SIZE for _ in range(GRID_SIZE)]

    # Place monsters
    for m in monsters:
        if m["revealed"]:
            grid[m["row"]][m["col"]] = _DEFEATED_MOB_EMOJI if not m["alive"] else m.get("emoji", "👾")

    # Place hunters — allow multiple on same tile, show first
    tile_counts = {}
    for h in hunters.values():
        if h.get("alive", True):
            key = (h["row"], h["col"])
            tile_counts[key] = tile_counts.get(key, 0) + 1

    placed = set()
    for i, (uid, h) in enumerate(hunters.items()):
        r, c = h["row"], h["col"]
        if not h.get("alive", True):
            grid[r][c] = DEAD_EMOJI
        else:
            key = (r, c)
            if key not in placed:
                grid[r][c] = _get_hunter_sprite(h, i)
                placed.add(key)

    # Add border frame
    SEP     = " "
    top_row = _GRID_BORDER_CORNER + (SEP + _GRID_BORDER_SIDE) * GRID_SIZE
    rows    = [top_row]
    for row in grid:
        rows.append(_GRID_BORDER_SIDE + SEP + SEP.join(row))

    return "\n".join(rows)

def _hp_bar(cur: int, max_: int, length: int = 10) -> str:
    pct    = max(0, min(cur/max(max_,1), 1.0))
    filled = int(pct * length)
    return "█"*filled + "░"*(length-filled)


def _xp_bar(xp: int, xp_next: int, length: int = 10) -> str:
    pct    = max(0, min(xp/max(xp_next,1), 1.0))
    filled = int(pct * length)
    return "█"*filled + "░"*(length-filled)


# ─────────────────────────────────────────────────────────────
#  GATE SESSION
# ─────────────────────────────────────────────────────────────

class GateSession:
    def __init__(self, rank: str, channel: discord.TextChannel, spawner_id: int):
        self.rank          = rank
        self.channel       = channel
        self.spawner_id    = spawner_id
        self.hunters       = {}        # {user_id: hunter_dict}
        self.monsters      = []
        self.grid_msg      = None
        self.boss_msg      = None
        self.boss_data     = None
        self.phase         = "joining"
        self.start_time    = time.time()
        self.battle_log    = []
        self.force_votes   = set()
        self._last_update  = 0
        self.total_monsters = MONSTERS_PER_GATE
        self.monster_pool  = MONSTERS.get(rank, MONSTERS["E"])
        self.boss_template = BOSSES.get(rank, BOSSES["E"])
        self._bot_ref      = None  # set when gate starts

    def place_monsters(self):
        positions  = _spawn_monster_positions(self.total_monsters)
        templates  = random.choices(self.monster_pool, k=self.total_monsters)
        self.monsters = []
        for i,(row,col) in enumerate(positions):
            t = templates[i].copy()
            self.monsters.append({
                **t,
                "gate_rank":    self.rank,   # used by calc_damage for rank-gap scaling
                "current_hp": t["hp"],
                "row": row, "col": col,
                "alive": True, "locked_by": None, "revealed": False,
                "bleed_turns": 0, "bleed_dmg": 0,
                "poison_turns": 0,
                "phase_hidden": 0,
                "pressure_applied": False,
                "fear_applied": False,
            })

    def all_monsters_dead(self) -> bool:
        return all(not m["alive"] for m in self.monsters)

    def all_hunters_dead(self) -> bool:
        return all(not h.get("alive", True) for h in self.hunters.values())

    def monster_at(self, row: int, col: int):
        for m in self.monsters:
            if m["alive"] and m["row"]==row and m["col"]==col:
                return m
        return None

    def killed_count(self) -> int:
        return sum(1 for m in self.monsters if not m["alive"])

    def add_log(self, entry: str):
        self.battle_log.append(entry)
        if len(self.battle_log) > 4:
            self.battle_log = self.battle_log[-4:]

    def get_log(self) -> str:
        return "\n".join(f"→ {e}" for e in self.battle_log) if self.battle_log else "*No actions yet.*"


# ─────────────────────────────────────────────────────────────
#  EMBED BUILDERS
# ─────────────────────────────────────────────────────────────

def _get_gate_image() -> str:
    """
    Load gate image URL — checked once per bot run and cached in GATE_IMAGE_URL.

    Priority:
      1. emojis.json → get_emoji("gate_image")   (set via sl ea gate_image <url>)
      2. Fallback     → empty string
    Result is cached in GATE_IMAGE_URL so restarts only re-fetch once, not per embed.
    """
    # Try emojis.json (single source of truth)
    try:
        from cogs.admin.emoji_manager import get_emoji as _ge
        url = _ge("gate_image")
        if url and url.startswith("http"):
            return url
    except Exception:
        pass

    # Default fallback image
    return "https://cdn.discordapp.com/attachments/1482309921235144748/1510313498616529027/image0.jpg?ex=6a1c5c8e&is=6a1b0b0e&hm=2f88fd6a9c2b3f0b7cb8fde72fb41c7550788092b9c3ae44feead0c6eb3e71b4&"

# Cached at import time — re-fetched only on bot restart, never per embed call.
GATE_IMAGE_URL: str = _get_gate_image()

def _spawn_embed(session: GateSession) -> discord.Embed:
    meta           = RANK_META.get(session.rank, {})
    color          = meta.get("color", 0x7B2FBE)
    re             = _rank_emoji(session.rank)
    start_ts       = int(time.time()) + JOIN_WINDOW
    hunters_joined = len(session.hunters)

    if session.hunters:
        hunter_lines = "\n".join(
            f"{'🔵🟡🟠🔴'[i % 4]} <@{uid}> — {_rank_emoji(h['rank'])} {h['rank']} Rank"
            for i, (uid, h) in enumerate(session.hunters.items())
        )
    else:
        hunter_lines = "*Waiting for hunters...*"

    embed = discord.Embed(
        title="**A Gate Has Appeared!**",
        color=color,
    )
    embed.add_field(
        name="Gate Info",
        value=(
            f"• {re} **Rank** ﹕ {session.rank} Rank\n"
            f"• 🌐 **Status** ﹕ Stabilizing\n"
            f"• 📋 **Closes In** ﹕ <t:{start_ts}:R>\n"
            f"• 🏰 **Threat level** ﹕ {meta.get('threat', '???')}\n"
            f"• 💰 **Rewards** ﹕ {meta.get('rewards', '???' )}"
        ),
        inline=False,
    )
    embed.add_field(
        name=f"Hunters `{hunters_joined}/{MAX_HUNTERS}`",
        value=hunter_lines,
        inline=False,
    )
    embed.set_image(url=GATE_IMAGE_URL)
    embed.set_footer(text="System Notice • Press 🚪 Enter Gate to join")
    return embed

def _active_embed(session: GateSession) -> discord.Embed:
    meta   = RANK_META.get(session.rank, {})
    color  = meta.get("color", 0x7B2FBE)
    killed = session.killed_count()

    hunter_lines = []
    for i, (uid, h) in enumerate(session.hunters.items()):
        dot    = PLAYER_EMOJIS[i % len(PLAYER_EMOJIS)]
        status = ""
        if not h.get("alive", True):
            status = "  💀"
        elif h.get("in_combat"):
            status = "  ⚔️"
        hunter_lines.append(f"{dot} <@{uid}>{status}")
    hunters_str = "\n".join(hunter_lines) or "*None*"

    embed = discord.Embed(
        title="Gate Entered!",
        description=(
            f"> Complete the gate in **{GATE_TIMER // 60}** minutes to fight the boss and earn rewards"
        ),
        color=color,
    )
    embed.add_field(
        name="**Quest**",
        value=f"┗ Find and Neutralize **{killed}/{session.total_monsters}** monsters.",
        inline=False,
    )
    embed.add_field(
        name="Hunters",
        value=hunters_str,
        inline=False,
    )
    embed.add_field(
        name="Grid",
        value=build_grid(session.hunters, session.monsters),
        inline=False,
    )
    if session.battle_log:
        embed.set_footer(text="  ·  ".join(f"→ {e}" for e in session.battle_log[-2:]))
    else:
        embed.set_footer(text="System Notice • Clear before instability")
    return embed

def _boss_embed(session: GateSession) -> discord.Embed:
    boss  = session.boss_data
    color = RANK_META.get(session.rank,{}).get("color",0x7B2FBE)
    bar   = _hp_bar(boss["current_hp"], boss["max_hp"], 16)
    hunters_str = "\n".join(
        f"{PLAYER_EMOJIS[i]} **{h['name']}**  ❤️`{h['hp']:,}/{h['max_hp']:,}`"
        + (" 💀" if not h.get("alive",True) else "")
        for i,h in enumerate(session.hunters.values())
    )
    embed = discord.Embed(
        title=f"[ BOSS PHASE ] — {boss['name']}",
        description=(
            f"```ansi\n"
            f"\u001b[1;31m▓▓▓▓▓▓▓▓▓▓ BOSS BATTLE ▓▓▓▓▓▓▓▓▓▓\u001b[0m\n"
            f"```\n"
            f"❤️ **{boss['current_hp']:,} / {boss['max_hp']:,}**\n"
            f"`[{bar}]`"
        ),
        color=color,
    )
    embed.add_field(name="👥 Hunters", value=hunters_str, inline=False)
    embed.add_field(name="📜 Battle Log", value=session.get_log() or "*No actions yet.*", inline=False)
    embed.set_footer(text="Attack the boss to clear the gate!")
    return embed


def _encounter_embed(hunter: dict, monster: dict, p_log: str, m_log: str) -> discord.Embed:
    mp_cur    = hunter.get("mp", 0)
    raw_emoji = monster.get("emoji", "👾")
    is_link   = monster.get("is_link", False)

    embed = discord.Embed(
        title="Dungeon Encounter!",
        description="Defeat the **monster** to gain progress.",
        color=0x7B2FBE,
    )

    # ── Player section ────────────────────────────────────────
    player_val = f"MP: **{mp_cur}**\n❤️ Health: **{hunter['hp']:,}/{hunter['max_hp']:,}**"
    if p_log:
        player_val += f"\n{p_log}"
    embed.add_field(name=hunter["name"], value=player_val, inline=False)

    # ── Monster section ───────────────────────────────────────
    monster_val = f"❤️ Health: **{monster['current_hp']:,}/{monster['hp']:,}**"
    if m_log and m_log.strip():
        monster_val += f"\n{m_log.strip()}"
    embed.add_field(name=monster["name"], value=monster_val, inline=False)

    # ── Monster visual ────────────────────────────────────────
    # is_link=True  → URL image  → set_image (large, below fields, exactly like 2nd screenshot)
    # custom emoji  → <:name:id> → these ONLY work in guild channels, NOT in DMs
    #                 So in DM combat we show the emoji name as text fallback
    # unicode emoji → show enlarged (3× repeat)
    if is_link and raw_emoji.startswith("http"):
        embed.set_image(url=raw_emoji)
    elif raw_emoji.startswith("<:") or raw_emoji.startswith("<a:"):
        # Custom emoji doesn't render in DMs — show name as text placeholder
        # Extract name from <:name:id>
        try:
            emoji_name = raw_emoji.split(":")[1]
            embed.add_field(name="\u200b", value=f"*[ {emoji_name} ]*", inline=False)
        except Exception:
            pass
    else:
        # Unicode emoji — enlarge by repeating
        embed.add_field(name="\u200b", value=f"{raw_emoji}  {raw_emoji}  {raw_emoji}", inline=False)

    embed.set_footer(text=f"Choose your action from the menu below.")
    return embed


# ─────────────────────────────────────────────────────────────
#  JOIN VIEW
# ─────────────────────────────────────────────────────────────

class JoinView(discord.ui.View):
    def __init__(self, session: GateSession, channel_id: int, bot):
        super().__init__(timeout=JOIN_WINDOW)
        self.session    = session
        self.channel_id = channel_id
        self.bot        = bot

    @discord.ui.button(label="🚪 Enter Gate", style=discord.ButtonStyle.success)
    async def enter(self, interaction: discord.Interaction, button: discord.ui.Button):
        session = self.session
        uid     = interaction.user.id

        if uid in session.hunters:
            return await interaction.response.send_message("❌ Already in this gate.", ephemeral=True)
        if len(session.hunters) >= MAX_HUNTERS:
            return await interaction.response.send_message("❌ Gate is full.", ephemeral=True)
        if session.phase != "joining":
            return await interaction.response.send_message("❌ Gate already started.", ephemeral=True)

        player = get_player(uid)
        if not player:
            return await interaction.response.send_message("❌ Not registered. Use `sl start` first.", ephemeral=True)

        # Rank access — all ranks welcome (team play encouraged for higher-rank gates)
        # No restriction check needed — GATE_ACCESS is open for all
        p_rank = player.get("rank", "E")

        # Gate key check — consumed here on entry (skip for admin test gates)
        is_admin_gate = (session.spawner_id == 0)  # 0 = flag for admin-spawned
        if not is_admin_gate:
            if player.get("gate_keys", 0) <= 0:
                return await interaction.response.send_message(
                    "❌ You need a 🔑 **Gate Key** to enter. Earn one from `sl daily`.",
                    ephemeral=True,
                )
            player["gate_keys"] -= 1
            save_player(uid, player)

        # Build hunter snapshot from player data
        row, col = PLAYER_CORNERS[len(session.hunters) % 4]
        hunter = {
            "user_id":       uid,
            "name":          interaction.user.display_name,
            "rank":          p_rank,
            "level":         player.get("level", 1),   # needed for skill unlock checks
            "hp":            player["hp"],
            "max_hp":        player["hp"],
            "mp":            player.get("mp",200),
            "max_mp":        player.get("mp",200),
            "atk":           player.get("atk",130),
            "def":           player.get("def",50),
            "prec":          player.get("prec",15),
            "spd":           player.get("spd",15),
            "row": row, "col": col,
            "alive":         True,
            "in_combat":     False,
            "monsters_killed": 0,
            "xp_earned":     0,
            "boss_dmg_dealt":0,
            "bleed_turns":   0,
            "bleed_dmg":     0,
            "fear_miss":     0.0,
            "stun_turns":    0,
        }
        session.hunters[uid] = hunter

        await interaction.response.send_message(
            f"✅ **{interaction.user.display_name}** entered the gate! ({len(session.hunters)}/{MAX_HUNTERS})",
            ephemeral=False,
        )
        await _update_spawn_embed(session)

        if len(session.hunters) >= MAX_HUNTERS:
            self.stop()
            await _start_gate(session, self.channel_id, self.bot)

    @discord.ui.button(label="⚡ Force Start", style=discord.ButtonStyle.secondary)
    async def force_start(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = interaction.user.id
        if uid not in self.session.hunters:
            return await interaction.response.send_message("❌ Join the gate first.", ephemeral=True)
        self.session.force_votes.add(uid)
        count = len(self.session.force_votes)
        await interaction.response.send_message(
            f"⚡ Force-start vote: **{count}/{FORCE_START_COUNT}**", ephemeral=False
        )
        if count >= FORCE_START_COUNT and self.session.hunters:
            self.stop()
            await _start_gate(self.session, self.channel_id, self.bot)


# ─────────────────────────────────────────────────────────────
#  GRID ACTION VIEW (channel)
# ─────────────────────────────────────────────────────────────

class GridActionView(discord.ui.View):
    def __init__(self, session: GateSession, channel_id: int, bot):
        super().__init__(timeout=None)
        self.session    = session
        self.channel_id = channel_id
        self.bot        = bot

    @discord.ui.button(label="Move", style=discord.ButtonStyle.primary)
    async def move_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = interaction.user.id
        if uid not in self.session.hunters:
            return await interaction.response.send_message("❌ You're not in this gate.", ephemeral=True)
        hunter = self.session.hunters[uid]
        if not hunter.get("alive", True):
            return await interaction.response.send_message("💀 You've fallen. Await the boss phase.", ephemeral=True)
        if hunter.get("in_combat"):
            return await interaction.response.send_message("⚔️ You're already in combat.", ephemeral=True)
        view = MovementView(self.session, self.channel_id, uid, self.bot, self)
        msg  = await interaction.response.send_message("🧭 Choose your direction:", view=view, ephemeral=True)
        view.move_msg = await interaction.original_response()

    @discord.ui.button(label="Stats", style=discord.ButtonStyle.secondary)
    async def stats_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = interaction.user.id
        if uid not in self.session.hunters:
            return await interaction.response.send_message("❌ Not in this gate.", ephemeral=True)
        h   = self.session.hunters[uid]
        bar = _hp_bar(h["hp"], h["max_hp"])
        embed = discord.Embed(
            title=f"📊 {h['name']}'s Gate Stats",
            description=(
                f"❤️ HP: `[{bar}]` **{h['hp']:,}/{h['max_hp']:,}**\n"
                f"⚔️ ATK: `{h['atk']:,}`  🛡️ DEF: `{h['def']:,}`\n"
                f"🎯 PREC: `{h['prec']}`  💨 SPD: `{h['spd']}`\n"
                f"☠️ Kills: `{h['monsters_killed']}`"
            ),
            color=0x7B2FBE,
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="Logs", style=discord.ButtonStyle.success)
    async def log_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            embed=discord.Embed(description=self.session.get_log(), color=0x7B2FBE),
            ephemeral=True,
        )

    @discord.ui.button(label="Leave", style=discord.ButtonStyle.danger)
    async def leave_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = interaction.user.id
        if uid not in self.session.hunters:
            return await interaction.response.send_message("❌ Not in this gate.", ephemeral=True)
        h = self.session.hunters[uid]
        if h.get("in_combat"):
            return await interaction.response.send_message("❌ Can't leave mid-combat.", ephemeral=True)
        del self.session.hunters[uid]
        await interaction.response.send_message(f"🚪 **{interaction.user.display_name}** left the gate.", ephemeral=False)
        await _update_grid(self.session, bot=self.bot)
        if self.session.all_hunters_dead() or not self.session.hunters:
            await _end_fail(self.session, self.channel_id)


# ─────────────────────────────────────────────────────────────
#  MOVEMENT VIEW (ephemeral DM-style)
# ─────────────────────────────────────────────────────────────

class MovementView(discord.ui.View):
    def __init__(self, session, channel_id, uid, bot, grid_view):
        super().__init__(timeout=60)
        self.session    = session
        self.channel_id = channel_id
        self.uid        = uid
        self.bot        = bot
        self.grid_view  = grid_view
        self._last_move = 0
        self.move_msg   = None  # stores the ephemeral message for editing later

    async def _move(self, interaction, dr, dc):
        uid     = interaction.user.id
        session = self.session
        if uid != self.uid:
            return await interaction.response.send_message("❌ Not your controls.", ephemeral=True)

        now = time.time()
        if now - self._last_move < MOVE_COOLDOWN:
            return await interaction.response.send_message("⏳ Moving too fast!", ephemeral=True)
        self._last_move = now

        hunter = session.hunters.get(uid)
        if not hunter or not hunter.get("alive",True) or hunter.get("in_combat"):
            return await interaction.response.send_message("❌ Can't move right now.", ephemeral=True)

        nr = max(0, min(GRID_SIZE-1, hunter["row"] + dr))
        nc = max(0, min(GRID_SIZE-1, hunter["col"] + dc))

        # Check if another hunter is there
        for ou, oh in session.hunters.items():
            if ou != uid and oh.get("alive",True) and oh["row"]==nr and oh["col"]==nc:
                return await interaction.response.send_message("❌ Another hunter is there.", ephemeral=True)

        # Block movement onto a dead monster's cell
        for m in session.monsters:
            if not m["alive"] and m["row"] == nr and m["col"] == nc:
                return await interaction.response.send_message(
                    f"🚫 **{m['name']}** lies defeated here — path is blocked.",
                    ephemeral=True,
                )

        hunter["row"], hunter["col"] = nr, nc

        # Check monster encounter BEFORE grid update so emoji shows correctly
        monster = session.monster_at(nr, nc)
        if monster and monster.get("alive", True) and not monster["locked_by"]:
            monster["locked_by"] = uid
            monster["revealed"]  = True
            hunter["in_combat"]  = True

        # Now update grid (monster emoji will show if encountered)
        await interaction.response.defer()
        await _update_grid(session, force=True, bot=getattr(session, "_bot_ref", None))

        if monster and hunter.get("in_combat") and monster.get("locked_by") == uid:
            self.stop()
            await _start_combat(session, self.channel_id, hunter, monster, interaction, self.grid_view, self.bot, move_view=self)

    @discord.ui.button(label="↖", style=discord.ButtonStyle.secondary, row=0)
    async def pad_tl(self, i, b): pass

    @discord.ui.button(label="⬆️", style=discord.ButtonStyle.primary, row=0)
    async def up(self, i, b): await self._move(i, -1, 0)

    @discord.ui.button(label="↗", style=discord.ButtonStyle.secondary, row=0)
    async def pad_tr(self, i, b): pass

    @discord.ui.button(label="⬅️", style=discord.ButtonStyle.primary, row=1)
    async def left(self, i, b): await self._move(i, 0, -1)

    @discord.ui.button(label="⏺️", style=discord.ButtonStyle.secondary, row=1)
    async def center(self, i, b): pass

    @discord.ui.button(label="➡️", style=discord.ButtonStyle.primary, row=1)
    async def right(self, i, b): await self._move(i, 0, 1)

    @discord.ui.button(label="↙", style=discord.ButtonStyle.secondary, row=2)
    async def pad_bl(self, i, b): pass

    @discord.ui.button(label="⬇️", style=discord.ButtonStyle.primary, row=2)
    async def down(self, i, b): await self._move(i, 1, 0)

    @discord.ui.button(label="↘", style=discord.ButtonStyle.secondary, row=2)
    async def pad_br(self, i, b): pass


# ─────────────────────────────────────────────────────────────
#  COMBAT VIEW (ephemeral — only visible to the hunter)
# ─────────────────────────────────────────────────────────────

class DmCombatView(discord.ui.View):
    def __init__(self, session, channel_id, hunter, monster, grid_view, bot):
        super().__init__(timeout=DM_COMBAT_TIMEOUT)
        self.session        = session
        self.channel_id     = channel_id
        self.hunter         = hunter
        self.monster        = monster
        self.grid_view      = grid_view
        self.bot            = bot
        self.stun_turns     = 0
        self.move_view      = None   # set by _start_combat
        self.combat_msg     = None   # set after DM send
        self._add_select()           # build the action select menu

    # ── Build / rebuild the Select Menu ──────────────────────
    def _add_select(self):
        """Rebuild the action Select Menu (called on init + after each turn).
        Preserves non-Select items (e.g. Back to Gate link button)."""
        # Remove only existing Select items, keep buttons (link buttons etc.)
        self._children = [item for item in self.children if not isinstance(item, discord.ui.Select)]

        hunter = self.hunter
        level  = hunter.get("level", 1)
        mp_cur = hunter.get("mp", 0)

        options = [
            discord.SelectOption(
                label="Punch",
                value="__punch__",
                description="Basic attack",
                emoji="⚔️",
            )
        ]
        for sk in SKILLS:
            unlocked   = level >= sk["unlock_level"]
            affordable = mp_cur >= sk["mana_cost"]
            dmg_pct    = int(sk["power"] * 10)
            if not unlocked:
                desc  = f"Unlocks at Level {sk['unlock_level']}"
                emoji = "🔒"
            elif not affordable:
                desc  = f"Need {sk['mana_cost']} MP  (you have {mp_cur})"
                emoji = "💤"
            else:
                desc  = f"Level {level}  |  {dmg_pct}% Damage  |  MP Cost: {sk['mana_cost']}"
                emoji = "✨"
            options.append(discord.SelectOption(
                label=sk["name"],
                value=sk["id"],
                description=desc[:100],
                emoji=emoji,
            ))

        select = discord.ui.Select(
            placeholder="Choose your action...",
            options=options,
            row=0,
        )

        async def _on_select(interaction: discord.Interaction):
            if interaction.user.id != self.hunter["user_id"]:
                return await interaction.response.send_message("❌ Not your battle.", ephemeral=True)
            chosen = select.values[0]
            if chosen == "__punch__":
                await interaction.response.defer()
                await self._process(interaction, skill_id=None, already_deferred=True)
            else:
                sk_obj = next((s for s in SKILLS if s["id"] == chosen), None)
                if sk_obj:
                    if self.hunter.get("level", 1) < sk_obj["unlock_level"]:
                        return await interaction.response.send_message(
                            f"🔒 **{sk_obj['name']}** not unlocked yet.", ephemeral=True)
                    if self.hunter.get("mp", 0) < sk_obj["mana_cost"]:
                        return await interaction.response.send_message(
                            f"💤 Not enough MP for **{sk_obj['name']}** ({sk_obj['mana_cost']} needed).", ephemeral=True)
                await interaction.response.defer()
                await self._process(interaction, skill_id=chosen, already_deferred=True)

        select.callback = _on_select
        self.add_item(select)

    async def on_timeout(self):
        hunter  = self.hunter
        monster = self.monster
        hunter["in_combat"]  = False
        monster["locked_by"] = None
        self.stop()
        try:
            if self.combat_msg:
                await self.combat_msg.edit(
                    embed=discord.Embed(
                        title="[ SYSTEM ] — Combat Timed Out",
                        description="You took too long. The monster fled. You can move again.",
                        color=0xFF4444,
                    ),
                    view=None,
                )
        except Exception:
            pass
        await _update_grid(self.session, bot=self.bot)

    async def _process(self, interaction: discord.Interaction, skill_id: str | None = None, already_deferred: bool = False):
        if interaction.user.id != self.hunter["user_id"]:
            return await interaction.response.send_message("❌ Not your battle.", ephemeral=True)

        hunter  = self.hunter
        monster = self.monster

        # ── Resolve skill / normal attack ────────────────────
        skill      = None
        skill_mult = 1.0
        skill_log  = ""

        if skill_id:
            from cogs.player.player_cog import get_skill_by_id
            skill = get_skill_by_id(skill_id)
            if skill:
                # Check player level still meets requirement (safety)
                if hunter.get("level", 1) < skill["unlock_level"]:
                    return await interaction.response.send_message(
                        f"❌ **{skill['name']}** is not unlocked yet.", ephemeral=True
                    )
                # Check mana
                mp_cost = skill["mana_cost"]
                if hunter.get("mp", 0) < mp_cost:
                    return await interaction.response.send_message(
                        f"❌ Not enough MP! **{skill['name']}** costs `{mp_cost}` MP "
                        f"but you only have `{hunter.get('mp', 0)}` MP.",
                        ephemeral=True,
                    )
                # Deduct mana
                hunter["mp"] = max(0, hunter.get("mp", 0) - mp_cost)
                # Skill multiplier: power / 10 (e.g. power 40 → ×4.0, power 100 → ×10.0)
                skill_mult = skill["power"] / 10.0
                skill_log  = f"{skill['emoji']} **{skill['name']}** activated!"

        # ── Disable skills check (Naga Warlord ability) ──────
        if monster.get("ability") == "disable_skills" and skill_id:
            ab_chance = monster.get("ability_chance", 0)
            if random.random() < ab_chance:
                # Skill blocked — refund mana cost
                if skill:
                    hunter["mp"] = min(hunter.get("max_mp", 200), hunter.get("mp", 0) + skill["mana_cost"])
                p_log = f"🚫 **Paralytic Spit** — your skill was disrupted! MP refunded."
                embed = _encounter_embed(hunter, monster, p_log, "")
                try:
                    await self.combat_msg.edit(embed=embed, view=self)
                except Exception:
                    pass
                await interaction.response.defer()
                return

        # ── Player attacks monster ────────────────────────────
        p_log = skill_log

        # Fear aura check
        fear_miss = hunter.get("fear_miss", 0.0)
        if fear_miss > 0 and random.random() < fear_miss:
            p_log += ("\n" if p_log else "") + "😨 **Fear Aura** — your attack missed!"
            p_dmg = 0
        else:
            dmg, is_crit, dodged = calc_damage(hunter, monster, skill_mult=skill_mult)
            if dodged:
                p_log += ("\n" if p_log else "") + f"💨 **{monster['name']}** dodged your attack!"
                p_dmg = 0
            else:
                # Granite Skin: reduce incoming dmg by 25%
                if monster.get("ability") == "granite_skin":
                    dmg = int(dmg * 0.75)
                # Bone shield: block entirely
                if monster.get("ability") == "bone_shield" and random.random() < monster.get("ability_chance",0):
                    p_log += ("\n" if p_log else "") + f"🛡️ **{monster['name']}** blocked your attack! *(Bone Shield)*"
                    p_dmg = 0
                else:
                    monster["current_hp"] = max(0, monster["current_hp"] - dmg)
                    p_dmg = dmg
                    crit_tag = " ⚡ **CRIT!**" if is_crit else ""
                    skill_tag = f" *({skill['name']})*" if skill else ""
                    p_log += ("\n" if p_log else "") + f"⚔️ You dealt **{p_dmg:,}** damage{crit_tag}{skill_tag}"

        monster_dead = monster["current_hp"] <= 0
        m_log = ""

        # ── Monster retaliates ────────────────────────────────
        if not monster_dead:
            ability      = monster.get("ability","")
            ab_chance    = monster.get("ability_chance",0.0)
            ab_value     = monster.get("ability_value",0.0)
            ab_triggers  = random.random() < ab_chance

            # Phase shift
            if ability == "phase_shift" and ab_triggers and not monster.get("phase_hidden",0):
                monster["phase_hidden"] = 2
            if monster.get("phase_hidden",0) > 0:
                monster["phase_hidden"] -= 1
                m_log = f"👁️ **{monster['name']}** vanished — attacks fail! *(Phase Shift)*"
            elif self.stun_turns > 0:
                self.stun_turns -= 1
                m_log = f"⚡ **{monster['name']}** is stunned — skips turn!"
            else:
                # Dragon pressure
                if ability == "dragon_pressure" and not monster.get("pressure_applied"):
                    monster["pressure_applied"] = True
                    for stat in ("atk","def","hp","mp","prec","spd"):
                        hunter[stat] = max(1, int(hunter.get(stat,1) * (1-ab_value)))
                    hunter["max_hp"] = max(1, int(hunter["max_hp"] * (1 - ab_value)))
                    m_log = f"🐉 **Dragon's Pressure** — all your stats reduced by {int(ab_value*100)}%!"

                # Fear aura
                if ability == "fear_aura" and not monster.get("fear_applied"):
                    monster["fear_applied"] = True
                    hunter["fear_miss"] = ab_value
                    m_log += f"\n😨 **Fear Aura** — your dodge reduced by {int(ab_value*100)}%!"

                m_dmg, _, m_dodged = calc_damage(monster, hunter)

                if m_dodged:
                    m_log += f"\n💨 You dodged **{monster['name']}**'s attack!"
                else:
                    m_dmg = safe_boss_dmg(m_dmg, hunter["hp"], hunter["max_hp"])
                    hunter["hp"] = max(0, hunter["hp"] - m_dmg)
                    m_log += f"\n👾 **{monster['name']}** dealt **{m_dmg:,}** damage"

                # Burn aura
                if ability == "burn_aura":
                    burn = max(1, int(hunter["max_hp"] * ab_value))
                    hunter["hp"] = max(0, hunter["hp"] - burn)
                    m_log += f"\n🔥 **Burn Aura** — {burn:,} burn damage!"

                # Regen
                if ability == "regen_heads":
                    regen = int(monster["hp"] * ab_value)
                    monster["current_hp"] = min(monster["hp"], monster["current_hp"] + regen)
                    m_log += f"\n💚 **Regen Heads** — healed {regen:,} HP!"

                # Mana drain
                if ability in ("mana_drain","mana_siphon") and ab_triggers:
                    drain = min(hunter.get("mp",0), max(10, int(hunter.get("max_mp",200)*0.15)))
                    hunter["mp"] = max(0, hunter.get("mp",0) - drain)
                    if ability == "mana_siphon":
                        monster["current_hp"] = min(monster["hp"], monster["current_hp"] + drain*2)
                    m_log += f"\n💙 **{monster['name']}** drained **{drain}** MP!"

                # Paralyze
                if ability == "paralyze" and ab_triggers:
                    self.stun_turns = 1
                    m_log += f"\n⚡ **Numb Dust** — you're paralyzed! Skip next turn."

                # Bleed
                if ability in ("bleed","bleed_heal") and ab_triggers:
                    bleed_dmg = max(1, int(hunter["max_hp"] * ab_value))
                    hunter["bleed_turns"] = hunter.get("bleed_turns",0) + 2
                    hunter["bleed_dmg"]   = bleed_dmg
                    if ability == "bleed_heal":
                        monster["current_hp"] = min(monster["hp"], monster["current_hp"] + bleed_dmg)
                        m_log += f"\n🩸 **Sanguine Harvest** — Bleed! Monster healed {bleed_dmg:,}!"
                    else:
                        m_log += f"\n🩸 **Deep Laceration** — Bleed! {bleed_dmg:,}/turn for 2 turns."

                # Speed reduce
                if ability == "speed_reduce" and ab_triggers:
                    hunter["spd"] = max(1, int(hunter.get("spd",10)*0.70))
                    m_log += f"\n🐌 **Viscous Body** — your speed reduced!"

            # Bleed tick on hunter
            if hunter.get("bleed_turns",0) > 0:
                bdmg = hunter.get("bleed_dmg",0)
                hunter["hp"] = max(0, hunter["hp"] - bdmg)
                hunter["bleed_turns"] -= 1
                m_log += f"\n🩸 **Bleed** — {bdmg:,} damage! ({hunter['bleed_turns']} turns left)"

        hunter_dead  = hunter["hp"] <= 0
        monster_dead = monster["current_hp"] <= 0

        embed = _encounter_embed(hunter, monster, p_log, m_log.strip("\n"))

        # ── Monster died ──────────────────────────────────────
        if monster_dead:
            embed.color = 0x57F287
            embed.add_field(
                name=f"🏆 {monster['name']} defeated!",
                value=f"<:exp:1500854097170141276> **+{monster['xp']} XP** earned!\nYou may move again.",
                inline=False,
            )
            hunter["in_combat"]  = False
            monster["alive"]     = False
            monster["locked_by"] = None
            hunter["hp"]         = hunter["max_hp"]
            hunter["mp"]         = hunter["max_mp"]   # MP fully restored after each fight
            self.session.add_log(f"{hunter['name']} defeated {monster['name']}!")
            self.stop()

            # Build "Back to Gate" link so hunter can jump back to the battlefield
            _ch = self.session.channel
            _gm = self.session.grid_msg
            _gate_url = (
                f"https://discord.com/channels/{_ch.guild.id}/{_ch.id}/{_gm.id}"
                if _gm else f"https://discord.com/channels/{_ch.guild.id}/{_ch.id}"
            )
            _back_view = discord.ui.View()
            _back_view.add_item(discord.ui.Button(
                label="\u21a9 Back to Gate",
                style=discord.ButtonStyle.link,
                url=_gate_url,
            ))
            try:
                await self.combat_msg.edit(embed=embed, view=_back_view)
            except Exception:
                pass
            if not already_deferred:
                try:
                    await interaction.response.defer()
                except Exception:
                    pass
            await _award_xp(self.session, hunter, monster, interaction.user)
            await _update_grid(self.session, force=True, bot=self.bot)
            # Refresh the existing move message with a fresh MovementView
            if not self.session.all_monsters_dead() and self.move_view and self.move_view.move_msg:
                try:
                    new_move = MovementView(self.session, self.channel_id, hunter["user_id"], self.bot, self.grid_view)
                    await self.move_view.move_msg.edit(content="✅ Monster down! Choose your next move:", view=new_move)
                    new_move.move_msg = self.move_view.move_msg
                except Exception:
                    pass
            if self.session.all_monsters_dead():
                self.bot.loop.create_task(_start_boss(self.session, self.channel_id, self.bot))
            return

        # ── Hunter died ───────────────────────────────────────
        if hunter_dead:
            embed.color = 0xFF4444
            embed.add_field(
                name="💀 Defeated",
                value="You can still deal **50% damage** in the boss phase.",
                inline=False,
            )
            hunter["alive"]      = False
            hunter["in_combat"]  = False
            monster["locked_by"] = None
            self.session.add_log(f"{hunter['name']} was defeated by {monster['name']}!")
            self.stop()
            try:
                await self.combat_msg.edit(embed=embed, view=None)
            except Exception:
                pass
            if not already_deferred:
                try:
                    await interaction.response.defer()
                except Exception:
                    pass
            await _update_grid(self.session, bot=self.bot)
            if self.session.all_hunters_dead():
                await _end_fail(self.session, self.channel_id)
            return


        # ── Rebuild select (MP may have changed) then update message ──
        self._add_select()
        try:
            await self.combat_msg.edit(embed=embed, view=self)
        except Exception:
            pass
        if not already_deferred:
            try:
                await interaction.response.defer()
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────
#  BOSS COMBAT VIEW
# ─────────────────────────────────────────────────────────────

class BossCombatView(discord.ui.View):
    def __init__(self, session, channel_id, bot):
        super().__init__(timeout=None)
        self.session    = session
        self.channel_id = channel_id
        self.bot        = bot

    @discord.ui.button(label="⚔️ Attack", style=discord.ButtonStyle.danger, row=0)
    async def attack_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._boss_attack(interaction, skill_id=None)

    @discord.ui.button(label="🌑 Shadow Strike", style=discord.ButtonStyle.primary, row=1, custom_id="boss_shadow_strike")
    async def boss_shadow_strike(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._boss_attack(interaction, skill_id="shadow_strike")

    @discord.ui.button(label="⚡ Multi Strike", style=discord.ButtonStyle.primary, row=1, custom_id="boss_multi_strike")
    async def boss_multi_strike(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._boss_attack(interaction, skill_id="multi_strike")

    @discord.ui.button(label="🌀 Arc Slash", style=discord.ButtonStyle.primary, row=2, custom_id="boss_arc_slash")
    async def boss_arc_slash(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._boss_attack(interaction, skill_id="arc_slash")

    @discord.ui.button(label="💥 Shadow Burst", style=discord.ButtonStyle.danger, row=2, custom_id="boss_shadow_burst")
    async def boss_shadow_burst(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._boss_attack(interaction, skill_id="shadow_burst")

    async def _boss_attack(self, interaction: discord.Interaction, skill_id: str | None):
        session = self.session
        uid     = interaction.user.id

        if uid not in session.hunters:
            return await interaction.response.send_message("❌ Not in this gate.", ephemeral=True)

        if session.phase == "ended":
            return await interaction.response.send_message("❌ The gate has already ended.", ephemeral=True)

        hunter  = session.hunters[uid]
        boss    = session.boss_data
        is_dead = not hunter.get("alive", True)

        # Dead hunters can only attack if at least one alive hunter remains
        alive_hunters = [h for h in session.hunters.values() if h.get("alive", True)]
        if is_dead and not alive_hunters:
            return await interaction.response.send_message("💀 All hunters have fallen. The gate is lost.", ephemeral=True)

        # Dead hunters can't use skills
        if is_dead and skill_id:
            return await interaction.response.send_message("💀 Fallen hunters cannot use skills.", ephemeral=True)

        # Resolve skill
        skill      = None
        skill_mult = 1.0
        if skill_id:
            from cogs.player.player_cog import get_skill_by_id
            skill = get_skill_by_id(skill_id)
            if skill:
                if hunter.get("level", 1) < skill["unlock_level"]:
                    return await interaction.response.send_message(
                        f"❌ **{skill['name']}** is not unlocked yet.", ephemeral=True
                    )
                mp_cost = skill["mana_cost"]
                if hunter.get("mp", 0) < mp_cost:
                    return await interaction.response.send_message(
                        f"❌ Not enough MP! **{skill['name']}** costs `{mp_cost}` MP "
                        f"but you only have `{hunter.get('mp', 0)}` MP.",
                        ephemeral=True,
                    )
                hunter["mp"] = max(0, hunter.get("mp", 0) - mp_cost)
                skill_mult   = skill["power"] / 10.0

        dmg, is_crit, dodged = calc_damage(hunter, boss, skill_mult=skill_mult)
        if is_dead:
            dmg = int(dmg * DEAD_DAMAGE_MULT)

        # Boss damage cap based on kills
        cap = max(50, int(boss["max_hp"] * BOSS_CAP_MULT * (hunter["monsters_killed"] / max(session.total_monsters,1))))
        dmg = min(dmg, cap)

        boss["current_hp"] = max(0, boss["current_hp"] - dmg)
        hunter["boss_dmg_dealt"] = hunter.get("boss_dmg_dealt",0) + dmg

        crit_tag  = " ⚡ **CRIT!**" if is_crit else ""
        dead_tag  = " *(fallen)*" if is_dead else ""
        skill_tag = f" *[{skill['name']}]*" if skill else ""
        session.add_log(f"{hunter['name']}{dead_tag} → **{dmg:,}** DMG{crit_tag}{skill_tag}!")

        if boss["current_hp"] <= 0:
            await interaction.response.defer()
            await _end_clear(session, self.channel_id)
            return

        # Boss retaliates — targets lowest HP alive hunter
        alive_hunters = [h for h in session.hunters.values() if h.get("alive",True)]
        if alive_hunters:
            target = min(alive_hunters, key=lambda h: h["hp"])
            b_dmg, _, b_dodged = calc_damage(boss, target)
            b_dmg = safe_boss_dmg(b_dmg, target["hp"], target["max_hp"])
            if b_dodged:
                session.add_log(f"{boss['name']} attacked {target['name']} — **dodged!** 💨")
            else:
                target["hp"] = max(0, target["hp"] - b_dmg)
                session.add_log(f"{boss['name']} → **{target['name']}** for **{b_dmg:,}**!")
                if target["hp"] <= 0:
                    target["alive"] = False
                    session.add_log(f"💀 {target['name']} has fallen!")

        await interaction.response.defer()

        # Check if all hunters wiped during boss phase
        alive_after = [h for h in session.hunters.values() if h.get("alive", True)]
        if not alive_after:
            await _end_fail(session, self.channel_id, reason="wipe")
            return

        # Rebuild view so skill buttons reflect updated MP
        new_view = _build_boss_view(session, self.channel_id, self.bot)
        try:
            await session.boss_msg.edit(embed=_boss_embed(session), view=new_view)
        except Exception:
            pass


def _build_boss_view(session, channel_id, bot) -> BossCombatView:
    """
    Build boss view with skill buttons disabled if any hunter lacks MP.
    Since multiple hunters share the view, buttons are always visible —
    each hunter's MP is checked on click.
    """
    return BossCombatView(session, channel_id, bot)


# ─────────────────────────────────────────────────────────────
#  GATE FLOW FUNCTIONS
# ─────────────────────────────────────────────────────────────

async def _update_spawn_embed(session: GateSession):
    if not session.grid_msg:
        return
    try:
        await session.grid_msg.edit(embed=_spawn_embed(session))
    except Exception:
        pass


async def _update_grid(session: GateSession, force: bool = False, bot=None):
    if not session.grid_msg:
        return
    now = time.time()
    if not force and (now - session._last_update) < 1.2:
        return
    session._last_update = now
    try:
        _bot = bot or getattr(session, "_bot_ref", None)
        if _bot:
            new_view = GridActionView(session, session.channel.id, _bot)
            await session.grid_msg.edit(embed=_active_embed(session), view=new_view)
        else:
            await session.grid_msg.edit(embed=_active_embed(session))
    except Exception:
        pass


async def _join_countdown(session, channel_id, msg, view, bot):
    await asyncio.sleep(JOIN_WINDOW)
    if session.phase != "joining":
        return
    if not session.hunters:
        await msg.edit(
            embed=discord.Embed(
                title="[ GATE COLLAPSED ]",
                description="No hunters entered. Gate Key consumed.",
                color=0x36393F,
            ),
            view=None,
        )
        active_gates.pop(channel_id, None)
        return
    await _start_gate(session, channel_id, bot)


async def _start_gate(session: GateSession, channel_id: int, bot):
    if session.phase != "joining":
        return
    session.phase = "active"
    session._bot_ref = bot
    session.place_monsters()

    try:
        await session.grid_msg.edit(
            embed=discord.Embed(
                title="🚪  GATE ENTERED",
                description=(
                    f"```ansi\n"
                    f"\u001b[1;34m{'█'*10} HUNTERS CROSSED THE THRESHOLD {'█'*10}\u001b[0m\n"
                    f"```\n"
                    f"**{len(session.hunters)}** hunter(s) have entered the gate.\n"
                    f"You have **{GATE_TIMER//60} minutes** to clear all monsters and defeat the boss.\n\n"
                    f"*The battlefield is below. Use **🧭 Move** to navigate.*"
                ),
                color=RANK_META.get(session.rank, {}).get("color", 0x4040AA),
            ),
            view=None,
        )
    except Exception:
        pass

    grid_view = GridActionView(session, channel_id, bot)
    new_msg   = await session.channel.send(embed=_active_embed(session), view=grid_view)
    session.grid_msg = new_msg
    bot.loop.create_task(_gate_timer(session, channel_id))


async def _gate_timer(session: GateSession, channel_id: int):
    await asyncio.sleep(GATE_TIMER)
    if session.phase == "active":
        await _end_fail(session, channel_id, reason="time")


async def _start_boss(session: GateSession, channel_id: int, bot):
    session.phase = "boss"
    t      = session.boss_template.copy()
    count  = max(1, len(session.hunters))
    hp_mult = 1.0 + (count-1)*0.30
    scaled = int(t["hp"] * hp_mult)
    session.boss_data = {**t, "max_hp": scaled, "current_hp": scaled, "gate_rank": session.rank}

    view = _build_boss_view(session, channel_id, bot)
    msg  = await session.channel.send(embed=_boss_embed(session), view=view)
    session.boss_msg = msg


async def _start_combat(session, channel_id, hunter, monster, interaction, grid_view, bot, move_view=None):
    # HP restored each fight (intentional — each monster is a fresh duel)
    hunter["hp"] = hunter["max_hp"]
    hunter["mp"] = hunter["max_mp"]

    embed = _encounter_embed(hunter, monster, "Battle begins!", f"{monster['name']} blocks your path!")

    # Build a view with a "Back to Gate" button linking back to the gate channel
    channel_url  = f"https://discord.com/channels/{session.channel.guild.id}/{session.channel.id}"
    grid_msg_url = (
        f"https://discord.com/channels/{session.channel.guild.id}/{session.channel.id}/{session.grid_msg.id}"
        if session.grid_msg else channel_url
    )

    class DmCombatWithBack(DmCombatView):
        pass

    view = DmCombatWithBack(session, channel_id, hunter, monster, grid_view, bot)
    view.move_view = move_view

    # Add a link button (no callback needed — it's a URL button)
    back_btn = discord.ui.Button(
        label="↩ Back to Gate",
        style=discord.ButtonStyle.link,
        url=grid_msg_url,
        row=1,
    )
    view.add_item(back_btn)

    user = interaction.user
    try:
        dm_msg = await user.send(embed=embed, view=view)
        view.combat_msg = dm_msg
        dm_link = f"https://discord.com/channels/@me/{dm_msg.channel.id}/{dm_msg.id}"
        notif = discord.Embed(
            description=(
                f"⚔️ **{monster['name']}** encountered!\n"
                f"[**▶ Open Battle**]({dm_link}) *(check your DMs)*"
            ),
            color=0x2C2F33,
        )
        await interaction.followup.send(embed=notif, ephemeral=True)
    except discord.Forbidden:
        hunter["in_combat"]  = False
        monster["locked_by"] = None
        session.add_log(f"{hunter['name']}'s DMs closed — skipped.")
        await _update_grid(session, bot=bot)


async def _award_xp(session: GateSession, hunter: dict, monster: dict, user):
    hunter["xp_earned"]        = hunter.get("xp_earned",0) + monster["xp"]
    hunter["monsters_killed"]  += 1

    player = get_player(hunter["user_id"])
    if not player:
        return

    player["xp"]              = player.get("xp",0) + monster["xp"]
    player["monsters_killed"] = player.get("monsters_killed",0) + 1

    levels = apply_level_up(player)
    save_player(hunter["user_id"], player)

    if levels > 0:
        new_level = player["level"]
        try:
            await user.send(embed=discord.Embed(
                title="[ SYSTEM ] — Level Up!",
                description=(
                    f"```ansi\n"
                    f"\u001b[1;33m▓▓▓▓▓▓▓▓▓▓ LEVEL UP ▓▓▓▓▓▓▓▓▓▓\u001b[0m\n"
                    f"```\n"
                    f"**{user.display_name}** reached **Level {new_level}**!\n\n"
                    f"<:exp:1500854097170141276> **+{levels*3} Skill Points** allocated\n"
                    f"✦ Stats passively increased\n\n"
                    f"-# Use `sl su <stat> <n>` to invest"
                ),
                color=0xF1C40F,
            ))
        except discord.Forbidden:
            pass


async def _end_clear(session: GateSession, channel_id: int):
    session.phase = "ended"
    lines = []

    for uid, h in session.hunters.items():
        kills    = h.get("monsters_killed",0)
        boss_dmg = h.get("boss_dmg_dealt",0)
        gold     = kills * GOLD_PER_KILL.get(session.rank,40) + int(boss_dmg*0.05)
        crystals = max(1, int(gold*0.10))
        chest    = POST_GATE_CHESTS.get(session.rank, POST_GATE_CHESTS["E"])
        lo,hi    = chest["gold"]
        chest_gold = random.randint(lo,hi)

        player = get_player(uid)
        got_key = False
        if player:
            player["gold"]          = player.get("gold",0) + gold + chest_gold
            player["mana_crystals"] = player.get("mana_crystals",0) + crystals
            player["gates_cleared"] = player.get("gates_cleared",0) + 1
            got_key = random.random() < KEY_DROP_CHANCE.get(session.rank,0.10)
            if got_key:
                player["gate_keys"] = player.get("gate_keys",0)+1
            save_player(uid, player)

        key_line   = f"\n🔑 **+1 Gate Key**" if got_key else ""
        chest_line = f"\n{chest['emoji']} **{chest['label']}** → `+{chest_gold:,}` Gold"
        lines.append(
            f"**{h['name']}** · Kills: **{kills}** · Boss DMG: **{boss_dmg:,}**\n"
            f"┣ 🪙 **+{gold:,}** Gold  ·  💎 **+{crystals}** Essence"
            f"{chest_line}{key_line}"
        )

    color = RANK_META.get(session.rank,{}).get("color",0x57F287)
    embed = discord.Embed(
        title=f"[ GATE CLEARED ] — {_rank_emoji(session.rank)} {session.rank} Rank",
        description=(
            f"```ansi\n"
            f"\u001b[1;32m▓▓▓▓▓▓▓▓▓▓ MISSION COMPLETE ▓▓▓▓▓▓▓▓▓▓\u001b[0m\n"
            f"```\n"
            + "\n\n".join(lines)
        ),
        color=color,
    )
    embed.set_footer(text=f"Total monsters cleared: {session.total_monsters}")
    try:
        await (session.boss_msg or session.grid_msg).edit(embed=embed, view=None)
    except Exception:
        await session.channel.send(embed=embed)
    active_gates.pop(channel_id, None)


async def _end_fail(session: GateSession, channel_id: int, reason: str = "wipe"):
    if session.phase == "ended":
        return
    session.phase = "ended"
    reason_text = {
        "time":  "Time ran out.",
        "admin": "Gate force-ended by an admin.",
    }.get(reason, "All hunters were defeated.")
    lines = [
        f"**{h['name']}** — {h.get('monsters_killed',0)} kills · kept **{h.get('xp_earned',0)} XP**"
        for h in session.hunters.values()
    ]
    embed = discord.Embed(
        title="☠️ Gate Failed",
        description=f"{reason_text}\n\n" + "\n".join(lines),
        color=0xFF4444,
    )
    # Delete all gate messages so nothing lingers in chat
    for msg in [session.grid_msg, session.boss_msg]:
        if msg:
            try:
                await msg.delete()
            except Exception:
                pass
    # Send the final result embed as a fresh message
    try:
        await session.channel.send(embed=embed)
    except Exception:
        pass
    active_gates.pop(channel_id, None)


# ─────────────────────────────────────────────────────────────
#  GATE RANK ROLLING (based on player rank)
# ─────────────────────────────────────────────────────────────

def roll_gate_rank(player_rank: str, level: int) -> str:
    """Roll a gate rank appropriate for the player's rank."""
    rank_idx = RANK_ORDER.index(player_rank)
    weights  = {}
    for i, r in enumerate(RANK_ORDER):
        if i > rank_idx:
            weights[r] = 0
        elif i == rank_idx:
            weights[r] = 5
        elif i == rank_idx - 1:
            weights[r] = 30
        elif i == rank_idx - 2:
            weights[r] = 40
        else:
            weights[r] = 25
    valid = {r: w for r,w in weights.items() if w > 0}
    return random.choices(list(valid.keys()), weights=list(valid.values()), k=1)[0]


# ─────────────────────────────────────────────────────────────
#  COG
# ─────────────────────────────────────────────────────────────

class GateCog(commands.Cog, name="Gate"):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        _inject_monster_emojis()  # load monster emojis from JSON (supports m_ prefix + fuzzy)

    async def cog_load(self):
        print("[GateCog] ✅ Ready.")

    @commands.group(name="gate", invoke_without_command=True)
    async def gate(self, ctx: commands.Context):
        await self.gate_spawn(ctx)

    @gate.command(name="spawn", aliases=["s","open"])
    async def gate_spawn(self, ctx: commands.Context):
        """Spend a Gate Key to open a gate. Key is consumed on entry, not spawn."""
        player = get_player(ctx.author.id)
        if not player:
            return await ctx.send("❌ Not registered. Use `sl start` first.")

        if active_gates.get(ctx.channel.id):
            return await ctx.send("❌ A gate is already active in this channel.")

        uid = ctx.author.id
        for sess in active_gates.values():
            if uid in sess.hunters:
                return await ctx.send("❌ You're already inside an active gate.")

        # Cooldown check
        last = gate_summon_cd.get(uid, 0)
        rem  = GATE_SUMMON_CD_S - (time.time() - last)
        if rem > 0:
            return await ctx.send(f"⏳ Gate cooldown: **{rem:.1f}s** remaining.")

        # Key check — consumed when the player clicks Enter Gate (in JoinView)
        if player.get("gate_keys", 0) <= 0:
            return await ctx.send("❌ No Gate Keys 🔑. Earn them from daily rewards.")

        gate_summon_cd[uid] = time.time()

        p_rank  = player.get("rank", "E")
        level   = player.get("level", 1)
        rank    = roll_gate_rank(p_rank, level)
        session = GateSession(rank, ctx.channel, uid)
        active_gates[ctx.channel.id] = session

        ping_role = discord.utils.get(ctx.guild.roles, name=GATE_PING_ROLE)
        ping_msg  = ping_role.mention if ping_role else ""

        view = JoinView(session, ctx.channel.id, self.bot)
        msg  = await ctx.send(content=ping_msg or None, embed=_spawn_embed(session), view=view)
        session.grid_msg = msg

        self.bot.loop.create_task(
            _join_countdown(session, ctx.channel.id, msg, view, self.bot)
        )

    @gate.command(name="admin", aliases=["test","debug"])
    async def gate_admin_spawn(self, ctx: commands.Context, rank: str = None):
        """Admin only: spawn a specific gate rank for testing. No key cost, no cooldown.
        Usage: sl gate admin <rank>   e.g. sl gate admin S"""
        if not is_admin(ctx.author.id):
            return await ctx.send("❌ You don't have permission.", delete_after=6)

        valid_ranks = ["E", "D", "C", "B", "A", "S"]
        if not rank or rank.upper() not in valid_ranks:
            return await ctx.send(
                f"❌ Specify a rank: `sl gate admin <rank>`\n"
                f"Valid ranks: {', '.join(f'**{r}**' for r in valid_ranks)}"
            )

        rank = rank.upper()

        if active_gates.get(ctx.channel.id):
            return await ctx.send("❌ A gate is already active in this channel.")

        session = GateSession(rank, ctx.channel, 0)  # spawner_id=0 = admin/test gate (no key cost)
        active_gates[ctx.channel.id] = session

        view = JoinView(session, ctx.channel.id, self.bot)
        msg  = await ctx.send(
            content=f"🛠️ **[ADMIN TEST GATE]** — No key cost, no cooldown.",
            embed=_spawn_embed(session),
            view=view,
        )
        session.grid_msg = msg

        self.bot.loop.create_task(
            _join_countdown(session, ctx.channel.id, msg, view, self.bot)
        )

    @gate.command(name="skip", aliases=["end"])
    async def gate_skip(self, ctx: commands.Context):
        """Admin: force-end the current gate."""
        if not is_admin(ctx.author.id):
            return await ctx.send("❌ You don't have permission.", delete_after=6)
        session = active_gates.get(ctx.channel.id)
        if not session:
            return await ctx.send("❌ No active gate in this channel.")
        await _end_fail(session, ctx.channel.id, reason="admin")
        await ctx.send("🗑️ Gate force-ended.", delete_after=5)

    @gate.command(name="cancel", aliases=["c"])
    async def gate_cancel(self, ctx: commands.Context):
        """Admin: cancel the current gate cleanly (no fail embed, just removes it).
        Usage: sl gate cancel"""
        if not is_admin(ctx.author.id):
            return await ctx.send("❌ You don't have permission.", delete_after=6)
        session = active_gates.get(ctx.channel.id)
        if not session:
            return await ctx.send("❌ No active gate in this channel.")

        session.phase = "ended"
        active_gates.pop(ctx.channel.id, None)

        embed = discord.Embed(
            title="🚫 Gate Cancelled",
            description="An admin has cancelled this gate. No rewards or penalties.",
            color=0x808080,
        )
        try:
            await (session.grid_msg or session.boss_msg).edit(embed=embed, view=None)
        except Exception:
            pass
        await ctx.send("✅ Gate cancelled.", delete_after=5)

    @gate.command(name="force", aliases=["fs", "forcestart"])
    async def gate_force_start(self, ctx: commands.Context):
        """Admin: force-start the joining phase immediately."""
        if not is_admin(ctx.author.id):
            return await ctx.send("❌ You don't have permission.", delete_after=6)
        session = active_gates.get(ctx.channel.id)
        if not session:
            return await ctx.send("❌ No active gate in this channel.")
        if session.phase != "joining":
            return await ctx.send("❌ Gate is already past the joining phase.")
        if not session.hunters:
            return await ctx.send("❌ No hunters have joined yet — at least 1 needed.")
        await ctx.message.delete()
        await _start_gate(session, ctx.channel.id, self.bot)

    @gate.command(name="info", aliases=["i"])
    async def gate_info(self, ctx: commands.Context):
        """View current gate status."""
        session = active_gates.get(ctx.channel.id)
        if not session:
            return await ctx.send("❌ No active gate in this channel.")
        await ctx.send(embed=_active_embed(session))

    @gate.command(name="access", aliases=["ranks"])
    async def gate_access_info(self, ctx: commands.Context):
        """View which gates your rank can enter."""
        player = get_player(ctx.author.id)
        if not player:
            return await ctx.send("❌ Not registered.")
        rank     = player.get("rank","E")
        national = player.get("national_level",False)
        allowed  = GATE_ACCESS.get(rank,[]) + (["S"] if national else [])
        lines    = []
        for r in RANK_ORDER:
            can = r in allowed
            lines.append(f"{'✅' if can else '🔒'} **{r} Rank Gates** {_rank_emoji(r)}")
        if rank == "S" and not national:
            lines[-1] += " *(National Level required)*"
        embed = discord.Embed(
            title=f"🚪 Gate Access — {_rank_emoji(rank)} {rank} Rank",
            description="\n".join(lines),
            color=RANK_COLORS.get(rank,0x7B2FBE),
        )
        await ctx.send(embed=embed)

    async def cog_command_error(self, ctx, error):
        if isinstance(error, commands.CheckFailure):
            await ctx.send("❌ You don't have permission.", delete_after=6)
        elif isinstance(error, commands.CommandInvokeError):
            print(f"[GateCog] ❌ {ctx.command}: {error.original}")
            await ctx.send("⚠️ Something went wrong.", delete_after=6)
        else:
            raise error


async def setup(bot: commands.Bot):
    await bot.add_cog(GateCog(bot))
